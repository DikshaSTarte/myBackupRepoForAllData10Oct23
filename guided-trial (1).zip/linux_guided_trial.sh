#!/bin/bash

SCA_SLEEP_TIME=30

sleep_progress_bar() {
	# Define the duration of the "sleep" in seconds
	duration=$1

	# Define the width of the progress bar
	bar_width=$1

	# Calculate the number of dots to print for each second
	dots_per_second=$((bar_width / duration))

	# Loop through the duration, updating the progress bar and sleeping
	for ((i = 0; i < $duration; i++)); do
		# Calculate the number of dots to print for this second
		dots=$(((i + 1) * dots_per_second))

		# Print the progress bar
		printf "\r[%-${bar_width}s] %d/%d seconds" "$(printf "%${dots}s" | tr ' ' '=')" $((i + 1)) $duration

		# Sleep for one second
		sleep 1
	done

	# Add a newline character after the progress bar
	echo ""
}

pull_docker() {

	# Pull WebGoat OWASP
	docker pull $1
	# Check the result of docker pull
	if [ $? -eq 0 ]; then
		echo ""
		echo "[+] Docker pull operation is complete, running SCA... opening the web browser in $SCA_SLEEP_TIME seconds"
		echo "    IMPORTANT: Please note JFrog Advanced Security analyis might take up to 5 minutes"
		sleep_progress_bar $SCA_SLEEP_TIME
		if [[ $OSTYPE == 'darwin'* ]]; then
			open "https://${JF_INSTANCE_NAME}.jfrog.io/ui/scans-list/repositories/docker-hub-remote-repo-cache/scan-descendants"
		else
			xdg-open "https://${JF_INSTANCE_NAME}.jfrog.io/ui/scans-list/repositories/docker-hub-remote-repo-cache/scan-descendants"
		fi
		echo ""
		echo "Docker image pulled via JFrog Platform!"
		echo ""
	else
		echo "[-] Failed to pull docker. Is the docker name correct? Is the instance configured correctly?"
	fi
}

# Check if curl and docker are installed
if ! command -v curl &>/dev/null; then
	echo "curl not found. Please install curl with sudo apt-get install curl"
	exit 1
fi

if ! command -v docker &>/dev/null; then
	echo "docker not found. Please install docker - https://www.docker.com/products/docker-desktop/"
	echo "You might need to reopen the terminal to refresh your PATH environment variable."
	exit 1
fi

if ! docker images &>/dev/null; then
	echo "Failed to execute \"docker images\" command. Is the docker service available?"
	exit 1
fi

while true; do
	# Main menu
	echo "Welcome to JFrog trial setup!"
	echo "============================="
	echo "1. Configure the instance new or existing"
	echo "2. Docker login to existing trial from a new workstation"
	echo "3. Pull Docker image or select sample docker image"
	echo "4. Push Docker image from local machine to scan with JFrog Advanced Security"
	echo "5. Exit"
	echo ""

	read -p "Please select an option: " option

	if [[ "$option" == "1" ]]; then

		echo ""
		echo "Would you like to configure an existing instance or launch a new trial instance?"
		echo "1. I want to launch a new trial instance"
		echo "2. I already have an instance"
		echo ""

		read -p "Please select an option: " decided_option
		echo ""

		if [ "$decided_option" = "1" ]; then
			echo ""
			echo "Use the browser to launch a new JFrog Advanced Security Trial instance."
			echo "Once the instance is launched, paste in this terminal the instance name and credential to complete its configuration."
			echo "Opening the browser in 5 seconds..."
			sleep_progress_bar 5

			# Create a 14-day trial
			if [[ $OSTYPE == 'darwin'* ]]; then
				open https://jfrog.com/start-free/security/ &>/dev/null
			else
				xdg-open https://jfrog.com/start-free/security/ &>/dev/null
			fi
		fi
		# Ask for JF credentials
		if [ -z "$JF_INSTANCE_NAME" ]; then
			read -p "Enter instance name: " JF_INSTANCE_NAME
			# Check if the input contains "://" to determine if it's a full URL
			if [[ "$JF_INSTANCE_NAME" == http* ]]; then
				URL="$JF_INSTANCE_NAME"
				# Extract the hostname from the URL
				JF_INSTANCE_NAME=$(echo "$URL" | awk -F/ '{print $3}' | sed 's/.jfrog.io//')
			fi
		fi

		if [ -z "$JF_USERNAME" ]; then
			read -p "Enter Email: " JF_USERNAME
		fi

		while [ -z "$JF_PASSWORD" ]; do
			echo ""
			echo "Have you signed up with SSO or email?"
			echo "1. I have signed up with SSO - Google or Github"
			echo "2. I have signed up with Email and defined a password"
			echo ""

			read -p "Please select an option: " signed_up_option
			echo ""

			if [ "$signed_up_option" = "1" ]; then
				# SSO
				echo "Please generate an API Key using the browser and paste it in the terminal. Opening browser in 5 seconds..."
				echo "Note: Generate an API Key (scroll down) and not an Identity Token!"
				sleep_progress_bar 5
				if [[ $OSTYPE == 'darwin'* ]]; then
					open https://$JF_INSTANCE_NAME.jfrog.io/ui/user_profile &>/dev/null
				else
					xdg-open https://$JF_INSTANCE_NAME.jfrog.io/ui/user_profile &>/dev/null
				fi
				read -sp "Enter API Key: " JF_PASSWORD
			elif [ "$signed_up_option" = "2" ]; then
				# Email based registration
				read -sp "Enter Password: " JF_PASSWORD
			else
				echo "Invalid option"
			fi
		done

		echo ""
		echo "Configuring the trial instance:"
		echo "==============================="
		# ------------ Remote Docker-Hub Repository ------------
		# Configure remote repository with Xray enabled
		RESPONSE_CODE=$(curl -s -o /dev/null -w "%{http_code}" -u "$JF_USERNAME:$JF_PASSWORD" -X PUT "https://$JF_INSTANCE_NAME.jfrog.io/artifactory/api/repositories/docker-hub-remote-repo" -H "Content-Type: application/json" -d '{"key":"docker-hub-remote-repo","rclass":"remote","packageType":"docker","url":"https://registry-1.docker.io/","xrayIndex":true}')
		if [ "$RESPONSE_CODE" == "200" ]; then
			echo "[+] Successfully created new remote repository for DockerHub with Xray SCA enabled"
		else
			echo "[-] Failed to created new remote repository for DockerHub with Xray SCA enabled. Maybe it already exists?"
		fi

		# Turn on JFrog Advanced Security
		RESPONSE_CODE=$(curl -s -o /dev/null -w "%{http_code}" -u "$JF_USERNAME:$JF_PASSWORD" -X PUT "https://$JF_INSTANCE_NAME.jfrog.io/xray/api/v1/repos_config" -H "Content-Type: application/json" -d '{"repo_name":"docker-hub-remote-repo","repo_config":{"vuln_contextual_analysis":true,"exposures":{"scanners_category":{"services_scan":true,"secrets_scan":true,"applications_scan":true}},"retention_in_days":90}}')
		if [ "$RESPONSE_CODE" -eq "200" ]; then
			echo "[+] Successfully configured JFrog Advanced Security scanning on the remote repository for DockerHub"
		else
			echo "[-] Failed to configure JFrog Advanced Security scanning on the remote repository for DockerHub. Does the repository exist? Are you working with an instance that has JFrog Advanced Security available?"
		fi

		# Local Docker Repository
		# Configure local repository with Xray enabled
		RESPONSE_CODE=$(curl -s -o /dev/null -w "%{http_code}" -u "$JF_USERNAME:$JF_PASSWORD" -X PUT "https://$JF_INSTANCE_NAME.jfrog.io/artifactory/api/repositories/local-docker-repo" -H "Content-Type: application/json" -d '{"key":"local-docker-repo","rclass":"local","packageType":"docker","xrayIndex":true}')
		if [ "$RESPONSE_CODE" -eq "200" ]; then
			echo "[+] Successfully created new local repository for Dockers with Xray SCA enabled"
		else
			echo "[-] Failed to create new local repository for Dockers with Xray SCA enabled. Maybe it already exists?"
		fi

		# Turn on JFrog Advanced Security
		RESPONSE_CODE=$(curl -s -o /dev/null -w "%{http_code}" -u "$JF_USERNAME:$JF_PASSWORD" -X PUT "https://$JF_INSTANCE_NAME.jfrog.io/xray/api/v1/repos_config" -H "Content-Type: application/json" -d '{"repo_name":"local-docker-repo","repo_config":{"vuln_contextual_analysis":true,"exposures":{"scanners_category":{"services_scan":true,"secrets_scan":true,"applications_scan":true}},"retention_in_days":90}}')
		if [[ "$RESPONSE_CODE" -eq "200" ]]; then
			echo "[+] Successfully configured JFrog Advanced Security scanning on the local repository for Dockers"
		else
			echo "[-] Failed to configure JFrog Advanced Security scanning on the local repository for Dockers. Does the repository exist? Are you working with an instance that has JFrog Advanced Security available?"
		fi

		# Policy and Watch
		# Configure policy
		RESPONSE_CODE=$(curl -s -o /dev/null -w "%{http_code}" -u "$JF_USERNAME:$JF_PASSWORD" -X POST "https://$JF_INSTANCE_NAME.jfrog.io/xray/api/v2/policies" -H "Content-Type: application/json" -d '{"name":"Security_policy","type":"security","rules":[{"name":"Critical_CVEs","priority":1,"actions":{"block_download":{"unscanned":false,"active":false}},"criteria":{"applicable_cves_only":true,"fix_version_dependant":true,"min_severity":"Critical"}},{"name":"Malicious_packages","priority":2,"actions":{"block_download":{"active":true}},"criteria":{"malicious_package":true}},{"name":"High_Exposures","priority":3,"criteria":{"exposures":{"applications":true,"iac":true,"min_severity":"high","secrets":true,"malicious_code": false,"services":true}}}]}')
		if [ "$RESPONSE_CODE" -eq 201 ]; then
			echo "[+] Successfully configured an Xray policy. The policy rules are:"
			echo "     Create violation for CVEs with Critical CVSS Score"
			echo "     Create violation for Exposures with High impact severity"
			echo "     Create violation and block download of malicious packages"
		else
			echo "[-] Failed to configure an Xray policy. Does the policy name already exist? Are you working with an instance that has JFrog Advanced Security available?"
		fi

		# Configure watch
		RESPONSE_CODE=$(curl -s -o /dev/null -w "%{http_code}" -u "$JF_USERNAME:$JF_PASSWORD" -X POST "https://$JF_INSTANCE_NAME.jfrog.io/xray/api/v2/watches" -H "Content-Type: application/json" -d "{\"general_data\":{\"description\":\"This is a new watch created using API V2\",\"name\":\"Security_watch\",\"active\":true},\"project_resources\":{\"resources\":[{\"type\":\"all-repos\",\"name\":\"All Repositories\",\"bin_mgr_id\":\"default\"}]},\"assigned_policies\":[{\"name\":\"Security_policy\",\"type\":\"security\"}]}")
		if [ "$RESPONSE_CODE" -eq "201" ]; then
			echo "[+] Successfully configured an Xray Watch on all repositories."
		else
			echo "[-] Failed to configure an Xray Watch on all repositories. Does the Watch name already exist?"
		fi

		# Configure docker
		docker login -u $JF_USERNAME -p $JF_PASSWORD $JF_INSTANCE_NAME.jfrog.io >/dev/null 2>&1

		# Check if docker login failed
		if [ $? -eq 0 ]; then
			echo "[+] Successfully executed docker login command to work with the trial instance. You are now logged in."
		else
			echo "[-] Failed to execute docker login command"
		fi

		echo ""
		echo "Trial setup complete!"
		echo ""
		#fi
		# done

	elif [[ "$option" == "2" ]]; then
		# Ask for JF credentials
		if [ -z "$JF_INSTANCE_NAME" ]; then
			read -p "Enter instance name: " JF_INSTANCE_NAME
			# Check if the input contains "://" to determine if it's a full URL
			if [[ "$JF_INSTANCE_NAME" == http* ]]; then
				URL="$JF_INSTANCE_NAME"
				# Extract the hostname from the URL
				JF_INSTANCE_NAME=$(echo "$URL" | awk -F/ '{print $3}' | sed 's/.jfrog.io//')
			fi
		fi

		if [ -z "$JF_USERNAME" ]; then
			read -p "Enter Email: " JF_USERNAME
		fi

		while [ -z "$JF_PASSWORD" ]; do
			echo ""
			echo "Have you signed up with SSO or email?"
			echo "1. I have signed up with SSO - Google or Github"
			echo "2. I have signed up with Email and defined a password"
			echo ""

			read -p "Please select an option: " signed_up_option
			echo ""

			if [ "$signed_up_option" = "1" ]; then
				# SSO
				echo "Please generate an API Key using the browser and paste it in the terminal. Opening browser in 5 seconds..."
				echo "Note: Generate an API Key (scroll down) and not an Identity Token!"
				sleep_progress_bar 5
				if [[ $OSTYPE == 'darwin'* ]]; then
					open https://$JF_INSTANCE_NAME.jfrog.io/ui/user_profile &>/dev/null
				else
					xdg-open https://$JF_INSTANCE_NAME.jfrog.io/ui/user_profile &>/dev/null
				fi
				read -sp "Enter API Key: " JF_PASSWORD
			elif [ "$signed_up_option" = "2" ]; then
				# Email based registration
				read -sp "Enter Password: " JF_PASSWORD
			else
				echo "Invalid option"
			fi
		done

		# Configure docker
		docker login -u $JF_USERNAME -p $JF_PASSWORD $JF_INSTANCE_NAME.jfrog.io >/dev/null 2>&1

		echo ""
		# Check if docker login failed
		if [ $? -eq 0 ]; then
			echo "[+] Successfully executed docker login command to work with the trial instance. You are now logged in."
		else
			echo "[-] Failed to execute docker login command"
		fi

		echo ""

	elif [[ "$option" == "3" ]]; then
		# Ask for JF credentials
		if [ -z "$JF_INSTANCE_NAME" ]; then
			read -p "Enter instance name: " JF_INSTANCE_NAME
			# Check if the input contains "://" to determine if it's a full URL
			if [[ "$JF_INSTANCE_NAME" == http* ]]; then
				URL="$JF_INSTANCE_NAME"
				# Extract the hostname from the URL
				JF_INSTANCE_NAME=$(echo "$URL" | awk -F/ '{print $3}' | sed 's/.jfrog.io//')
			fi
		fi

		echo ""
		echo "Pull Docker image or select sample docker image:"
		echo "================================================"

		# Menu of Docker images
		echo "1. Pull OWASP WebGoat - Good example of Contextual Analysis value"
		echo "2. Pull netdata:1.13.0 - Good example of a Docker with 100M+ downloads with an embedded secret"
		echo "3. Pull juice-shop:latest - Good example of Application and Secret Exposures"
		echo "4. Pull hello:latest- Good example of ServiceExposures (nginx)"
		echo "5. Pull custom image from DockerHub via Artifactory to scan with JFrog Advanced Security"
		echo ""

		read -p "Please select an option: " image_option
		echo ""

		if [[ "$image_option" == "1" ]]; then
			# Pull WebGoat OWASP
			pull_docker "${JF_INSTANCE_NAME}.jfrog.io/docker-hub-remote-repo/webgoat/webgoat-8.0:latest"
		elif [[ "$image_option" == "2" ]]; then
			# Pull titpetric/netdata:1.13.0
			pull_docker "${JF_INSTANCE_NAME}.jfrog.io/docker-hub-remote-repo/titpetric/netdata:1.13.0"
		elif [[ "$image_option" == "3" ]]; then
			# Pull bkimminich/juice-shop:latest
			pull_docker "${JF_INSTANCE_NAME}.jfrog.io/docker-hub-remote-repo/bkimminich/juice-shop:latest"
		elif [[ "$image_option" == "4" ]]; then
			# Pull nginxdemos/hello:latest
			pull_docker "${JF_INSTANCE_NAME}.jfrog.io/docker-hub-remote-repo/nginxdemos/hello:latest"
		elif [[ "$image_option" == "5" ]]; then
			# Load custom image
			read -p "Enter path to Docker image (like webgoat/webgoat-8.0:latest): " image_path
			docker rmi "${JF_INSTANCE_NAME}.jfrog.io/docker-hub-remote-repo/${image_path}" >/dev/null 2>&1
			docker image prune -f >/dev/null
			pull_docker "${JF_INSTANCE_NAME}.jfrog.io/docker-hub-remote-repo/${image_path}"
		else
			echo "Invalid option"
		fi

	elif [[ "$option" == "4" ]]; then
		# Ask for JF credentials
		if [ -z "$JF_INSTANCE_NAME" ]; then
			read -p "Enter instance name: " JF_INSTANCE_NAME
			# Check if the input contains "://" to determine if it's a full URL
			if [[ "$JF_INSTANCE_NAME" == http* ]]; then
				URL="$JF_INSTANCE_NAME"
				# Extract the hostname from the URL
				JF_INSTANCE_NAME=$(echo "$URL" | awk -F/ '{print $3}' | sed 's/.jfrog.io//')
			fi
		fi

		echo ""
		echo "Push Docker image from local machine to scan with JFrog Advanced Security:"
		echo "======================================================"
		echo "Listing available docker images on local machine:"
		echo ""
		docker images
		echo ""
		echo "Enter Docker image name and then its tag: "
		echo "=========================================	"
		read -p "Enter the Docker image name (REPOSITORY column): " image_name
		read -p "Enter the Docker tag (TAG column): " tag
		echo ""
		docker tag $image_name:$tag $JF_INSTANCE_NAME.jfrog.io/local-docker-repo/$image_name:$tag

		# Check the result of docker tag
		if [ $? -eq 0 ]; then
			docker push $JF_INSTANCE_NAME.jfrog.io/local-docker-repo/$image_name:$tag
			if [ $? -eq 0 ]; then
				echo ""
				echo "[+] Docker push operation is complete, running SCA... opening the web browser in $SCA_SLEEP_TIME seconds"
				echo "    IMPORTANT: Please note JFrog Advanced Security analyis might take up to 5 minutes"
				sleep_progress_bar $SCA_SLEEP_TIME
				if [[ $OSTYPE == 'darwin'* ]]; then
					open "https://${JF_INSTANCE_NAME}.jfrog.io/ui/scans-list/repositories/local-docker-repo/scan-descendants"
				else
					xdg-open "https://${JF_INSTANCE_NAME}.jfrog.io/ui/scans-list/repositories/local-docker-repo/scan-descendants"
				fi

				echo ""
				echo "Docker image pushed to JFrog Platform!"
				echo ""
			else
				echo "[-] Failed to push docker. Is the docker name correct? Is the instance configured correctly?"
			fi
		else
			echo "[-] Failed to tag docker. Is the docker name correct?"
		fi
	elif [[ "$option" == "5" ]]; then
		echo "Exiting script."
		exit 1
	else
		echo "Invalid option"
	fi
done
