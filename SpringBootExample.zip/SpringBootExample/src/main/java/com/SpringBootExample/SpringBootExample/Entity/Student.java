package com.SpringBootExample.SpringBootExample.Entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;




@Entity
@Table(name="Student_table")
public class Student {
	
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)

private Long id;
private String name;
private int age;
private String dept;

public Student() {
}

public Student(Long id, String name, int age, String dept) {
	super();
	this.id = id;
	this.name = name;
	this.age = age;
	this.dept = dept;
}

public Long getId() {
	return id;
}

public void setId(Long id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public int getAge() {
	return age;
}

public void setAge(int age) {
	this.age = age;
}

public String getDept() {
	return dept;
}

public void setDept(String dept) {
	this.dept = dept;
}


@ManyToMany(fetch =FetchType.LAZY,cascade = CascadeType.ALL)

@JoinTable(name="Student_Course_Table" ,joinColumns= 
{
		@JoinColumn(name="Student_id", referencedColumnName="id")
		},
inverseJoinColumns = @JoinColumn(name="Course_id",referencedColumnName="id"))

@JsonBackReference
private Set<Course>course;
}
