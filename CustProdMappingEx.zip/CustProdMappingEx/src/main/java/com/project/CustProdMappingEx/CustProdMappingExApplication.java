package com.project.CustProdMappingEx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustProdMappingExApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustProdMappingExApplication.class, args);
	}

}
