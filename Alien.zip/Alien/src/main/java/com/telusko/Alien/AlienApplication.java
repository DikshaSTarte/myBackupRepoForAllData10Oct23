package com.telusko.Alien;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlienApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlienApplication.class, args);
	}

}
