package com.telusko.Alien;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlienApplicationTests {

	@Test
	void contextLoads() {
	}

}
