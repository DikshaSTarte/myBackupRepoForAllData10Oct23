package com.hrms.demo.serviceImpl;
import com.hrms.demo.dto.response.UserListResponse;
import com.hrms.demo.dto.response.UserTypeResponse;
import com.hrms.demo.globleexception.UserAlreadyExistsException;
import com.hrms.demo.globleexception.UserNotFoundException;
import com.hrms.demo.globleexception.newPasswordAndConformPasswordNotMatchesException;
import com.hrms.demo.model.*;
import com.hrms.demo.repository.*;
import com.hrms.demo.dto.request.UserRequest;
import com.hrms.demo.dto.response.UserResponse;
import com.hrms.demo.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.*;
@Slf4j
@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private UserTypeRepository userTypeRepository;

    @Autowired
    private InterviewerRepository interviewerRepository;
    @Autowired
    private EmailRepository emailRepository;
    @Autowired
    PasswordEncoder passwordEncoder;
    @Value("${app.frontend.url}")
    private String frontendurl;

    @Override
    public UserResponse saveUser(UserRequest userRequest) {
        log.info("UserServiceImpl----------saveUser------{}",userRequest);
        User user = new User();
        user.setUsername(userRequest.getUsername());
        UserType userTypeId = userTypeRepository.findByActiveAndUserTypeId(true, userRequest.getUserType());
        user.setUserType(userTypeId);
        // user.setPassword(passwordEncoder.encode(userRequest.getPassword()));
        user.setUserFirstName(userRequest.getUserFirstName());
        user.setUserLastName(userRequest.getUserLastName());

        if (userRepository.existsByActiveAndUserContact(user.isActive(),userRequest.getUserContact())) {
            log.error("UserServiceImpl----------saveUser------{}",userRequest.getUserContact(),"User already exists with this contact number");
            throw new UserAlreadyExistsException("User already exists with this contact number" );
        }
        user.setUserContact(userRequest.getUserContact());

        if(userRepository.existsByActiveAndUserEmailId(user.isActive(),userRequest.getUserEmailId())){
            log.error("UserServiceImpl----------saveUser------{}",userRequest.getUserEmailId(),"User already exists with this emailId");
            throw new UserAlreadyExistsException("User already exists with this emailId");
        }
        user.setUserEmailId(userRequest.getUserEmailId());
        String password = generateRandomPassword(); // generate random password
        user.setPassword(password);
        String email = userRequest.getUserEmailId(); // get the user's email address from the database

        String emailBody = "Dear User,\n\nYour Username is: " + email + "\n\nYour Password is: " + password + "\n\nKeep it safe\n\nClick on the given link to login \n\n "+frontendurl+"\n\n"+"\n\nRegards,\nRecruitment Tracker Team";
        //String emailBody = "Dear User,\n\nYour Username is: " + email + "\n\nYour Password is: " + password + "\n\nRegards,\nRecruitment Tracker Team";

        String subjectMessage="Your New Password";

        Email emailEntity=new Email();
        emailEntity.setEmailId(email);
        emailEntity.setSubjectMessage(subjectMessage);
        emailEntity.setMessage(emailBody);
        emailEntity.setIsSendEmail(false);
        emailRepository.save(emailEntity);

        String encodedPassword1 = passwordEncoder.encode(password);
        user.setPassword(encodedPassword1);

        User save = this.userRepository.save(user);

        UserResponse userResponse = userEntityToUserResponse(save);
       // UserResponse userResponse1 = userEntityToUserResponse(save);
        log.info("UserServiceImpl----------saveUser------{}",userRequest);
        return userResponse;
    }

    public String generateRandomPassword() {
        String upperCaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String lowerCaseLetters = "abcdefghijklmnopqrstuvwxyz";
        String numbers = "0123456789";
        String specialCharacters = "!@#$%&*";
        String combinedChars = upperCaseLetters + lowerCaseLetters + numbers + specialCharacters;
        Random random = new Random();
        StringBuilder password = new StringBuilder();
        for (int i = 0; i < 8; i++) {
            password.append(combinedChars.charAt(random.nextInt(combinedChars.length())));
        }
        return password.toString();
    }
    @Override
    public String deleteUserById(Integer userId) {
        log.info("UserServiceImpl-------------deleteUserById-----------{}",userId);
        Optional<User> user = userRepository.findById(userId);
        user.get().setActive(false);
        userRepository.save(user.get());
        return "User Successfully Deleted";
    }
    @Override
    public UserResponse getUserById(Integer userId) {
        log.info("UserServiceImpl-------------getUserById-----------{}",userId);
        User user = userRepository.findByActiveAndUserId(true, userId);
        // User user = new User();
        UserResponse userResponse = new UserResponse();
        userResponse.setUserId(user.getUserId());
        userResponse.setUserType(new UserTypeResponse(user.getUserType().getUserTypeId(), user.getUserType().getUserTypeName()));
        userResponse.setUserFirstName(user.getUserFirstName());
        userResponse.setUserLastName(user.getUserLastName());
        userResponse.setUsername(user.getUsername());


        userResponse.setUserContact(user.getUserContact());
        userResponse.setUserEmailId(user.getUserEmailId());
        log.info("UserServiceImpl-------------getUserById-----------{}",userId);
        return userResponse;
    }
    @Override
    public UserResponse updateUser(Integer userId, UserRequest userRequest) {
        log.info("UserServiceImpl-------------updateUser-----------{}",userId,userRequest);
        User user = userRepository.findByActiveAndUserId(true, userId);
        user.setUserFirstName(userRequest.getUserFirstName());
        user.setUserLastName(userRequest.getUserLastName());
        user.setUserContact(userRequest.getUserContact());
        user.setUserEmailId(userRequest.getUserEmailId());
        user.setUserType(userTypeRepository.findById(userRequest.getUserType()).get());

        User update = this.userRepository.save(user);
        UserResponse userResponse = userEntityToUserResponse(update);
        log.info("UserServiceImpl-------------updateUser-----------{}",userId,userRequest);
        return userResponse;
    }
    @Override
    public List<UserResponse> getListOfUsers() {
        log.info("UserServiceImpl-------------getListOfUsers-----------{}");
        List<User> all = userRepository.findByActive(true);
        List<UserResponse> userResposeList = new ArrayList<>();
        for (User user : all) {
            userResposeList.add(userEntityToUserResponse(user));
        }
        return userResposeList;
    }
    public String createRandomStringForUser() {
        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        int length = 7;
        for (int i = 0; i < length; i++) {
            int index = random.nextInt(alphabet.length());
            char randomChar = alphabet.charAt(index);
            sb.append(randomChar);
        }
        String randomStringPassword = sb.toString();

        return randomStringPassword;
    }
    @Override
    public List<UserResponse> getAllUser(Integer pageNumber, String searchKey) {
    log.info("UserServiceImpl---------------getAllUser----------{}",pageNumber,searchKey);
        Pageable pageable = PageRequest.of(pageNumber, 7);
        if (searchKey.equals("")) {
            List<User> all1 = userRepository.findByActive(true, pageable);
            List<UserResponse> userResponseList1 = new ArrayList<>();
            for (User user : all1) {
                userResponseList1.add(userEntityToUserResponse(user));
            }
            return userResponseList1;
        } else {
            List<User> all2 = userRepository.findByActiveAndUserFirstNameContainingIgnoreCaseOrUserLastNameContainingIgnoreCaseOrUserContactContainingIgnoreCaseOrUserEmailIdContainingIgnoreCaseOrUsernameContainingIgnoreCase(true, searchKey, searchKey, searchKey, searchKey, searchKey, pageable);

            List<UserResponse> userResponseList2 = new ArrayList<>();
            for (User user : all2) {
                userResponseList2.add(userEntityToUserResponse(user));
            }
            return userResponseList2;
        }
    }
    UserResponse userEntityToUserResponse(User user) {
        UserResponse userResponse = new UserResponse();
        userResponse.setUserId(user.getUserId());
        userResponse.setUsername(user.getUsername());
        userResponse.setUserType(new UserTypeResponse(user.getUserType().getUserTypeId(), user.getUserType().getUserTypeName()));
        //userResponse.setUserType(user.getUserType().getUserTypeId());
        userResponse.setUserContact(user.getUserContact());
        userResponse.setUserEmailId(user.getUserEmailId());
        userResponse.setUserFirstName(user.getUserFirstName());
        userResponse.setUserLastName(user.getUserLastName());

        return userResponse;
    }

    @Override
//    public List<UserResponse> getUserByUserTypeId(Integer userTypeId) {
//        log.info("UserServiceImpl---------------getUserByUserTypeId------------{}",userTypeId);
//        Optional<UserType> userOptional = Optional.ofNullable(userTypeRepository.findByActiveAndUserTypeId(true, userTypeId))
//
//        List<User> user = userRepository.findByActiveAndUserType(true,userOptional.get());
//        List<UserResponse> responses = new ArrayList<>();
//        for (User usr:user) {
//            UserResponse response = new UserResponse();
//            response.setUserType(new UserTypeResponse(usr.getUserType().getUserTypeId(),usr.getUserType().getUserTypeName()));
//            response.setUserId(usr.getUserId());
//            response.setUserFirstName(usr.getUserFirstName());
//            response.setUserLastName(usr.getUserLastName());
//            responses.add(response);
//        }
//        log.info("UserServiceImpl---------------getUserByUserTypeId------------{}",userTypeId);
//        return responses ;
//    }
    public List<UserResponse> getUserByUserTypeId(Integer userTypeId) {
        log.info("UserServiceImpl---------------getUserByUserTypeId------------{}", userTypeId);
        Optional<UserType> userOptional = Optional.ofNullable(userTypeRepository.findByActiveAndUserTypeId(true, userTypeId));
        List<User> users = userRepository.findByActiveAndUserType(true, userOptional.get());
        List<UserResponse> responses = new ArrayList<>();
        Set<String> uniqueIdentifiers = new HashSet<>();

        for (User user : users) {
            UserResponse response = new UserResponse();
            response.setUserType(new UserTypeResponse(user.getUserType().getUserTypeId(), user.getUserType().getUserTypeName()));
            response.setUserId(user.getUserId());
            response.setUserFirstName(user.getUserFirstName());
            response.setUserLastName(user.getUserLastName());
            response.setUserType(new UserTypeResponse(user.getUserType().getUserTypeId(),user.getUserType().getUserTypeName()));


            // Create a unique identifier based on user's first name and last name
            String uniqueIdentifier = user.getUserFirstName() + "-" + user.getUserLastName();

            // Check if the unique identifier is not already present
            if (!uniqueIdentifiers.contains(uniqueIdentifier)) {
                responses.add(response);
                uniqueIdentifiers.add(uniqueIdentifier);
            }
        }

        log.info("UserServiceImpl---------------getUserByUserTypeId------------{}", userTypeId);
        return responses;
    }

    private String generateOTP() {
        Random random = new Random();
        int otpLength = 6; // Set the desired length of the OTP
        StringBuilder otp = new StringBuilder();

        for (int i = 0; i < otpLength; i++) {
            otp.append(random.nextInt(10));
        }

        return otp.toString();
    }
    @Override
    public void forgotPassword(String userEmailId) {
        User user = userRepository.findByActiveAndUserEmailId(true, userEmailId);

        if (user == null) {
            throw new UserNotFoundException("User not found for email: " + userEmailId);
        }
        String otp = generateOTP(); // generate random password
       user.setOtp(otp);

        User save = this.userRepository.save(user);

        String emailBody1 = "Dear User,\n\nYour Username is: " + userEmailId+ "\n\nYour OTP is: " + otp + "\n\nRegards,\nRecruitment Tracker Team";
       String subject2="Your OTP ";

        Email emailEntity2=new Email();
        emailEntity2.setEmailId(userEmailId);
        emailEntity2.setSubjectMessage(subject2);
        emailEntity2.setMessage(emailBody1);
        emailEntity2.setIsSendEmail(false);
        emailRepository.save(emailEntity2);

    }

    private void sendOtpToUserEmail(String otp, String userEmailId,String subject2) throws MessagingException {
        Properties properties = new Properties();
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587");
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        String username = "recruitmenttrackerteams@gmail.com";
        char[] password1 = "jqbgbvknsrljaqsn".toCharArray();
        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                String password = new String(password1);
                return new PasswordAuthentication(username, password);
            }

        });
        Message message34 = new MimeMessage(session);
        message34.setFrom(new InternetAddress(username));
        message34.setRecipients(Message.RecipientType.TO, InternetAddress.parse(userEmailId));
        message34.setSubject(subject2);

        String emailBody = "Dear User,\n\nYour Username is: " + userEmailId+ "\n\nYour OTP is: " + otp + "\n\nRegards,\nRecruitment Tracker Team";
        message34.setText(emailBody);

        Transport.send(message34);
    }

    @Override
    public boolean verifyOTP(String userEmailId, String otp) {
        User user = userRepository.findByActiveAndUserEmailId(true,userEmailId);

        if (user == null) {
            throw new UserNotFoundException("User not found for email: " + userEmailId);
        }
        String storedOTP = user.getOtp(); // Assuming the stored OTP is stored in the User entity as a field (e.g., 'otp')
        return storedOTP.equals(otp);
    }


    @Override
    public void resetPassword(String userEmailId, String newPassword,String conformPassword) {
        User user = userRepository.findByActiveAndUserEmailId(true, userEmailId);

        if (user == null) {
            throw new UserNotFoundException("User not found for email: " + userEmailId);
        }
         else if(!newPassword.equals(conformPassword)){

            throw new newPasswordAndConformPasswordNotMatchesException("New password and confirm password do not match.");
        }
        // Update the user's password with the new password
        else if(newPassword.equals(conformPassword)){
            String encodedPassword = passwordEncoder.encode(newPassword);
            user.setPassword(encodedPassword);
            userRepository.save(user);

        }
    }

    @Override
    public UserListResponse getListUsersPg(Integer pageNumber, Integer pageSize, String searchTerm) {
        List<User> all;
        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        long totalUsers;
        Integer excludedUserTypeId = 4;
        if (searchTerm != null && !searchTerm.isEmpty()) {
            all = userRepository.findBySearchTermAndUserTypeUserTypeIdNotFour(searchTerm,pageable);
            totalUsers = userRepository.countBySearchTermAndUserTypeUserTypeIdNotFour(searchTerm); // Get the count from the list size
        } else {

            Page<User> userPage = userRepository.findByActiveAndUserTypeUserTypeIdNotOrderByUserIdDesc(true, excludedUserTypeId, pageable);

            all = userPage.getContent();
            totalUsers = userRepository.countByActiveAndUserTypeUserTypeIdNot(true,4); // Get the total count separately
        }
        List<UserResponse> userResposeList = new ArrayList<>();
        for (User user : all) {
            userResposeList.add(userEntityToUserResponse(user));
        }
        System.out.println("Total candidates: " + totalUsers);

        return new UserListResponse(totalUsers, userResposeList);
    }

}