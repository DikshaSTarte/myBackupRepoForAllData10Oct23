package com.hrms.demo.dto.request;

import javax.persistence.Column;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InterviewerFeedbackRequest {

    @NotNull
    @Min(value = 0, message = "InterviewerFdbk Rating must be greater than or equal to 0.")
    private Integer interviewerFdbkRatings;
    @NotBlank(message = "Feedback description is required")
    @Column(name = "interviewer_fdbk_descp")
    private String interviewerFdbkDescp;
}
