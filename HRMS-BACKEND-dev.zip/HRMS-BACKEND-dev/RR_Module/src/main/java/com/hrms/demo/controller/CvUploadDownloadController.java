
package com.hrms.demo.controller;

// Skipping this as it has already had been implemented in other classes by manisha
import com.hrms.demo.model.Candidate;
import com.hrms.demo.model.FileUploade;
import com.hrms.demo.repository.CandidateRepository;
import com.hrms.demo.repository.FileUploadeRepository;
import com.hrms.demo.service.CvUploadDownloadService;
import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.util.http.fileupload.FileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
@Slf4j
@RestController
@RequestMapping("/resume")
public class CvUploadDownloadController {

    @Autowired
    private CvUploadDownloadService cvUploadDownloadService;

    @PostMapping("/uploadFile")
    public ResponseEntity<Object> uploadFile(@RequestParam("File") MultipartFile file) throws IOException {
        log.info("CvUploadDownloadController-----------------uploadFile--------{}",file);
        return cvUploadDownloadService.uploadFile(file);
    }

    @GetMapping("/download/{candidateId}")
    public ResponseEntity<Resource> downloadFile(@PathVariable Integer candidateId, HttpServletRequest request) {
        log.info("CvUploadDownloadController-----------------downloadFile---------{}",candidateId,request);
        return cvUploadDownloadService.downloadFile(candidateId, request);
    }
}

