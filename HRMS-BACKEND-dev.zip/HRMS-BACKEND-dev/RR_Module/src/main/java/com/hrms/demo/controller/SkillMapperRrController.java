
package com.hrms.demo.controller;

import com.hrms.demo.dto.request.SkillMapperRrRequest;
import com.hrms.demo.dto.response.SkillMapperRrResponse;

import com.hrms.demo.model.SkillMapperRR;
import com.hrms.demo.repository.SkillMapperRrRepository;
//import com.hrms.demo.service.SkillMapperRrService;
import com.hrms.demo.service.SkillMapperRrService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
@Slf4j
@RestController
@RequestMapping("/api/v1/skillMapper")
public class SkillMapperRrController {
 @Autowired
    private SkillMapperRrService skillMapperRrService;
 @Autowired
 private SkillMapperRrRepository skillMapperRrRepository ;

    @PostMapping("/save")
    public SkillMapperRrResponse saveSkillMapperData(@Valid @RequestBody SkillMapperRrRequest skillMapperRrRequest) {
        System.out.println("skill mapped successfully...");
        log.info("SkillMapperRrController-----saveSkillMapperData----{}",skillMapperRrRequest);
        return skillMapperRrService.createSkillMapperRr(skillMapperRrRequest);

    }

    @GetMapping("/get/{skillMapperId}")
    public SkillMapperRrResponse getSkillMapperById(@PathVariable Integer skillMapperId) {
       // SkillMapperRR skillMapper = skillMapperRrService.getSkillMapperById(id);
        System.out.println("skills list fetched successfully...");
        log.info("SkillMapperRrController-----getSkillMapperById----{}",skillMapperId);
        return this.skillMapperRrService.getSkillMapperById(skillMapperId);
    }
}

