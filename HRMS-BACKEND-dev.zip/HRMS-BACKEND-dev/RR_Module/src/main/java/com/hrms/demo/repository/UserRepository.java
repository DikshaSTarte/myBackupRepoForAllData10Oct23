package com.hrms.demo.repository;

import com.hrms.demo.model.Candidate;
import com.hrms.demo.model.User;
import com.hrms.demo.model.UserType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;
@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
   List<User> findByActive(boolean b);
   Optional <User> findByUsername(String username);
   User findByActiveAndUserId(boolean active, Integer UserId);
    public List<User> findByActive(boolean active,Pageable pageable);
    public List<User> findByActiveAndUserFirstNameContainingIgnoreCaseOrUserLastNameContainingIgnoreCaseOrUserContactContainingIgnoreCaseOrUserEmailIdContainingIgnoreCaseOrUsernameContainingIgnoreCase(boolean active,String key1,String key2,String key3,String key4,String key5,Pageable pageable);
    User findByUserId(Integer id);

    List<User> findByUserType(UserType userType);
    boolean existsByUsername(String username);

  //  boolean existsByUserTypeId(Integer userTypeId);
  boolean existsByUserType_UserTypeId(Integer userTypeId);
    //   boolean existsByUserTypeId(Integer usertypeid);

   User findByActiveAndUserEmailId(boolean b,String userEmailId);


    boolean existsByActiveAndUserContact(boolean b,String userContact);

    List<User> findByActiveAndUserType(boolean b, UserType userType);

    boolean existsByActiveAndUserEmailId(boolean b, String userEmailId);




   /* @Query("SELECT u FROM User u " +

            "WHERE (u.username LIKE :search% " +

            "OR u.userFirstName LIKE :search% " +

            "OR u.userLastName LIKE :search% " +

            "OR u.userContact LIKE :search% " +

            "OR u.userEmailId LIKE :search%) " +

            "AND u.userType.userTypeId != 4")

    List<User> findBySearchTermAndUserTypeNotFour(@Param("search") String searchTerm, Pageable pageable);*/
   @Query("SELECT u FROM User u " +
           "WHERE (u.username LIKE CONCAT(:search, '%') AND u.userType.userTypeId != 4 " +
           "OR u.userFirstName LIKE CONCAT(:search, '%') AND u.userType.userTypeId != 4" +
           "OR u.userLastName LIKE CONCAT(:search, '%') AND u.userType.userTypeId != 4" +
           "OR u.userContact LIKE CONCAT(:search, '%') AND u.userType.userTypeId != 4" +
           " OR (CONCAT(u.userFirstName, ' ', u.userLastName) LIKE CONCAT(:search, '%')) AND u.userType.userTypeId != 4 " +
           "OR u.userEmailId LIKE CONCAT(:search, '%')) AND u.userType.userTypeId != 4" +
           "AND u.active = true")
   List<User> findBySearchTermAndUserTypeUserTypeIdNotFour(@Param("search") String searchTerm, Pageable pageable);

    @Query("SELECT Count(u) FROM User u " +
            "WHERE (u.username LIKE CONCAT(:search, '%')  AND u.userType.userTypeId != 4" +
            "OR u.userFirstName LIKE CONCAT(:search, '%') AND u.userType.userTypeId != 4" +
            "OR u.userLastName LIKE CONCAT(:search, '%') AND u.userType.userTypeId != 4" +
            "OR u.userContact LIKE CONCAT(:search, '%') AND u.userType.userTypeId != 4" +
            "OR u.userEmailId LIKE CONCAT(:search, '%')) AND u.userType.userTypeId != 4" +
            " OR (CONCAT(u.userFirstName, ' ', u.userLastName) LIKE CONCAT(:search, '%')) " +
            "AND u.userType.userTypeId != 4 " +
            "AND u.active = true")
    long  countBySearchTermAndUserTypeUserTypeIdNotFour(@Param("search") String searchTerm);
    long countByActiveAndUserTypeUserTypeIdNot(boolean active, Integer userTypeId);



    Page<User> findByActiveAndUserTypeUserTypeIdNotOrderByUserIdDesc(boolean active, Integer userTypeId, Pageable pageable);



// Page<User> findByActiveOrderByuserIdDesc(boolean active, Pageable pageable);

   // long countByActive(boolean active);

}
