package com.hrms.demo.controller;

import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@RestController
@RequestMapping("/api/vi/file")
public class UploadDownloadController {
    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body("Please select a file to upload.");
        }

        try {
            // Specify the directory where the file will be saved
            String uploadDir ="C:\\Users\\MFSPC004\\Downloads\\UploadFileHrmsFolder\\";

            // Get the file name
            String fileName = StringUtils.cleanPath(file.getOriginalFilename());
            String filePath = uploadDir + "/" + fileName;

            // Save the file to the file system
            File targetFile = new File(filePath);
            file.transferTo(targetFile);

            return ResponseEntity.ok("File uploaded successfully.");
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred while uploading the file.");
        }
    }

    @GetMapping("/download/{fileName:.+}")
    public ResponseEntity<Resource> downloadFile(@PathVariable String fileName, HttpServletRequest request) {
        // Specify the directory where the files are stored
        String uploadDir = "pdf/";
        //String uploadDir = "C:\\Users\\MFSPC004\\Downloads\\UploadFileHrmsFolder\\";
        String filePath = uploadDir + "/" + fileName;

        // Load the file as a resource
        Resource resource = new FileSystemResource(filePath);

        if (resource.exists()) {
            // Determine the file's content type
            String contentType = null;
            try {
                contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
            } catch (IOException e) {
                // Handle the exception
            }

            // Set appropriate headers for the file download
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName);
            headers.add(HttpHeaders.CONTENT_TYPE, contentType != null ? contentType : MediaType.APPLICATION_OCTET_STREAM_VALUE);

            return ResponseEntity.ok()
                    .headers(headers)
                    .body(resource);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
