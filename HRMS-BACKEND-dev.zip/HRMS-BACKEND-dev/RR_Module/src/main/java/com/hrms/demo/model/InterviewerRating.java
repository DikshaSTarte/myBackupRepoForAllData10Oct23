package com.hrms.demo.model;

import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="interviwerRating")
@AllArgsConstructor
@NoArgsConstructor
public class InterviewerRating extends BaseEntity{
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "interviwerRatingId")
  private Integer interviwerRatingId;
  @Column(name = "rateScore")
    private Integer rateScore;
}
