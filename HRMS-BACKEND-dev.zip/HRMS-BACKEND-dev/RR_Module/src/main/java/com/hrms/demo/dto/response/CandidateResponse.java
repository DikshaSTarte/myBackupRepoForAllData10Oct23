package com.hrms.demo.dto.response;

import lombok.*;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CandidateResponse {
    private Integer candidateId;
    private String candidateFirstName;
    private String candidateLastName;
    private String candidateContactNo;
    private String candidateEmail;
    private float candidateExperience;
    private CandidateStatusResponse candidateStatus;
    private String candidateCurrentCompany;
    private float candidateCurrentCtc;
    private float candidateExpectedCtc;
    private float candidateNoticePeriod;
    private List<SkillResponse> skillsId;
    private FileUploadeResponse fileId;
    private boolean negotiableNoticePeriod;
    private int participationInRecruitment;
    private boolean CandidateSelected;


}
