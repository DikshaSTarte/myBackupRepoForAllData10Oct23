package com.hrms.demo.globleexception;

import org.apache.tomcat.util.http.fileupload.impl.SizeLimitExceededException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.RestControllerAdvice;


import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class ExceptionHandler {
    @org.springframework.web.bind.annotation.ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> handleMethodArgsNotValidException(MethodArgumentNotValidException ex) {
        Map<String, String> resp = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String field = ((FieldError) error).getField();
            String msg = error.getDefaultMessage();
            resp.put(field, msg);
        });
        return new ResponseEntity<Map<String, String>>(resp, HttpStatus.BAD_REQUEST);
    }

    @org.springframework.web.bind.annotation.ExceptionHandler(newPasswordAndConformPasswordNotMatchesException.class)
    public ResponseEntity<Map<String, String>> handleMethodArgsNotValidException(newPasswordAndConformPasswordNotMatchesException ex) {

        Map<String, String> map = new HashMap<>();
        map.put("messsage", ex.getMessage());
        return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
    }

    //        @org.springframework.web.bind.annotation.ExceptionHandler(RuntimeException.class)
// public ResponseEntity<Map<String,String>> handleMethodArgsNotValidException (RuntimeException ex){
//
//        Map<String,String > map =new HashMap<>();
//        map.put("messsage",ex.getMessage());
//        return new ResponseEntity<Map<String,String>>(map, HttpStatus.OK);
//    }
    @org.springframework.web.bind.annotation.ExceptionHandler(SizeLimitExceededException.class)
    public ResponseEntity<Map<String, String>> handleMethodArgsNotValidException(SizeLimitExceededException ex) {

        Map<String, String> map = new HashMap<>();
        map.put("messsage", "file should be less than 200kb");
        return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
    }

    @org.springframework.web.bind.annotation.ExceptionHandler(CompanyAlreadyExistsException.class)
    public ResponseEntity<Map<String, String>> handleMethodArgsNotValidException(CompanyAlreadyExistsException ex) {

        Map<String, String> map = new HashMap<>();
        map.put("message", "company already exist");
        return new ResponseEntity<Map<String, String>>(map, HttpStatus.BAD_REQUEST);
    }

      @org.springframework.web.bind.annotation.ExceptionHandler(SkillTypeAlreadyExistException.class)
      public ResponseEntity<Map<String,String>> handleMethodArgsNotValidException (SkillTypeAlreadyExistException ex){

          Map<String,String > map =new HashMap<>();
          map.put("message",ex.getMessage());
          return new ResponseEntity<Map<String,String>>(map, HttpStatus.BAD_REQUEST);
      }
    @org.springframework.web.bind.annotation.ExceptionHandler(SkillSetAlreadyExistException.class)
    public ResponseEntity<Map<String, String>> handleMethodArgsNotValidException(SkillSetAlreadyExistException ex) {

        Map<String, String> map = new HashMap<>();
        map.put("message", "SkillSet Already Exist");
        return new ResponseEntity<Map<String, String>>(map, HttpStatus.BAD_REQUEST);
    }

    @org.springframework.web.bind.annotation.ExceptionHandler(UserAlreadyExistsException.class)
    public ResponseEntity<Map<String, String>> handleMethodArgsNotValidException(UserAlreadyExistsException ex) {

        Map<String, String> map = new HashMap<>();
        map.put("message", ex.getMessage());
        return new ResponseEntity<Map<String, String>>(map, HttpStatus.BAD_REQUEST);
    }

    @org.springframework.web.bind.annotation.ExceptionHandler(InterviewerAlreadyExistException.class)
    public ResponseEntity<Map<String, String>> handleMethodArgsNotValidException(InterviewerAlreadyExistException ex) {

        Map<String, String> map = new HashMap<>();
        map.put("message", ex.getMessage());
        return new ResponseEntity<Map<String, String>>(map, HttpStatus.BAD_REQUEST);
    }

    @org.springframework.web.bind.annotation.ExceptionHandler(CandiateAlredyExistException.class)
    public ResponseEntity<Map<String, String>> handleMethodArgsNotValidException(CandiateAlredyExistException ex) {

        Map<String, String> map = new HashMap<>();
        map.put("message", ex.getMessage());
        return new ResponseEntity<Map<String, String>>(map, HttpStatus.BAD_REQUEST);
    }

    @org.springframework.web.bind.annotation.ExceptionHandler(ObjectNotExistException.class)
    public ResponseEntity<Map<String, String>> handleMethodArgsNotValidException(ObjectNotExistException ex) {

        Map<String, String> map = new HashMap<>();
        map.put("message", ex.getMessage());
        return new ResponseEntity<Map<String, String>>(map, HttpStatus.BAD_REQUEST);
    }

    @org.springframework.web.bind.annotation.ExceptionHandler(UsernameNotFoundException.class)

    public ResponseEntity<Map<String, String>> handleMethodArgsNotValidException(UsernameNotFoundException ex) {

        Map<String, String> map = new HashMap<>();

        map.put("message", ex.getMessage());

        return new ResponseEntity<Map<String, String>>(map, HttpStatus.BAD_REQUEST);

    }

    @org.springframework.web.bind.annotation.ExceptionHandler(BadCredentialsException.class)

    public ResponseEntity<Map<String, String>> handleMethodArgsNotValidException(BadCredentialsException ex) {


        Map<String, String> map = new HashMap<>();

        map.put("message", "Invalid password");

        return new ResponseEntity<Map<String, String>>(map, HttpStatus.BAD_REQUEST);

    }


    @org.springframework.web.bind.annotation.ExceptionHandler(RRAlreadyExistsException.class)

    public ResponseEntity<Map<String,String>> handleMethodArgsNotValidException (RRAlreadyExistsException ex){


        Map<String,String > map =new HashMap<>();

        map.put("message",ex.getMessage());


        return new ResponseEntity<Map<String,String>>(map, HttpStatus.BAD_REQUEST);

    }

}



