package com.hrms.demo.service;

import com.hrms.demo.dto.request.CandidateFeedbackFormRequest;
import com.hrms.demo.dto.request.InterviewerCandidateRequest;
import com.hrms.demo.dto.response.InterviewerCandidateResponse;
import com.hrms.demo.dto.response.InterviewerFeedbackOnCandidateResponse;
import com.hrms.demo.dto.response.InterviewerMapperListResponse;
import com.hrms.demo.model.Interviewer;
import com.hrms.demo.model.InterviewerCandidateMapper;
import com.hrms.demo.model.RRMaster;
import java.util.List;
public interface InterviewerCandidateService {
    InterviewerCandidateResponse saveCandidatesForInterviewer(InterviewerCandidateRequest interviewerCandidateRequest);
    List<InterviewerCandidateResponse> getCandidatesByInterviewerId(Integer interviewerId);
    List<InterviewerCandidateResponse> getAllCandidatesForInterviewer();
    InterviewerFeedbackOnCandidateResponse saveFeedbackForCandidate(CandidateFeedbackFormRequest feedbackFormRequest);
    void deleteCandidateByinterviewerCandidateMapperId(Integer interviewerCandidateMapperId);




   InterviewerMapperListResponse getCandidatesByInterviewerId1(Integer interviewerId, Integer pageNumber, Integer pageSize, String searchTerm);



    // InterviewerMapperListResponse getCandidatesByInterviewerId1(Integer interviewerId, Integer pageNumber, Integer pageSize, String searchTerm);



}
