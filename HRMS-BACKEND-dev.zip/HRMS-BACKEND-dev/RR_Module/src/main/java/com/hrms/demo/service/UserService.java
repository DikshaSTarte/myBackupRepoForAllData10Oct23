
package com.hrms.demo.service;

import com.hrms.demo.dto.request.UserRequest;
import com.hrms.demo.dto.response.CandidateResponse;
import com.hrms.demo.dto.response.UserListResponse;
import com.hrms.demo.dto.response.UserResponse;
import com.hrms.demo.model.User;
//import com.hrms.demo.model.UserVarify;

import java.util.List;
import java.util.Set;

public interface UserService {
  UserResponse saveUser(UserRequest userRequest);
    public String deleteUserById(Integer userId);
    UserResponse getUserById(Integer userId);
    UserResponse updateUser(Integer userId,UserRequest userRequest);
    List<UserResponse> getListOfUsers();
 // public void saveRandomStringForUser(User user);
  //public void sendEmail(String toEmail,String subject,String body);
  public List<UserResponse > getAllUser(Integer pageNumber, String searchKey);

  public List<UserResponse> getUserByUserTypeId(Integer userTypeId);


  public void forgotPassword(String userEmailId);

  boolean verifyOTP(String userEmail, String enteredOTP);

  void resetPassword(String userEmail, String newPassword,String conformPassword);

    UserListResponse getListUsersPg(Integer pageNumber, Integer pageSize, String searchTerm);
}



