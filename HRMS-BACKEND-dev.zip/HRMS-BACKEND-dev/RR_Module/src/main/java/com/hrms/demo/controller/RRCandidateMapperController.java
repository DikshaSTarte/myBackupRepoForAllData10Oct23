package com.hrms.demo.controller;

import com.hrms.demo.dto.request.RRCandidateMapperRequest;
import com.hrms.demo.dto.request.RrFinalCandidateRequest;
import com.hrms.demo.dto.response.CandidateForRrResponse;
import com.hrms.demo.dto.response.RRCandidateMapperResponse;
import com.hrms.demo.dto.response.SelectedCandidateResponse;
import com.hrms.demo.model.RRCandidateMapper;
import com.hrms.demo.model.SelectedCandidateMapper;
import com.hrms.demo.service.RRCandidateMapperService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@Slf4j
@RestController
@RequestMapping("/api/v1/rrCandidateMapper")
public class RRCandidateMapperController {
    @Autowired
    private RRCandidateMapperService rrCandidateMapperService;
    @PostMapping("/save")
    public RRCandidateMapperResponse saveCandidatesForRR(@RequestBody RRCandidateMapperRequest rrCandidateMapperRequest){
        log.info("RRCandidateMapperController------saveCandidatesForRR--{}",rrCandidateMapperRequest);
        return rrCandidateMapperService.saveCandidatesByRrId(rrCandidateMapperRequest);
    }
    @GetMapping("/get/selectedCandidates/{rrId}")
    public List<SelectedCandidateResponse> getListOfSelectedCandidatesByRr(@PathVariable Integer rrId) {
        log.info("RRCandidateMapperController------getListOfSelectedCandidatesByRr--{}",rrId);
        return this.rrCandidateMapperService.getAllSelectedCandidatesByRrId(rrId);
    }
    @PostMapping("/selectedCandidates/save")
    public List<SelectedCandidateMapper> saveSelectedCandidatesForRr(@RequestBody RrFinalCandidateRequest rrFinalCandidateRequest){
        log.info("RRCandidateMapperController------saveSelectedCandidatesForRr--{}",rrFinalCandidateRequest);
        return rrCandidateMapperService.saveSelectedCandidatesByRrId(rrFinalCandidateRequest);
    }

}
