package com.hrms.demo.service;

import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

public interface CvUploadDownloadService {
    ResponseEntity<Object> uploadFile(MultipartFile file) throws IOException;
    ResponseEntity<Resource> downloadFile(Integer candidateId, HttpServletRequest request);
}

