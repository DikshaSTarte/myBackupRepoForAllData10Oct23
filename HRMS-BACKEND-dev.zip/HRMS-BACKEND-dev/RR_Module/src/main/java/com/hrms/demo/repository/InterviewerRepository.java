package com.hrms.demo.repository;

import com.hrms.demo.model.Interviewer;
import com.hrms.demo.model.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface InterviewerRepository extends JpaRepository<Interviewer, Integer> {
    Interviewer findByActiveAndInterviewerId(boolean active, Integer InterviewerId);

    List<Interviewer> findByActive(boolean b);

    public List<Interviewer> findByActive(boolean active,Pageable pageable);

    public List<Interviewer> findByActiveAndInterviewerFirstNameContainingIgnoreCaseOrInterviewerLastNameContainingIgnoreCaseOrInterviewerContactNoContainingIgnoreCaseOrInterviewerEmailContainingIgnoreCase(boolean active,String key1, String key2, String key3, String key4, Pageable pageable);

    Interviewer findByInterviewerId(Integer interviewerId);

    boolean existsByActiveAndInterviewerContactNo(boolean b, String interviewerContactNo);

    boolean existsByActiveAndInterviewerEmail(boolean b, String interviewerEmail);

    Interviewer findByActiveAndUserId(boolean active, User userId);
    /*@Query("SELECT i FROM Interviewer i " +
            "WHERE i.interviewerFirstName LIKE :search% " +
            "OR i.interviewerLastName LIKE :search% " +
            "OR i.interviewerContactNo LIKE :search% " +
            "OR i.interviewerEmail LIKE :search% " +
            "OR i.interviewerExperience LIKE :search%")
    List<Interviewer> findBySearchTerm(@Param("search")String searchTerm, Pageable pageable);
*/
   /* @Query("SELECT i FROM Interviewer i " +
            "WHERE i.active = true AND (" +
            "i.interviewerFirstName LIKE :search% " +
            "OR i.interviewerLastName LIKE :search% " +
            "OR i.interviewerContactNo LIKE :search% " +
            "OR i.interviewerEmail LIKE :search% " +
            "OR i.interviewerExperience LIKE :search%)")
    List<Interviewer> findBySearchTerm(@Param("search") String searchTerm, Pageable pageable);*/


//    @Query("SELECT i FROM Interviewer i " +
//            "WHERE i.active = true AND (" +
//            "(i.interviewerFirstName LIKE :search% OR i.interviewerLastName LIKE :search% " +
//            "OR i.interviewerContactNo LIKE :search% OR i.interviewerEmail LIKE :search% " +
//            "OR i.interviewerExperience LIKE :search%) " +
//            "OR (CONCAT(i.interviewerFirstName, ' ', i.interviewerLastName) LIKE CONCAT(:search, '%')))" +
//            "ORDER BY i.id DESC")
//    List<Interviewer> findBySearchTerm(@Param("search") String searchTerm, Pageable pageable);

    @Query("SELECT i FROM Interviewer i WHERE " +
            "i.active = true AND (" +
            "LOWER(i.interviewerFirstName) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "LOWER(i.interviewerLastName) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "LOWER(i.interviewerContactNo) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "LOWER(i.interviewerEmail) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "LOWER(i.interviewerExperience) LIKE LOWER(CONCAT(:searchTerm, '%'))" +
            "OR CONCAT(LOWER(i.interviewerFirstName), ' ', LOWER(i.interviewerLastName)) LIKE LOWER(CONCAT(:searchTerm, '%'))) " +
            "ORDER BY i.id DESC")
    List<Interviewer> findBySearchTerm(@Param("searchTerm") String searchTerm, Pageable pageable);



    @Query("SELECT COUNT(i) FROM Interviewer i WHERE " +
            "i.active = true AND (" +
            "LOWER(i.interviewerFirstName) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "LOWER(i.interviewerLastName) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "LOWER(i.interviewerContactNo) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "LOWER(i.interviewerEmail) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "LOWER(i.interviewerExperience) LIKE LOWER(CONCAT(:searchTerm, '%'))" +
            "OR CONCAT(LOWER(i.interviewerFirstName), ' ', LOWER(i.interviewerLastName)) LIKE LOWER(CONCAT(:searchTerm, '%'))) "
            )
    long countBySearchTerm(@Param("searchTerm") String searchTerm);


//    @Query("SELECT COUNT(i) FROM Interviewer i " +
//            "WHERE i.active = true AND (" +
//            "(i.interviewerFirstName LIKE :search% OR i.interviewerLastName LIKE :search% " +
//            "OR i.interviewerContactNo LIKE :search% OR i.interviewerEmail LIKE :search% " +
//            "OR i.interviewerExperience LIKE :search%) " +
//            "OR (CONCAT(i.interviewerFirstName, ' ', i.interviewerLastName) LIKE CONCAT(:search, '%')))")
//    long countBySearchTerm(@Param("search") String searchTerm);


    Page<Interviewer> findByActiveOrderByInterviewerIdDesc(boolean active, Pageable pageable);

    long countByActive(boolean active);
    Interviewer findByActiveAndUserId_UserId(boolean b,Integer interviewerId);
}