package com.hrms.demo.mapper;

import com.hrms.demo.dto.response.CandidateStatusResponse;
import com.hrms.demo.model.CandidateStatus;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
@Component
public class CandidateMapper {
    @Autowired
    private ModelMapper modelMapper;
    public CandidateStatusResponse candidateStatusMapper(CandidateStatus candidateStatus){
        CandidateStatusResponse candidateStatusResponse = new CandidateStatusResponse();
        candidateStatusResponse = modelMapper.map(candidateStatus, CandidateStatusResponse.class);
        return candidateStatusResponse;
    }
    public List<CandidateStatusResponse> candidateStatusListMapper(List<CandidateStatus> candidateStatuses){
        List<CandidateStatusResponse> dtos = candidateStatuses
                .stream()
                .map(user -> modelMapper.map(user, CandidateStatusResponse.class))
                .collect(Collectors.toList());
        return dtos;
    }
}
