package com.hrms.demo.serviceImpl;

import com.hrms.demo.dto.response.CompanyListResponse;
import com.hrms.demo.dto.response.GenericResponseDTO;
import com.hrms.demo.globleexception.CompanyAlreadyExistsException;
import com.hrms.demo.globleexception.RRAlreadyExistsException;
import com.hrms.demo.mapper.CompanyMapper;
import com.hrms.demo.model.RRMaster;
import com.hrms.demo.repository.CompanyRepository;
import com.hrms.demo.dto.request.CompanyRequest;
import com.hrms.demo.dto.response.CompanyResponse;
import com.hrms.demo.model.Company;
import com.hrms.demo.repository.RRMasterRepository;
import com.hrms.demo.service.CompanyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Slf4j
@Service
public class CompanyServiceImpl implements CompanyService {
    @Autowired
    private CompanyRepository companyRepository;
    @Autowired
    private RRMasterRepository rrMasterRepository;
    @Autowired
    private CompanyMapper companyMapper;
    CompanyResponse companyEntityToCompanyResponse(Company company){
        CompanyResponse companyResponse= new CompanyResponse();
        companyResponse.setCompanyId(company.getCompanyId());
        companyResponse.setCompanyName(company.getCompanyName());
        companyResponse.setCompanyId(company.getCompanyId());
        return companyResponse;
    }
    @Override
    public GenericResponseDTO saveCompany(CompanyRequest companyRequest) throws CompanyAlreadyExistsException {
        log.info("CompanyServiceImpl-------------saveCompany--------{}",companyRequest);
        Optional<Company> existingCompany = companyRepository.findByActiveAndCompanyName(true,companyRequest.getCompanyName());
        if (existingCompany.isPresent()) {
            throw new CompanyAlreadyExistsException("Company already exists.");
        }
        Company company = new Company();
        company.setCompanyName(companyRequest.getCompanyName());
        Company save = this.companyRepository.save(company);

        return new GenericResponseDTO(save.getCompanyId());
    }
    @Override
    public String deleteCompanyById(Integer companyId) {
        log.info("CompanyServiceImpl-------------deleteCompanyById--------{}",companyId);
        Optional<Company> company= companyRepository.findById(companyId);

        List<RRMaster> rrMasterList = rrMasterRepository.findDistinctRrMastersByCompanyAndActiveIsTrue(company.get());

        if (rrMasterList.size()>0){
            if(rrMasterList.size()==1)
                throw new RRAlreadyExistsException( " RR with the company "+company.get().getCompanyName()+"  already exists ");
            else
                throw new RRAlreadyExistsException( rrMasterList.size()+" RRs with the company "+company.get().getCompanyName()+"  already exists ");

        }
        company.get().setActive(false);
        companyRepository.save(company.get());
        return "Success";
    }
    @Override
    public CompanyResponse getCompanyById(Integer companyId) {
        log.info("CompanyServiceImpl-------------getCompanyById--------{}",companyId);
        Company company= companyRepository.findByActiveAndCompanyId(true,companyId);
//        CompanyResponse companyResponse=new CompanyResponse();
//        companyResponse.setCompanyId(company.getCompanyId());
//        companyResponse.setCompanyName(company.getCompanyName());
        CompanyResponse companyResponse = companyMapper.companyMapper(company);
        return companyResponse;
    }
    @Override
    public CompanyResponse updateCompany(Integer companyId, CompanyRequest companyRequest) {
        log.info("CompanyServiceImpl-------------updateCompany--------{}",companyId,companyRequest);
        Company company=companyRepository.findByActiveAndCompanyId(true,companyId);
        company.setCompanyName(companyRequest.getCompanyName());
        Company update=this.companyRepository.save(company);
//        CompanyResponse companyResponse = companyEntityToCompanyResponse(update);
        CompanyResponse companyResponse = companyMapper.companyMapper(company);
        return companyResponse;
    }
    @Override
    public List<CompanyResponse> getListCompany() {

        List<Company> companies = companyRepository.findByActive(true);
//        List<CompanyResponse> companyResponseList= new ArrayList<>();
        //Use model mapper -- refer candidate status list API
//        for (Company company:companies) {
//            companyResponseList.add(companyEntityToCompanyResponse(company));
//
//        }
//        return companyResponseList;
        return companyMapper.companyListMapper(companies);
    }
    @Override
    public List<CompanyResponse> getAllCompany(Integer pageNumber, String searchKey) {
        Pageable pageable= PageRequest.of(pageNumber,7);
        if(searchKey.equals("")){
            List<Company> all1= companyRepository.findByActive(true,pageable);
            List<CompanyResponse> companyResponseList1 = new ArrayList<>();
            for (Company company: all1){
                companyResponseList1.add(companyEntityToCompanyResponse(company));
            }
            return companyResponseList1;
        }else {
            List<Company> all2= companyRepository.findByActiveAndCompanyNameContainingIgnoreCase(true,searchKey,pageable);

            List<CompanyResponse> companyResponseList2 = new ArrayList<>();
            for (Company company: all2){
                companyResponseList2.add(companyEntityToCompanyResponse(company));
            }
            return companyResponseList2;
        }
   }
    @Override
    public Page<Company> searchCompany(String searchKeyword, int pageNo, int pageSize) {
        Pageable pageable = PageRequest.of(pageNo, pageSize);
        return companyRepository.findAllByActiveAndCompanyNameIgnoreCaseStartingWithOrderByCompanyIdDesc(true,searchKeyword,pageable);
    }
    @Override
    public CompanyListResponse getListCompanyOp(Integer pageNumber, Integer pageSize, String searchTerm) {
        log.info("CompanyServiceImpl--------------getListCompanyOp-------{}",pageNumber,pageSize,searchTerm);

        List<Company> allCompanies;
        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        long totalCompany;
        if (searchTerm != null && !searchTerm.isEmpty()) {
            //Bring count based on search records instead of allCompanies.size()
            allCompanies = companyRepository.findBySearchTerm(searchTerm, pageable);
            totalCompany = allCompanies.size(); // Get the count from the list size
        } else {
            Page<Company> companyPage = companyRepository.findByActiveOrderByCompanyIdDesc(true,pageable);
            allCompanies = companyPage.getContent();
            totalCompany = companyRepository.countByActive(true); // Get the total count separately
        }
        List<CompanyResponse> companyResponseList = new ArrayList<>();
        for (Company company : allCompanies) {
            //Use mapper here
            companyResponseList.add(companyEntityToCompanyResponse(company));
        }
        System.out.println("Total company: " + totalCompany);
        log.info("CompanyServiceImpl--------------getListCompanyOp-------{}",pageNumber,pageSize,searchTerm);
        return new CompanyListResponse(totalCompany, companyResponseList);
    }
}
