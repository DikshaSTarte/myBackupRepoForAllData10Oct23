package com.hrms.demo.constants;

public class ConstantsForApis {
    public static final String PREFIX = "/api/v1/";
    public static final String SKILL = "skill/";
    public static final String SKILL_TYPE = "skillType";
    public static final String SKILL_BY_ID = "{id}";

}
