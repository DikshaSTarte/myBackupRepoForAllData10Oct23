
package com.hrms.demo.dto.response;

import com.hrms.demo.model.RRMaster;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Data
@NoArgsConstructor
@AllArgsConstructor

public class RrListByOwnerResponse {
    private long allRrListByOwnerId;
    private List<RrResponse> rrMasterList12;
}

