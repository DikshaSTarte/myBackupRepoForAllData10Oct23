
package com.hrms.demo.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.persistence.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "skills")
public class SkillEntity extends BaseEntity {

   /* @Id
    @GeneratedValue(strategy = GenerationType.AUTO)*/
   @Id
   @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "skills_generator")
   @SequenceGenerator(name = "skills_generator", sequenceName = "skills_SEQUENCE", initialValue = 4390, allocationSize = 1)
    @Column(name = "skills_id")
    private Integer id;

   @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "skill_type_id")
   private SkillTypeEntity skillType;

    @Column(name = "skill_set")
    private String skillSet;
}
