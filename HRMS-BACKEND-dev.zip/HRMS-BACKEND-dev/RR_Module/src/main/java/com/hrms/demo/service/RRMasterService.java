package com.hrms.demo.service;

import com.hrms.demo.dto.request.CreateRrRequest;
import com.hrms.demo.dto.request.RRMasterRequest;
import com.hrms.demo.dto.request.RrFilterRequest;
import com.hrms.demo.dto.response.*;
import com.hrms.demo.model.Candidate;
import com.hrms.demo.model.RRMaster;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.util.Set;

public interface RRMasterService {
    RRMasterResponse createRRMaster(CreateRrRequest createRrRequest);
    RrResponse getRRMasterById(Integer id);
    void deleteRRMasterById(Integer id);
    RrUpdateResponse updateRRMasterById(Integer id,RRMasterRequest rrMasterRequest);
    List<RRMasterResponse> getAllRRMaster();
    List<CandidateForRrResponse> getAllCandidatesByRrId(Integer rrId);
    List<RrResponse> getRRByOwnerId(Integer ownerId);

    RRlistResponse getAllRRMasterPg(Integer pageNumber, Integer pageSize, String searchTerm,List<String> companyNames, List<String> userRoles, List<String> ownerRoles, List<String> ownerNames);

    RRlistResponse getAllRRMasterPg(Integer pageNumber, Integer pageSize, String searchTerm, RrFilterRequest rrFilterRequest);
    CandidateListResponseForRR getAllCandidatesByRrIdPg(Integer rrId,Integer pageNumber, Integer pageSize, String sortBy, String sortDir, String searchTerm);

  //  public List<RRMasterResponse> getFilteredData(List<String> companyNames, List<String> userRoles, List<String> ownerRoles, List<String> ownerNames);

    public RRlistResponse getAllRRMasterPgx(Integer pageNumber, Integer pageSize, String searchTerm, RrFilterRequest rrFilterRequest);
    RrListByOwnerResponse getRRByOwnerIdPagination(Integer ownerId, Integer pageNumber, Integer pageSize, String searchTerm,RrFilterRequest rrFilterRequest);

//    public RrListByOwnerResponse getRRByOwnerIdPagination(Integer ownerId, RrFilterRequest rrFilterRequest);


    Set<OwnerResponse> getListOfOwners();
}

