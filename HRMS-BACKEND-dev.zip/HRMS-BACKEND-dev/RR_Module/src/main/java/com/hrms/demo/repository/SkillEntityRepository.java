package com.hrms.demo.repository;

import com.hrms.demo.dto.response.SkillResponse;
import com.hrms.demo.model.Candidate;
import com.hrms.demo.model.Company;
import com.hrms.demo.model.SkillEntity;
import com.hrms.demo.model.SkillTypeEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface SkillEntityRepository extends JpaRepository<SkillEntity, Integer> {

    SkillEntity findByActiveAndId(boolean active, Integer skillsId);

    List<SkillEntity> findByActiveAndIdIn(boolean active, List<Integer> skillsId);

    List<SkillEntity> findByActive(boolean b);

    Optional<SkillEntity> findByActiveAndSkillType_skillTypeName(boolean b,String skillType);

    Optional<SkillEntity> findByActiveAndSkillSetAndSkillType_skillTypeName(boolean b,String skillSet, String skillTypeName);

    Optional<SkillEntity> findByActiveAndSkillSet(boolean b, String skillSet);

    @Query("SELECT s FROM SkillEntity s " +
            "WHERE (s.skillSet LIKE :search% OR s.skillType.skillTypeName LIKE :search%) " +
            "AND s.active = true")
    List<SkillEntity> findBySearchTermAndActive(@Param("search") String searchTerm, Pageable pageable);
    Page<SkillEntity> findByActiveOrderByIdDesc(boolean active, Pageable pageable);
    long countByActive(boolean active);
    List<SkillEntity> findByActiveAndSkillType(boolean b, SkillTypeEntity skillTypeEntity);

}
