package com.hrms.demo.controller;
import com.hrms.demo.dto.request.InterviewerFeedbackRequest;
import com.hrms.demo.dto.response.InterviewerFeedbackResponse;
import com.hrms.demo.service.InterviewerFeedbackService;
import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@Slf4j
@RestController
@RequestMapping("/api/v1/interviewerFeedback")
public class InterviewerFeedbackController {
    @Autowired
    private InterviewerFeedbackService interviewerFeedbackService;
    @PostMapping("/save")
    public InterviewerFeedbackResponse SaveInterviewerFdbkData(@Valid @RequestBody InterviewerFeedbackRequest interviewerFeedbackRequest){
        log.info("InterviewerFeedbackController------SaveInterviewerFdbkData--{}",interviewerFeedbackRequest);
        return interviewerFeedbackService.saveInterviewerFeedback(interviewerFeedbackRequest);

    }
    @DeleteMapping("/delete/{interviewerFdbkId}")
    public ResponseEntity<Void> deleteInterviewerFeedbackData(@PathVariable Integer interviewerFdbkId){
        interviewerFeedbackService.deleteInterviewerFeedbackById(interviewerFdbkId);
        log.info("InterviewerFeedbackController------deleteInterviewerFeedbackData--{}",interviewerFdbkId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/list")
    public List<InterviewerFeedbackResponse> getShowListInterviewerFdbk() {
        log.info("InterviewerFeedbackController------getShowListInterviewerFdbk--{}");
        return this.interviewerFeedbackService.getListInterviewerFeedback();
    }


    @GetMapping("/get/{interviewerFdbkId}")
    public InterviewerFeedbackResponse getInterviewerFdbkById(@PathVariable Integer interviewerFdbkId){
        log.info("InterviewerFeedbackController------getInterviewerFdbkById--{}",interviewerFdbkId);
        return this.interviewerFeedbackService.getInterviewerFeedbackById(interviewerFdbkId);
    }
    @PutMapping("/update/{interviewerFdbkId}")
    public ResponseEntity<InterviewerFeedbackResponse> updateInterviewerFdbkData(@Valid @PathVariable Integer interviewerFdbkId ,@RequestBody InterviewerFeedbackRequest interviewerFeedbackRequest ){
        InterviewerFeedbackResponse interviewerFeedbackResponse=interviewerFeedbackService.updateInterviewerFeedback(interviewerFdbkId,interviewerFeedbackRequest);
        if(interviewerFeedbackResponse!=null){
            log.info("InterviewerFeedbackController------updateInterviewerFdbkData--{}",interviewerFdbkId,interviewerFeedbackRequest);
            return ResponseEntity.ok(interviewerFeedbackResponse);
        }else {
            log.error("InterviewerFeedbackController------updateInterviewerFdbkData--{}",interviewerFdbkId,interviewerFeedbackRequest,"updateInterviewerFeedbackData failed");
            return ResponseEntity.notFound().build();
        }
    }
}
