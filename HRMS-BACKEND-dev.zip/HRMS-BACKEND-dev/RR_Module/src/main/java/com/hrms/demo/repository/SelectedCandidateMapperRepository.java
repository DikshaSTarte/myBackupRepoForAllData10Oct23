package com.hrms.demo.repository;

import com.hrms.demo.model.Candidate;
import com.hrms.demo.model.RRMaster;
import com.hrms.demo.model.SelectedCandidateMapper;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface SelectedCandidateMapperRepository extends JpaRepository<SelectedCandidateMapper,Integer> {
    List<SelectedCandidateMapper> findByActiveAndRrId(boolean b, RRMaster rrId);

    List<Candidate> findCandidateIdByActiveAndRrId(boolean b, RRMaster rrMaster);

    @Query("SELECT DISTINCT scm.candidateId FROM SelectedCandidateMapper scm WHERE scm.active = true AND scm.rrId = :rrId")
    List<Candidate> findDistinctCandidateIdsByRrId(@Param("rrId") RRMaster rrId);

    Integer countByActiveAndRrId(boolean b, RRMaster rrMaster);
}