package com.hrms.demo.dto.response;

import lombok.*;
@Getter
@Setter
@AllArgsConstructor
public class DashboardCountDTO {
    private Long count;
    private Integer companyId;
}
