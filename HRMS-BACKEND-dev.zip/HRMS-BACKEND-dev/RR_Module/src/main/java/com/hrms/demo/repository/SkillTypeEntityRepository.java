package com.hrms.demo.repository;

import com.hrms.demo.model.Candidate;
import com.hrms.demo.model.SkillTypeEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface SkillTypeEntityRepository extends JpaRepository<SkillTypeEntity,Integer> {
    SkillTypeEntity findBySkillTypeName(String skillTypeName);

      // List<SkillTypeEntity> findByCategory(String category);
    List<SkillTypeEntity> findByActive(boolean b);
    Optional<SkillTypeEntity> findByActiveAndSkillTypeName(boolean b,String skillTypeName);
  //  Page<SkillTypeEntity> findByActiveAndSkillTypeNameIgnoreCaseStartingWith(boolean b,String skillTypeName, Pageable pageable);

    Page<SkillTypeEntity> findByActiveAndSkillTypeNameIgnoreCaseStartingWithOrderByIdDesc(boolean b, String searchKeyword, Pageable pageable);

    Page<SkillTypeEntity> findByActiveOrderByIdDesc(boolean Active, Pageable pageable);
  /*  @Query("SELECT c FROM SkillTypeEntity c WHERE " +
            "LOWER(c.id) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
            "LOWER(c.skillTypeName) LIKE LOWER(CONCAT('%', :searchTerm, '%'))")*/
  @Query("SELECT c FROM SkillTypeEntity c WHERE " +
          "LOWER(c.id) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
          "LOWER(c.skillTypeName) LIKE LOWER(CONCAT(:searchTerm, '%'))"+
          "AND c.active = true " +
          "ORDER BY c.id DESC")
    List<SkillTypeEntity> findBySearchTermAndActive(String searchTerm, Pageable pageable);
    long countByActive(boolean active);

    Optional<SkillTypeEntity> findByActiveAndId(boolean b, Integer skillTypeId);
}
