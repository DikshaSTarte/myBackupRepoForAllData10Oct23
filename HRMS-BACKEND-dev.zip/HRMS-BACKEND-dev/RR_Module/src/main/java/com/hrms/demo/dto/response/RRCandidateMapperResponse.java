package com.hrms.demo.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RRCandidateMapperResponse {
  //  private Integer rrCandidateMapperId;
    private Integer rrId;
    private List<Integer> candidateId;
}
