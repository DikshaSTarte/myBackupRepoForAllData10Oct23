package com.hrms.demo.controller;

import com.hrms.demo.dto.request.ResetPassRequest;
import com.hrms.demo.dto.response.PasswordResetResponse;
import com.hrms.demo.model.User;
import com.hrms.demo.repository.UserRepository;
import com.hrms.demo.service.ResetService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpSession;
@Slf4j
@RestController
@RequestMapping("/api/v1/")
public class PasswordResetController {
    @Autowired
    private ResetService resetService;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UserRepository usersRepository;

    @PutMapping("/reset-password")
    @ResponseBody
    public PasswordResetResponse handlePasswordReset(@RequestBody ResetPassRequest resetPassRequest,
                                                     HttpSession session) {
        log.info("PasswordResetController------------handlePasswordReset-------------{}",resetPassRequest);

        String newPassword= resetPassRequest.getNewPassword();
        String confirmPassword=resetPassRequest.getConfirmPassword();
        String currentPassword=resetPassRequest.getCurrentPassword();

// Check if the new password meets the password policy
        if (!isPasswordValid(newPassword)) {
            return new PasswordResetResponse(false, "Password must be at least 8 characters long and contain at least one letter, one number, and one special character.");
        }

// Check if the new password and confirmation password match
        if (!newPassword.equals(confirmPassword)) {
            return new PasswordResetResponse(false, "New password and confirmation password do not match.");
        }

// Check if the current password is correct (you'll need to implement this method)
        if (!isCurrentPasswordCorrect(currentPassword)) {
            return new PasswordResetResponse(false, "Current password is incorrect.");
        }

// Reset the password (you'll need to implement this method)
        resetUserPassword(newPassword);

// Invalidate the user's session
        session.invalidate();

// Return the success response
        return new PasswordResetResponse(true, "Password reset successfully.");
    }


    private void resetUserPassword(String newPassword) {

// Get the current user's username
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = auth.getName();

// Update the stored password with the new password
        resetService.updatePassword(username, newPassword);
    }

    private boolean isCurrentPasswordCorrect(String currentPassword) {
//Check if the current password matches the stored password
//String storedPassword = "password123"; // Replace with actual stored password
//return currentPassword.equals(storedPassword);

// Get the current user's username
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = auth.getName();
        System.out.println(username);

// Retrieve the user's password from the database using your authentication system
        User userDetails = resetService.findByUsername(username);
        String storedPassword = userDetails.getPassword();
        System.out.println(storedPassword);
        System.out.println();

        System.out.println(userDetails.getPassword());

// Check if the current password matches the stored password
        return passwordEncoder.matches(currentPassword, storedPassword);

    }

    private boolean isPasswordValid(String newPassword) {

// Password must be at least 8 characters long and contain at least one letter, one number, and one special character
        String pattern = "^(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$";
        return newPassword.matches(pattern);
    }

}
