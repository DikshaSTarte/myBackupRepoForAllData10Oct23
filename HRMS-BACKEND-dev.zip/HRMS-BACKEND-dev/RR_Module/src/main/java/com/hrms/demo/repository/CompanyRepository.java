package com.hrms.demo.repository;
import com.hrms.demo.dto.response.CompanyResponse;
import com.hrms.demo.model.Candidate;
import com.hrms.demo.model.Company;
import com.hrms.demo.model.SkillTypeEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface CompanyRepository extends JpaRepository<Company,Integer> {
      Company findByActiveAndCompanyId(boolean active, Integer CompanyId);
    List<Company> findByActive(boolean b);
    public List<Company> findByActive(boolean active,Pageable pageable);
    public List<Company> findByActiveAndCompanyNameContainingIgnoreCase(boolean active,String key1,Pageable pageable);
    Company findByCompanyId(Integer companyId);

    Optional<Company> findByActiveAndCompanyName(boolean b,String companyName);
  //  List<CompanyResponse> findAllByActiveAndCompanyNameIgnoreCaseStartingWithOrderByCompanyIdDesc(boolean b, String searchKeyword, Pageable pageable);

    //  Page<Company> findByActiveAndCompanyNameIgnoreCaseStartingWith(boolean b, String searchKeyword, Pageable pageable);
  // Page<Company> findAllByActiveAndCompanyNameIgnoreCaseStartingWithOrderByCompanyIdDesc(boolean b, String searchKeyword, int pageNo, int pageSize);
    Page<Company> findAllByActiveAndCompanyNameIgnoreCaseStartingWithOrderByCompanyIdDesc(boolean b, String searchKeyword, Pageable pageable);

   /* @Query("SELECT c FROM Company c WHERE " +
            "LOWER(c.companyId) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "LOWER(c.companyName) LIKE LOWER(CONCAT(:searchTerm, '%'))"+
            "ORDER BY c.id DESC")
    List<Company> findBySearchTerm(String searchTerm, Pageable pageable);*/
    @Query("SELECT c FROM Company c WHERE " +
           "c.active = true AND " +
//           "(LOWER(c.companyId) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
           "LOWER(c.companyName) LIKE LOWER(CONCAT(:searchTerm, '%')) " +
           "ORDER BY c.id DESC")
    List<Company> findBySearchTerm(String searchTerm, Pageable pageable);

    Page<Company> findByActiveOrderByCompanyIdDesc(boolean Active, Pageable pageable);
    long countByActive(boolean active);
    @Query("SELECT new com.hrms.demo.dto.response.CompanyResponse( c.companyId,c.companyName) FROM Company c WHERE c.active = true ")
    List<CompanyResponse> getCompanyIds();
}
