
package com.hrms.demo.model;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "skill_type")
public class SkillTypeEntity extends BaseEntity
{

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "skill_type_generator")
    @SequenceGenerator(name = "skill_type_generator", sequenceName = "skill_type_SEQUENCE", initialValue = 4389, allocationSize = 1)
    @Column(name = "skill_type_id")
    private Integer id;
    private String skillTypeName;
    @OneToMany(mappedBy = "skillType", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("skillType")
    private List<SkillEntity> skills;
}

