package com.hrms.demo.dto.request;

import javax.validation.constraints.*;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Range;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CandidateRequest {

    @NotBlank(message = "CandidateFirstName must not be blank.")
    @Pattern(regexp = "^[a-zA-Z ]+$", message = "CandidateFirstName can only contain letters and spaces.")
    private String candidateFirstName;

    @NotBlank(message = "CandidateLastName must not be blank.")
    @Pattern(regexp = "^[a-zA-Z ]+$", message = "CandidateLastName can only contain letters and spaces.")
    private String candidateLastName;

    @NotBlank(message = "Candidate contact number is required")
    @Pattern(regexp = "\\d{10}", message = "Candidate contact number must be a 10-digit number")
    private String candidateContactNo;

    @NotBlank(message = "Candidate email must not be blank.")
    @Email(message = "Candidate email is not valid.")
   // @Email(message = "Candidate email is not valid.",regexp = "[a-z0-9]+@[a-z]+\\.[a-z]{2,3}")
    private String candidateEmail;

    @NotNull
    @Min(value = 0, message = "Candidate experience must be greater than or equal to 0.")
    private float candidateExperience;

    @NotNull
    @Range(min = 1, max = 4, message = "Candidate status must be between 1 and 4.")
    private int candidateStatus;

    @NotBlank(message = "Candidate current company must not be blank.")
    @Pattern(regexp = "^[a-zA-Z ]*$", message = "Candidate current company can only contain letters and spaces.")
    private String candidateCurrentCompany;

    @NotNull
    @Min(value = 0, message = "Candidate current CTC must be greater than or equal to 0.")
    private float candidateCurrentCtc;

    @NotNull
    @Min(value = 0, message = "Candidate expected CTC must be greater than or equal to 0.")
    private float candidateExpectedCtc;

    @NotNull
    @Min(value = 0, message = "Candidate notice period must be greater than or equal to 0.")
    private float candidateNoticePeriod;

    private List<Integer> skillsId;

    private Integer fileId=0;
    private boolean negotiableNoticePeriod;

}
