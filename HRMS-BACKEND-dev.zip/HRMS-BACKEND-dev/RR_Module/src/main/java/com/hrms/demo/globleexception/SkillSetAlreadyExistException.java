package com.hrms.demo.globleexception;

public class SkillSetAlreadyExistException extends Throwable {
    public SkillSetAlreadyExistException(String skillSetAlreadyExistException) {

    }
}
