package com.hrms.demo.controller;

import com.hrms.demo.globleexception.fileSizeGraterThanMaxLimit;
import com.hrms.demo.model.FileUploade;
import com.hrms.demo.model.RRMaster;
import com.hrms.demo.repository.FileUploadeRepository;
import com.hrms.demo.repository.RRMasterRepository;
import com.hrms.demo.service.JobDescriptionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/jobdescription")

public class JobDescriptionController {

    @Autowired
    private JobDescriptionService jobDescriptionService;

    @PostMapping("/uploadFile")
    public ResponseEntity<Object> uploadFile(@RequestParam("File") MultipartFile file) throws IOException {
        log.info("JobDescriptionController------uploadFile--{}", file);
        return jobDescriptionService.uploadFile(file);
    }

    @GetMapping("/download/{rrMasterId}")
    public ResponseEntity<Resource> downloadFile(@PathVariable Integer rrMasterId, HttpServletRequest request) {
        log.info("JobDescriptionController------downloadFile--{}", rrMasterId, request);
        return jobDescriptionService.downloadFile(rrMasterId, request);
    }

}