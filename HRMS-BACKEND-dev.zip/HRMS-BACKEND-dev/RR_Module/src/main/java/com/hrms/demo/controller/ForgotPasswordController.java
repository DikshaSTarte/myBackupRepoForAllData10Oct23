package com.hrms.demo.controller;

import com.hrms.demo.dto.request.UserRequest;
import com.hrms.demo.globleexception.UserNotFoundException;
import com.hrms.demo.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
@Slf4j
@RestController
@RequestMapping("/forgot")

public class ForgotPasswordController {
    @Autowired
    private UserService userService;
    @PostMapping("/forgot-password")
    public ResponseEntity<Map<String, String>> forgotPassword(@RequestBody UserRequest userRequest) {
        log.info("ForgotPasswordController--------------forgotPassword-------------{}",userRequest);
        String userEmailId=userRequest.getUserEmailId();
        // System.out.println("its updated code");
        userService.forgotPassword(userEmailId);
        Map<String, String> response = new HashMap<>();
        response.put("message", "OTP send to email successfully");
        log.info("ForgotPasswordController------forgotPassword--{}",userRequest);
        return ResponseEntity.ok(response);
       // return ResponseEntity.ok("OTP send to email successfully");

    }

    @PostMapping("/verify-otp")
    public ResponseEntity<Map<String, String>> verifyOTP(@RequestBody UserRequest userRequest) {
        log.info("ForgotPasswordController--------------verifyOTP-------------{}",userRequest);
        String userEmailId=userRequest.getUserEmailId();
        String otp=userRequest.getOtp();
        try {
            boolean otpValid = userService.verifyOTP(userEmailId,otp);
            if (otpValid) {
                // OTP is valid, perform further actions or return success response
                Map<String, String> response = new HashMap<>();
                response.put("message", "OTP verified successfully.Proceed with password reset.");
               // return ResponseEntity.ok("OTP verified successfully.Proceed with password reset.");
                log.info("ForgotPasswordController------verifyOTP--{}",userRequest);
                return ResponseEntity.ok(response);
            } else {
                Map<String, String> response1 = new HashMap<>();
                response1.put("message", "Invalid OTP.");
                // Invalid OTP
               // return ResponseEntity.badRequest().body("Invalid OTP.");
                log.error("ForgotPasswordController------verifyOTP--{}",userRequest,"invalid otp");
              //  return ResponseEntity.ok(response1);
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response1);
            }
        } catch (UserNotFoundException e) {
            // User not found
            Map<String, String> response2 = new HashMap<>();
            response2.put("message",e.getMessage());
            //return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
            log.error("ForgotPasswordController----------verifyOTP------{}",e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response2);
        } catch (Exception e) {
            // Other errors
            Map<String, String> response3 = new HashMap<>();
            response3.put("message","An error occurred while processing your request.");
           // return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred while processing your request.");
            //return ResponseEntity.ok(response3);
            log.error("ForgotPasswordController----------verifyOTP------{}",e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response3);
        }
        }


    @PostMapping("/reset-password/initiallyLogin")
    public ResponseEntity<Map<String, String>> resetPassword(@RequestBody UserRequest userRequest) {
        log.info("ForgotPasswordController--------------resetPassword-------------{}",userRequest);
        String userEmailId=userRequest.getUserEmailId();
        String newPassword=userRequest.getNewPassword();
        String conformPassword=userRequest.getConformPassword();
        userService.resetPassword(userEmailId, newPassword,conformPassword);

        Map<String, String> response4 = new HashMap<>();
        response4.put("message", "Password reset successfully.");
       // return ResponseEntity.ok("Password reset successfully.");
        log.info("ForgotPasswordController------resetPassword--{}",userRequest);
        return ResponseEntity.ok(response4);
    }
}
