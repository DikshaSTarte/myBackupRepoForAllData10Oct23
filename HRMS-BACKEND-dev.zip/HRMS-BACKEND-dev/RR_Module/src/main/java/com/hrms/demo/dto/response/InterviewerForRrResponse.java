package com.hrms.demo.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class InterviewerForRrResponse {
    private Integer interviewerId;
    private String interviewerFirstName;
    private String interviewerLastName;
    private String interviewerEmail;
}
