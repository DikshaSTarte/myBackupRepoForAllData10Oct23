package com.hrms.demo.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RCResponse {
    private String customerName;
    private Integer customerId;
    private Long redCount;
    private Long yellowCount;
    private Long greenCount;
}
