package com.hrms.demo.service;
import com.hrms.demo.dto.request.InterviewerRatingRequest;
import com.hrms.demo.dto.response.InterviewerRatingResponse;
import java.util.List;

public interface InterviewerRatingService {
    InterviewerRatingResponse saveInterviewerRating(InterviewerRatingRequest interviewerRatingRequest);
    public String deleteInterviewerRatingById(Integer interviwerRatingId);
    InterviewerRatingResponse getInterviewerRatingById(Integer interviwerRatingId);
    InterviewerRatingResponse updateInterviewerRating(Integer interviwerRatingId,InterviewerRatingRequest interviewerRatingRequest);
    List<InterviewerRatingResponse> getListInterviewerRating();
}
