
package com.hrms.demo.schedular;

import com.hrms.demo.model.BaseEntity;
import com.hrms.demo.model.Email;
import com.hrms.demo.repository.EmailRepository;
import com.hrms.demo.serviceImpl.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.List;
import java.util.Properties;

@Component
@EnableScheduling
public class UserEmailSchedule extends BaseEntity {
    @Autowired
    private EmailRepository emailRepository;

    @Autowired
    private UserServiceImpl userServiceImpl;

    @Value("${spring.mail.username}")
    private String mailUserName;
    @Value("${spring.mail.password}")
    private String mailPassword;
    //@Scheduled(fixedRate = 3000) // Run every minute, you can adjust the interval as needed
//    @Async
//    @Transactional
    @Scheduled(cron = "0 * * * * *") // Run every minute, you can adjust the interval as needed
    public void processUnsentEmails() {
        List<Email> unsentEmails = emailRepository.findByIsSendEmail(false);

     //   System.out.println("Schedus");
        for (Email email : unsentEmails) {
            System.out.println("Mail SEND "+ email.getEmailId());
            try {
                sendPasswordToUserEmail(email.getMessage(), email.getEmailId(),email.getSubjectMessage());
             //   sendPasswordToUserEmail(email.getMessage(), email.getEmailId(),email.getSubjectMessage());

                email.setIsSendEmail(true);
                emailRepository.save(email);

            } catch (MessagingException e) {
                // Handle the exception, log or throw as needed
                e.printStackTrace();
            }
        }
    }

    public void sendPasswordToUserEmail(String messageBody,String email,String subjectMessage) throws MessagingException {
        Properties properties = new Properties();
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587");
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");

        String username =mailUserName;
        char[] password1 =mailPassword.toCharArray();

        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                String password = new String(password1);
                return new PasswordAuthentication(username, password);
            }

        });
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(username));

        message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(email));
        message.setSubject(subjectMessage);
        String emailBody = messageBody;
        message.setText(emailBody);
        Transport.send(message);

    }
}

