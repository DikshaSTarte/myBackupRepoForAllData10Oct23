package com.hrms.demo.controller;

import com.hrms.demo.dto.request.EmailRequest;
import com.hrms.demo.serviceImpl.EmailSenderServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/v1/interviews")
public class EmailController {
    @Autowired
    private EmailSenderServiceImpl interviewService;

    @PostMapping("/schedule")
    public ResponseEntity<String> scheduleInterview(@RequestBody EmailRequest request) {
        log.info("EmailController------scheduleInterview--{}", request);
        interviewService.scheduleInterview(request);
        return ResponseEntity.ok("Interview scheduled successfully.");
    }
}



