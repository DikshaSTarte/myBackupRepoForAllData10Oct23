package com.hrms.demo.repository;

import com.hrms.demo.model.Candidate;
import com.hrms.demo.model.InterviewSchedule;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface InterviewScheduleRepository extends JpaRepository<InterviewSchedule,Integer> {
    List<InterviewSchedule> findByInterviewTimeBetween(LocalDateTime now, LocalDateTime reminderTime);

}
