package com.hrms.demo.service;

import com.hrms.demo.dto.request.SkillMapperRrRequest;
import com.hrms.demo.dto.response.SkillMapperRrResponse;
import com.hrms.demo.model.SkillMapperRR;

public interface SkillMapperRrService {
    SkillMapperRrResponse createSkillMapperRr(SkillMapperRrRequest skillMapperRrRequest);
    SkillMapperRrResponse getSkillMapperById(Integer id);
}


