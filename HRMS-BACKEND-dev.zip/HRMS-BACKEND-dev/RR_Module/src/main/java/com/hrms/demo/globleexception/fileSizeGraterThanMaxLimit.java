package com.hrms.demo.globleexception;

public class fileSizeGraterThanMaxLimit extends Throwable {
    public fileSizeGraterThanMaxLimit(String s) {
        super(s);
    }
}
