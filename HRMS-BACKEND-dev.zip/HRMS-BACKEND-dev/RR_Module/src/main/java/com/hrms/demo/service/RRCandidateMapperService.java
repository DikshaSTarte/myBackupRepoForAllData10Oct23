package com.hrms.demo.service;

import com.hrms.demo.dto.request.RRCandidateMapperRequest;
import com.hrms.demo.dto.request.RrFinalCandidateRequest;
import com.hrms.demo.dto.response.CandidateForRrResponse;
import com.hrms.demo.dto.response.RRCandidateMapperResponse;
import com.hrms.demo.dto.response.SelectedCandidateResponse;
import com.hrms.demo.model.RRCandidateMapper;
import com.hrms.demo.model.SelectedCandidateMapper;

import java.util.List;

public interface RRCandidateMapperService {
    RRCandidateMapperResponse saveCandidatesByRrId(RRCandidateMapperRequest rrCandidateMapperRequest);
    List<SelectedCandidateResponse> getAllSelectedCandidatesByRrId(Integer rrId);
    List<SelectedCandidateMapper> saveSelectedCandidatesByRrId(RrFinalCandidateRequest rrFinalCandidateRequest);
}
