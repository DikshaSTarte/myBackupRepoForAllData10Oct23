package com.hrms.demo.service;

import com.hrms.demo.dto.request.CreateSkillRequest;
import com.hrms.demo.dto.request.SkillRequest;
import com.hrms.demo.dto.response.SkillDTO;
import com.hrms.demo.dto.response.SkillEntityListResponse;
import com.hrms.demo.dto.response.SkillResponse;
import com.hrms.demo.dto.response.SkillTypeDTO;
import com.hrms.demo.exceptionHandler.exception.ResourceNotFoundException;
import com.hrms.demo.globleexception.SkillAlreadyExistForSKillTypeException;
import com.hrms.demo.globleexception.SkillSetAlreadyExistException;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public interface SkillService {
    List<SkillResponse> getAllSkills();
    SkillResponse getSkillById(Integer id) throws ResourceNotFoundException;
    SkillDTO createSkill(CreateSkillRequest skillRequest) throws SkillSetAlreadyExistException, SkillAlreadyExistForSKillTypeException;

    SkillResponse updateSkill(Integer id, SkillRequest skillRequest) throws ResourceNotFoundException;
    void deleteSkill(Integer id) throws ResourceNotFoundException ;
    public List<SkillTypeDTO> getSkillsBySkillTypeId(Integer skillTypeId);
    SkillEntityListResponse getListSkillsPg(Integer pageNumber, Integer pageSize, String searchTerm);
}

