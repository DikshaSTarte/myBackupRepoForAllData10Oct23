package com.hrms.demo.dto.response;

import com.hrms.demo.model.RRMaster;
import com.hrms.demo.model.User;
import com.hrms.demo.model.UserType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserRrMapperResponse {
    // private UserType userType;
// private String userFirstName;
// private String userLastName;
// private RrResponse rrDetails ;
    private User userId;
    private RRMaster rrId;

}