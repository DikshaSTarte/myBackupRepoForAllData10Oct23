package com.hrms.demo.dto.request;

import com.hrms.demo.model.Candidate;
import com.hrms.demo.model.RRMaster;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RrFinalCandidateRequest {
    private List<Integer>candidateId ;
    private Integer rrId ;
}