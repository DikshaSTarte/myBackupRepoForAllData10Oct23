package com.hrms.demo.serviceImpl;
import com.hrms.demo.repository.InterviewerFeedbackRepository;
import com.hrms.demo.dto.request.InterviewerFeedbackRequest;
import com.hrms.demo.dto.response.InterviewerFeedbackResponse;
import com.hrms.demo.model.InterviewerFeedback;
import com.hrms.demo.service.InterviewerFeedbackService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Slf4j
@Service
public class InterviewerFeedbackServiceImpl implements InterviewerFeedbackService {
    @Autowired
    private InterviewerFeedbackRepository interviewerFeedbackRepository;
    @Override
    public InterviewerFeedbackResponse saveInterviewerFeedback(InterviewerFeedbackRequest interviewerFeedbackRequest) {
        log.info("InterviewerFeedbackServiceImpl--------------saveInterviewerFeedback----------{}",interviewerFeedbackRequest);
        InterviewerFeedback interviewerFeedback=new InterviewerFeedback();
        interviewerFeedback.setInterviewerFdbkDescp(interviewerFeedbackRequest.getInterviewerFdbkDescp());
        interviewerFeedback.setInterviewerFdbkRatings(interviewerFeedbackRequest.getInterviewerFdbkRatings());
        InterviewerFeedback save= this.interviewerFeedbackRepository.save(interviewerFeedback);
      InterviewerFeedbackResponse interviewerFeedbackResponse=  interviewerFeedbackEntityToInterviewerFeedbackResponse(save);
      return interviewerFeedbackResponse;
    }
    InterviewerFeedbackResponse interviewerFeedbackEntityToInterviewerFeedbackResponse(InterviewerFeedback interviewerFeedback){
        InterviewerFeedbackResponse interviewerFeedbackResponse=new InterviewerFeedbackResponse();
        interviewerFeedbackResponse.setInterviewerFdbkDescp(interviewerFeedback.getInterviewerFdbkDescp());
        interviewerFeedbackResponse.setInterviewerFdbkRatings(interviewerFeedback.getInterviewerFdbkRatings());
        return interviewerFeedbackResponse;
    }

    @Override
    public String deleteInterviewerFeedbackById(Integer interviewerFdbkId) {
        log.info("InterviewerFeedbackServiceImpl--------------deleteInterviewerFeedbackById----------{}",interviewerFdbkId);
        Optional<InterviewerFeedback> interviewerFeedback= interviewerFeedbackRepository.findById(interviewerFdbkId);
        interviewerFeedback.get().setActive(false);
        interviewerFeedbackRepository.save(interviewerFeedback.get());
        return "InterviewerFeedback Successfully Deleted";
    }
    @Override
    public InterviewerFeedbackResponse getInterviewerFeedbackById(Integer interviewerFdbkId) {
        log.info("InterviewerFeedbackServiceImpl--------------getInterviewerFeedbackById----------{}",interviewerFdbkId);
       InterviewerFeedback interviewerFeedback= interviewerFeedbackRepository.findByActiveAndInterviewerFdbkId(true,interviewerFdbkId);
        InterviewerFeedbackResponse interviewerFeedbackResponse=new InterviewerFeedbackResponse();
        interviewerFeedbackResponse.setInterviewerFdbkDescp(interviewerFeedback.getInterviewerFdbkDescp());
        interviewerFeedbackResponse.setInterviewerFdbkRatings(interviewerFeedback.getInterviewerFdbkRatings());
        return interviewerFeedbackResponse;
    }

    @Override
    public InterviewerFeedbackResponse updateInterviewerFeedback(Integer interviewerFdbkId, InterviewerFeedbackRequest interviewerFeedbackRequest) {
        log.info("InterviewerFeedbackServiceImpl--------------updateInterviewerFeedback----------{}",interviewerFdbkId,interviewerFeedbackRequest);
        InterviewerFeedback interviewerFeedback= interviewerFeedbackRepository.findByActiveAndInterviewerFdbkId(true,interviewerFdbkId);
        interviewerFeedback.setInterviewerFdbkDescp(interviewerFeedbackRequest.getInterviewerFdbkDescp());
        interviewerFeedback.setInterviewerFdbkRatings(interviewerFeedbackRequest.getInterviewerFdbkRatings());
        InterviewerFeedback update= this.interviewerFeedbackRepository.save(interviewerFeedback);
        InterviewerFeedbackResponse interviewerFeedbackResponse=interviewerFeedbackEntityToInterviewerFeedbackResponse(update);
        return interviewerFeedbackResponse;
    }


    @Override
    public List<InterviewerFeedbackResponse> getListInterviewerFeedback() {
        log.info("InterviewerFeedbackServiceImpl--------------getListInterviewerFeedback----------{}");
        List<InterviewerFeedback> all = interviewerFeedbackRepository.findByActive(true);
        List<InterviewerFeedbackResponse> interviewerFeedbackResponseList= new ArrayList<>();
        for (InterviewerFeedback interviewerFeedback:all) {
            interviewerFeedbackResponseList.add(interviewerFeedbackEntityToInterviewerFeedbackResponse(interviewerFeedback));

        }
        return interviewerFeedbackResponseList;
    }
}
