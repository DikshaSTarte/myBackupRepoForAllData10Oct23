package com.hrms.demo.dto.response;

import com.hrms.demo.model.Candidate;
import com.hrms.demo.model.SkillEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SkillCandidateMapperResponse {

    private Integer skillCandidateMapperId;

    private SkillEntity id;

    private Candidate candidateId;

}
