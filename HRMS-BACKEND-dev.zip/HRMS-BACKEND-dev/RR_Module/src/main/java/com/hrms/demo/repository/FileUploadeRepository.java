package com.hrms.demo.repository;

import com.hrms.demo.model.FileUploade;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface FileUploadeRepository extends JpaRepository<FileUploade,Integer> {
    Optional<FileUploade> findByActiveAndFileId(boolean b, Integer fileId);
}
