package com.hrms.demo.serviceImpl;

import com.hrms.demo.dto.request.DashboardRequest;
import com.hrms.demo.dto.response.*;
import com.hrms.demo.model.*;

import com.hrms.demo.model.CandidateStatus;
import com.hrms.demo.model.RRMaster;

import com.hrms.demo.repository.*;
import com.hrms.demo.service.DashboardService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j

@Service
public class DashboardServiceImpl implements DashboardService {
    @Autowired
    private InterviewerMapperRepository interviewerMapperRepository;
    @Autowired
    private CandidateRepository candidateRepository;
    @Autowired
    private SkillTypeEntityRepository skillTypeEntityRepository;
    @Autowired
    private CandidateStatusRepository candidateStatusRepository;
    @Autowired
    private InterviewerCandidateRepository interviewerCandidateRepository;
    @Autowired
    private RRMasterRepository rrMasterRepository;
    @Autowired
    private SkillMapperRrRepository skillMapperRrRepository;
    @Autowired
    private RRCandidateMapperRepository rrCandidateMapperRepository;
    @Autowired
    private  SkillCandidateMapperRepository skillCandidateMapperRepository;
    @Autowired
    private CompanyRepository companyRepository;
    @Autowired
    private RRStatusRepository rrStatusRepository;


//    @Override
//    public List<DashboardResponse> getMonthlyTrends() {
//        log.info("DashboardServiceImpl---------------getMonthlyTrends-------------{}");
//        List<DashboardResponse> monthlyTrends = new ArrayList<>();
//        DashboardResponse dashboardResponse = new DashboardResponse();
//        LocalDate startDate = LocalDate.parse("2023-01-01");
//        LocalDate endDate = LocalDate.parse("2023-12-01");
//        YearMonth startYearMonth = YearMonth.from(startDate);
//        YearMonth endYearMonth = YearMonth.from(endDate);
//
//        long monthsBetween = ChronoUnit.MONTHS.between(startYearMonth, endYearMonth);
//
//        System.out.println("Number of months between the dates: " + monthsBetween);
//
//        CandidateStatus selected = candidateStatusRepository.findByActiveAndCandidateStatusName(true, "SELECTED");
//
//        CandidateStatus rejected = candidateStatusRepository.findByActiveAndCandidateStatusName(true, "REJECTED");
//
//        CandidateStatus onHold = candidateStatusRepository.findByActiveAndCandidateStatusName(true, "ONHOLD");
//
//        YearMonth currentMonth = YearMonth.from(startDate);
//        YearMonth endMonth = YearMonth.from(endDate);
//
//        for (int i = 0; i <= monthsBetween; i++) {
//            LocalDate sDate = startDate;
//            LocalDate eDate = endDate;
//            Integer s = rrCandidateMapperRepository.countByCandidateIdAndCandidateStatusAndDateBetween(selected, sDate, eDate);
//            Integer r =rrCandidateMapperRepository.countByCandidateIdAndCandidateStatusAndDateBetween(rejected, sDate, eDate);
//            Integer o = rrCandidateMapperRepository.countByCandidateIdAndCandidateStatusAndDateBetween(onHold, sDate, eDate);
//// System.out.println("month ");
//            System.out.println("selected--->" + s);
//            System.out.println("rejected--->" + r);
//            System.out.println("onhold--->" + o);
//
////            DashboardResponse monthlyTrend = new DashboardResponse(currentMonth.atEndOfMonth(),s, r, o);
//            currentMonth = currentMonth.plusMonths(1);
////            monthlyTrends.add(monthlyTrend);
//        }
//        log.info("DashboardServiceImpl---------getMonthlyTrends-------------{}");
//        return monthlyTrends;
//    }
//    @Override
//    public List<DashboardResponse> saveDateData(DashboardRequest dashboardRequest) {
//        log.info("DashboardServiceImpl-------saveDateData---------{}",dashboardRequest);
//        List<DashboardResponse> monthlyCounts = new ArrayList<>();
//
//        LocalDate startDate = dashboardRequest.getStartDate();
//        CandidateStatus selected = candidateStatusRepository.findByActiveAndCandidateStatusName(true, "SELECTED");
//
//        CandidateStatus rejected = candidateStatusRepository.findByActiveAndCandidateStatusName(true, "REJECTED");
//
//        CandidateStatus onHold = candidateStatusRepository.findByActiveAndCandidateStatusName(true, "ONHOLD");
//        for(int i = 0; i < 12; i++){
//            LocalDate endDate = startDate.minusMonths(1);
//            Integer s = interviewerCandidateRepository.countByCandidateId_CandidateStatusAndDateBetween(selected, endDate, startDate);
//            Integer r = interviewerCandidateRepository.countByCandidateId_CandidateStatusAndDateBetween(rejected, endDate, startDate);
//            Integer o = interviewerCandidateRepository.countByCandidateId_CandidateStatusAndDateBetween(onHold, endDate, startDate);
//
//            DashboardResponse monthlyCount = new DashboardResponse(endDate,s,r,o);
//
//            monthlyCounts.add(monthlyCount);
//            startDate = startDate.minusMonths(1);
//            endDate.minusMonths(1);
//        }
//        log.info("DashboardServiceImpl-------saveDateData---------{}",dashboardRequest);
//        return monthlyCounts;
//    }

@Override
public List<DashboardResponse> saveDateData(DashboardRequest dashboardRequest) {
    log.info("DashboardServiceImpl-------------saveDateData-----------{}",dashboardRequest);
    List<DashboardResponse> monthlyCounts = new ArrayList<>();
    LocalDate startDate = dashboardRequest.getStartDate();

    List<String> candidateStatuses = new ArrayList<>();
    candidateStatuses.add("SELECTED");
    candidateStatuses.add("REJECTED");
    candidateStatuses.add("ONHOLD");

    for(int i = 0; i < 12; i++){
        LocalDate endDate = startDate.minusMonths(1);
        List<DropDownDTO<Long, String>> selectedCandidates = interviewerCandidateRepository.getCandidateStatusAndDate(candidateStatuses, endDate, startDate);
        Map<String, Long> selectedCandidatesMap = new HashMap<>();
        if(selectedCandidates != null && selectedCandidates.size()> 0){
            selectedCandidatesMap = selectedCandidates.stream().collect(Collectors.toMap(candidate -> candidate.getLabel(), candidate-> candidate.getValue()));
        }

        DashboardResponse dashboardResponse = new DashboardResponse();
        dashboardResponse.setMonth(endDate);
        dashboardResponse.setSelected(selectedCandidatesMap.getOrDefault("SELECTED", 0L));
        dashboardResponse.setOnHold(selectedCandidatesMap.getOrDefault("REJECTED", 0L));
        dashboardResponse.setRejected(selectedCandidatesMap.getOrDefault("ONHOLD", 0L));

        monthlyCounts.add(dashboardResponse);

        startDate = startDate.minusMonths(1);
        endDate.minusMonths(1);
    }
    return monthlyCounts;
}

//    public List<DashboardResponse> getMonthlyCounts(LocalDate startDate) {
//        log.info("DashboardServiceImpl-------------getMonthlyCounts-----------{}",startDate);
//        List<DashboardResponse> monthlyCounts = new ArrayList<>();
//        for (int i = 0; i < 12; i++) {
//            CandidateStatus selected = candidateStatusRepository.findByActiveAndCandidateStatusName(true, "SELECTED");
//
//            CandidateStatus rejected = candidateStatusRepository.findByActiveAndCandidateStatusName(true, "REJECTED");
//
//            CandidateStatus onHold = candidateStatusRepository.findByActiveAndCandidateStatusName(true, "ONHOLD");
//
//            LocalDate endDate = startDate.minusMonths(i);
//            Integer s = rrCandidateMapperRepository.countByCandidateIdAndCandidateStatusAndDateBetween(selected, endDate, startDate);
//            Integer r = rrCandidateMapperRepository.countByCandidateId_CandidateStatusAndDateBetween(rejected, endDate, startDate);
//            Integer o = interviewerCandidateRepository.countByCandidateId_CandidateStatusAndDateBetween(onHold, endDate, startDate);
//
////            DashboardResponse monthlyCount = new DashboardResponse(endDate,s,r,o);
////            monthlyCounts.add(monthlyCount);
//        }
//        log.info("DashboardServiceImpl-------------getMonthlyCounts-----------{}",startDate);
//        return monthlyCounts;
//    }

    @Override
     public  List<RRMasterResponse> getRRListByStatus(Integer statusId) {
        log.info("DashboardServiceImpl-------------getRRListByStatus-----------{}",statusId);
     List<RRMaster> rrMasterList;
        rrMasterList= rrMasterRepository.findByActiveAndRrStatusRrStatusId(true,statusId);
        List<RRMasterResponse> rrMasterResponseList = new ArrayList<>();
        for (RRMaster rrMaster : rrMasterList) {
            RRMasterResponse rrMasterResponse1=new RRMasterResponse();
            rrMasterResponse1.setRrStatus(rrMaster.getRrStatus());
            rrMasterResponse1.setRrMasterId(rrMaster.getRrMasterId());
            rrMasterResponse1.setOwnerId(new OwnerResponse(rrMaster.getOwnerId().getUserId(),rrMaster.getOwnerId().getUserType(), rrMaster.getOwnerId().getUserFirstName(),rrMaster.getOwnerId().getUserLastName(),rrMaster.getOwnerId().getUserContact(),rrMaster.getOwnerId().getUserEmailId()));
            rrMasterResponse1.setCompany(rrMaster.getCompany());
            rrMasterResponse1.setExperience(rrMaster.getExperience());
            rrMasterResponse1.setRequiredCount(rrMaster.getRequiredCount());
            //rrMasterResponse1.setSkillsId();
            rrMasterResponse1.setEndDate(rrMaster.getEndDate());
            rrMasterResponse1.setStartDate(rrMaster.getStartDate());
           // rrMasterResponse1.setCandidateId();
            rrMasterResponse1.setFileId(fileUploadT0FileuploadResposnse(rrMaster.getFileId()));
            //remaining
            List<SkillResponse> skillResponseList = new ArrayList<>();
            List<SkillMapperRR> skillMapperRRS = skillMapperRrRepository.findByRrMasterId(rrMaster);
            for (SkillMapperRR skillMapperRR : skillMapperRRS) {
                SkillResponse skillResponse = new SkillResponse();
                if(skillMapperRR.getSkillsId() != null){
                    skillResponse.setId(skillMapperRR.getSkillsId().getId());
                    skillResponse.setSkillSet(skillMapperRR.getSkillsId().getSkillSet());
                    skillResponse.setSkillType(new SkillTypeResponse(skillMapperRR.getSkillsId().getSkillType().getId(),skillMapperRR.getSkillsId().getSkillType().getSkillTypeName()));
                    skillResponseList.add(skillResponse);}
            }
            rrMasterResponse1.setSkillsId(skillResponseList);

            rrMasterResponseList.add(rrMasterResponse1);
        }
        log.info("DashboardServiceImpl-------------getRRListByStatus-----------{}",statusId);
       return rrMasterResponseList;
    }

    public FileUploadeResponse fileUploadT0FileuploadResposnse(FileUploade fileUploade) {
         FileUploadeResponse fileUploadeResponse=new FileUploadeResponse();
         fileUploadeResponse.setFileId(fileUploade.getFileId());
         fileUploadeResponse.setFileName(fileUploade.getFileName());
         fileUploadeResponse.setFilePath(fileUploade.getFilePath());
         fileUploadeResponse.setFileSize(fileUploade.getFileSize());
         fileUploadeResponse.setFileType(fileUploade.getFileType());

         return fileUploadeResponse;
    }

    public  CandidateStatusResponse CandidateStatusToCandidteStatusResponse(CandidateStatus candidateStatus)
    {
        CandidateStatusResponse candidateStatusResponse=new CandidateStatusResponse();
        candidateStatusResponse.setCandidateStatusId(candidateStatus.getCandidateStatusId());
        candidateStatusResponse.setCandidateStatusName(candidateStatus.getCandidateStatusName());
       return  candidateStatusResponse;
    }

    @Override
   public PiechartResponse getRRListCountByStatus()
    {
        log.info("DashboardServiceImpl------------getRRListCountByStatus-----------{}");
      PieChartMasterResponse pieChartMasterResponse=new PieChartMasterResponse();
      pieChartMasterResponse.setFullFilled(rrMasterRepository.countByActiveAndRrStatusRrStatusId(true,1));
      pieChartMasterResponse.setOpen(rrMasterRepository.countByActiveAndRrStatusRrStatusId(true,2));
      pieChartMasterResponse.setCancel(rrMasterRepository.countByActiveAndRrStatusRrStatusId(true,3));
      pieChartMasterResponse.setOnHold(rrMasterRepository.countByActiveAndRrStatusRrStatusId(true,4));
      PiechartResponse piechartResponse=new PiechartResponse();
      piechartResponse.setPieChartMasterResponse(pieChartMasterResponse);
        log.info("DashboardServiceImpl------------getRRListCountByStatus-----------{}");
      return piechartResponse;
    }
    @Override
    public List<RRListByCompanyResponse> getRrCountByCustomer() {
        log.info("DashboardServiceImpl------------getRrCountByCustomer-----------{}");
        List<CompanyResponse> companies = new ArrayList<>();
        companies =  companyRepository.getCompanyIds();
        List<DashboardCountDTO> rrCount = rrMasterRepository.findRrCount();

        Map<Integer, DashboardCountDTO> countMap = new HashMap<>();
        List<RRListByCompanyResponse> responseList = new ArrayList<>();
        rrCount.forEach(count->{
            countMap.putIfAbsent(count.getCompanyId(),count);
        });
        companies.forEach(company->{
           RRListByCompanyResponse response = new RRListByCompanyResponse();
           response.setCompany(new CompanyResponse(company.getCompanyId(),company.getCompanyName()));
            if(countMap.get(company.getCompanyId()) != null && countMap.get(company.getCompanyId()).getCompanyId() == company.getCompanyId().intValue()){
                response.setRrCount(countMap.get(company.getCompanyId()).getCount());
            }else{
                response.setRrCount(0L);
            }
            responseList.add(response);
        });
        log.info("DashboardServiceImpl------------getRrCountByCustomer-----------{}");
        return responseList;
    }
    @Override
    public List<SkillTypeForRrResponse> getSkillTypeCountForOpenRr() {
        log.info("DashboardServiceImpl------------getSkillTypeCountForOpenRr-----------{}");
         List<SkillTypeForRrResponse> skillMapperRRList = new ArrayList<>();

        Optional<RRStatus> rrStatus = rrStatusRepository.findById(2);
        List<SkillTypeEntity> skillType = skillTypeEntityRepository.findByActive(true);
        for (SkillTypeEntity skillTypeEntity : skillType) {
        Integer count = skillMapperRrRepository.countByActiveAndRrMasterId_rrStatusAndRrMasterId_ActiveAndSkillsId_SkillType(true,rrStatus.get(),true,skillTypeEntity);

            SkillTypeForRrResponse response = new SkillTypeForRrResponse();
            response.setCount(count);
            response.setSkillType(new SkillTypeResponse(skillTypeEntity.getId(),skillTypeEntity.getSkillTypeName()));
            skillMapperRRList.add(response);
        }
        log.info("DashboardServiceImpl------------getSkillTypeCountForOpenRr-----------{}");
        return skillMapperRRList;
    }


}

