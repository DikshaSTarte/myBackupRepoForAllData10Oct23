package com.hrms.demo.service;

import com.hrms.demo.dto.request.SkillTypeRequest;
import com.hrms.demo.dto.response.SkillTypeListResponse;
import com.hrms.demo.dto.response.SkillTypeResponse;
import com.hrms.demo.exceptionHandler.exception.ResourceNotFoundException;
import com.hrms.demo.globleexception.SkillTypeAlreadyExistException;
import com.hrms.demo.model.SkillTypeEntity;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface SkillTypeService
{
    List<SkillTypeResponse> getAllSkillTypes();

  //  SkillTypeResponse getSkillTypeById(Integer id) throws ResourceNotFoundException;

    SkillTypeEntity createSkillType(SkillTypeRequest skillTypeRequest) throws SkillTypeAlreadyExistException;

    SkillTypeResponse updateSkillType(Integer id, SkillTypeRequest skillTypeRequest) throws ResourceNotFoundException;

    void deleteSkillType(Integer id) throws ResourceNotFoundException;

    Page<SkillTypeEntity> searchSkillTypes(String searchKeyword, int pageNo, int pageSize);

    SkillTypeListResponse getListSkillTypeOp(Integer pageNumber, Integer pageSize, String searchTerm);
}


