package com.hrms.demo.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "skillCandidateMapper")
@AllArgsConstructor
@NoArgsConstructor
public class SkillCandidateMapper extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "skillCandidateMapper_generator")
    @SequenceGenerator(name = "skillCandidateMapper_generator", sequenceName = "skillCandidateMapper_SEQUENCE", initialValue = 4421, allocationSize = 1)
    @Column(name = "skillCandidateMapperId")
    private Integer skillCandidateMapperId;

    @ManyToOne
    @JoinColumn(name = "skills_id")
    private SkillEntity skillEntity;

    @ManyToOne
    @JoinColumn(name = "candidateId")
    private Candidate candidate;
}
