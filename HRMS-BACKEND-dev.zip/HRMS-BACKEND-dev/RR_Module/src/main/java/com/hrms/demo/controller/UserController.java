package com.hrms.demo.controller;

import com.hrms.demo.dto.response.CandidateResponse;
import com.hrms.demo.dto.response.UserListResponse;
import com.hrms.demo.globleexception.UserNotFoundException;
import com.hrms.demo.repository.UserRepository;
import com.hrms.demo.dto.request.UserRequest;

import com.hrms.demo.dto.response.UserResponse;

import com.hrms.demo.service.UserService;
import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Set;

@Slf4j
@RestController
@RequestMapping("/api/v1/user")
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    private UserRepository userRepository;

    @PostMapping("/save")
    public UserResponse SaveUserData(@Valid @RequestBody UserRequest userRequest){
        System.out.println("User Added Successfully...");
        log.info("UserController-----SaveUserData----{}",userRequest);
        return userService.saveUser(userRequest);
    }
    @DeleteMapping("/delete/{userId}")
    public ResponseEntity<Void> deleteCandidateData(@PathVariable Integer userId){
        userService.deleteUserById(userId);
        System.out.println("User Deleted Successfully...");
        log.info("UserController-----deleteCandidateData----{}",userId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/list")
    public List<UserResponse> getShowListCandidates() {
        log.info("UserController-----getShowListCandidates----{}");
        return this.userService.getListOfUsers();
    }
    @GetMapping("/get/{userId}")
    public UserResponse getUserById(@PathVariable Integer userId){
        log.info("UserController-----getUserById----{}",userId);
        return this.userService.getUserById(userId);
    }
    @PutMapping("/update/{userId}")
    public ResponseEntity<UserResponse> updateUserData(@Valid @PathVariable Integer userId ,@RequestBody UserRequest userRequest ){
        UserResponse userResponse= userService.updateUser(userId,userRequest);
        if(userResponse!=null){
            System.out.println("User updated successfully...");
            log.info("UserController-----updateUserData----{}",userId,userRequest);
            return ResponseEntity.ok(userResponse);
        }else {
            System.out.println("Check for user once again...\n user not found!!!");
            log.error("UserController-----updateUserData----{}",userId,userRequest,"update user data failed");
            return ResponseEntity.notFound().build();
        }
    }
    @GetMapping("/getAllUser")
    public ResponseEntity<List<UserResponse>> getAllUser(@RequestParam(defaultValue = "0") Integer pageNumber, @RequestParam(defaultValue = "") String searchKey){
        List<UserResponse>result= userService.getAllUser(pageNumber,searchKey);
        System.out.println("Result Size Is >> "+result.size());
        log.info("UserController-----getAllUser----{}",pageNumber,searchKey);
        return ResponseEntity.ok(result);
    }
    @GetMapping("/get/getUserByUserTypeId")
    public List<UserResponse> getByUserType(@RequestParam("userTypeId") Integer userTypeId ){
        log.info("UserController-----getByUserType----{}",userTypeId);
        return this.userService.getUserByUserTypeId(userTypeId);
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<String> forgotPassword(@RequestBody UserRequest userRequest) {
    String userEmailId=userRequest.getUserEmailId();
       // System.out.println("its updated code");
        userService.forgotPassword(userEmailId);
        log.info("UserController-----forgotPassword----{}",userRequest);
        return ResponseEntity.ok("OTP send to email successfully");
    }
    @PostMapping("/verify-otp")
    public ResponseEntity<String> verifyOTP(@RequestBody UserRequest userRequest) {
         String userEmailId=userRequest.getUserEmailId();
         String otp=userRequest.getOtp();
        try {
            boolean otpValid = userService.verifyOTP(userEmailId,otp);
            if (otpValid) {
                // OTP is valid, perform further actions or return success response
                log.info("UserController-----verifyOTP----{}",userRequest);
                return ResponseEntity.ok("OTP verified successfully.Proceed with password reset.");
            } else {
                // Invalid OTP
                return ResponseEntity.badRequest().body("Invalid OTP.");
            }
        } catch (UserNotFoundException e) {
            // User not found
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            // Other errors
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred while processing your request.");
        }
    }

   @PostMapping("/reset-password/initiallyLogin")
   public ResponseEntity<String> resetPassword(@RequestBody UserRequest userRequest) {
       String userEmailId=userRequest.getUserEmailId();
       String newPassword=userRequest.getNewPassword();
       String conformPassword=userRequest.getConformPassword();
               userService.resetPassword(userEmailId, newPassword,conformPassword);
               log.info("UserController-----resetPassword----{}",userRequest);
               return ResponseEntity.ok("Password reset successfully.");
   }

    @GetMapping("/list/users")
    public ResponseEntity<UserListResponse> getShowListUsers(@RequestParam(value = "pageNumber",defaultValue = "0",required = false) Integer pageNumber,
                                                             @RequestParam(value = "pageSize",defaultValue = "10",required = false) Integer pageSize,
                                                             @RequestParam(value = "searchTerm",defaultValue = "",required = false)String searchTerm ){
// log.info("CandidateController------getShowListCandidates--{}");
log.info("UserController-------------------getShowListUsers------------{}",pageNumber, pageSize, searchTerm);
        UserListResponse userListResponse =userService.getListUsersPg(pageNumber, pageSize, searchTerm);
        return ResponseEntity.ok(userListResponse);
    }
}