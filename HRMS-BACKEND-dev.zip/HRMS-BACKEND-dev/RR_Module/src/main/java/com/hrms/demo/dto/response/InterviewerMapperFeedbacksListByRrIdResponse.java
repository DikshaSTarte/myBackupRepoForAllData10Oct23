package com.hrms.demo.dto.response;

import com.hrms.demo.model.Candidate;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class InterviewerMapperFeedbacksListByRrIdResponse {

    private long allFeedbacksListByRr;
    private List<InterviewerMapperResponse> interviewerMapperResponseList12;
    private List<Integer> finalisedCandidates;
    private Integer updatedRequiredCount;

}
