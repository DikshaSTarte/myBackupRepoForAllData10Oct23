package com.hrms.demo.serviceImpl;

import com.hrms.demo.dto.request.UserRequest;
import com.hrms.demo.dto.response.*;
import com.hrms.demo.globleexception.InterviewerAlreadyExistException;
import com.hrms.demo.globleexception.UserAlreadyExistsException;
import com.hrms.demo.model.*;
import com.hrms.demo.repository.*;
import com.hrms.demo.dto.request.InterviewerRequest;
import com.hrms.demo.service.InterviewerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import javax.mail.MessagingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Slf4j
@Service
public class InterviewerServiceImpl implements InterviewerService {
    @Autowired
    private InterviewerRepository interviewerRepository;
    @Autowired
    PasswordEncoder passwordEncoder;
    @Autowired
    private UserTypeRepository userTypeRepository;
    @Autowired
    private UserRepository userRepository;
@Autowired
private SkillEntityRepository skillEntityRepository;
@Autowired
private SkillInterviewerMapperRepository skillInterviewerMapperRepository;
@Autowired
private UserServiceImpl userServiceImpl;
    InterviewerResponse interviewerEntityToInterviewerResponse(Interviewer interviewer){

        InterviewerResponse interviewerResponse = new InterviewerResponse();

        interviewerResponse.setInterviewerId(interviewer.getInterviewerId());
        interviewerResponse.setInterviewerContactNo(interviewer.getInterviewerContactNo());
        interviewerResponse.setInterviewerEmail(interviewer.getInterviewerEmail());
        interviewerResponse.setInterviewerExperience(interviewer.getInterviewerExperience());
        interviewerResponse.setInterviewerFirstName(interviewer.getInterviewerFirstName());
        interviewerResponse.setInterviewerLastName(interviewer.getInterviewerLastName());
        interviewerResponse.setUserId(new OwnerResponse(interviewer.getUserId().getUserId(),interviewer.getUserId().getUserType(),interviewer.getUserId().getUserFirstName(),interviewer.getUserId().getUserLastName(),
                interviewer.getUserId().getUserContact(),interviewer.getUserId().getUserEmailId()));

        List<SkillResponse> skillResponseList =new ArrayList<>();
        List<SkillInterviewerMapper> skillInterviewerMappers =skillInterviewerMapperRepository.findByActiveAndInterviewer(true,interviewer);
        for(SkillInterviewerMapper skillInterviewerMapper:skillInterviewerMappers){
            SkillResponse skillResponse=new SkillResponse();

            if(skillInterviewerMapper.getSkillEntity()!=null) {
                skillResponse.setSkillSet(skillInterviewerMapper.getSkillEntity().getSkillSet());
                skillResponse.setSkillType(new SkillTypeResponse(skillInterviewerMapper.getSkillEntity().getSkillType().getId(),skillInterviewerMapper.getSkillEntity().getSkillType().getSkillTypeName()));
                skillResponse.setId(skillInterviewerMapper.getSkillEntity().getId());
                skillResponseList.add(skillResponse);
            }
        }
           interviewerResponse.setSkillsId(skillResponseList);
        return interviewerResponse;
    }
    @Override
    public InterviewerResponse saveInterviewer(InterviewerRequest interviewerRequest) {
        log.info("InterviewerServiceImpl--------------saveInterviewer-------------{}",interviewerRequest);
//        Interviewer interviewer = interviewerRepository.findByActiveAndUserId_UserId(true,interviewerRequest.getUserId());
        Interviewer interviewer = new Interviewer();
        if(interviewerRepository.existsByActiveAndInterviewerEmail(true,interviewerRequest.getInterviewerEmail())){
            log.error("InterviewerServiceImpl--------------saveInterviewer-------------{}",interviewerRequest.getInterviewerEmail(),"Interviewer Already Exist with this email");
            throw new InterviewerAlreadyExistException("Interviewer Already Exist with this email");

        }
        if(interviewerRepository.existsByActiveAndInterviewerContactNo(true,interviewerRequest.getInterviewerContactNo())){
            log.error("InterviewerServiceImpl--------------saveInterviewer-------------{}",interviewerRequest.getInterviewerContactNo(),"Interviewer Already Exist with this ContactNo");
            throw new InterviewerAlreadyExistException("Interviewer Already Exist with this ContactNo");
        }
     /*  Interviewer existEmail= interviewerRepository.findByInterviewerEmail(interviewerRequest.getInterviewerEmail());
        if (existEmail!=null){
            throw new InterviewerAlreadyExistException("Interviewer Already Exist with this email");
        }*/

        interviewer.setInterviewerFirstName(interviewerRequest.getInterviewerFirstName());
        interviewer.setInterviewerLastName(interviewerRequest.getInterviewerLastName());
        interviewer.setInterviewerContactNo(interviewerRequest.getInterviewerContactNo());
        interviewer.setInterviewerExperience(interviewerRequest.getInterviewerExperience());
        interviewer.setInterviewerEmail(interviewerRequest.getInterviewerEmail());

        Interviewer save= this.interviewerRepository.save(interviewer);

        List<Integer> skillsId = interviewerRequest.getSkillsId();
        List<SkillInterviewerMapper> skillInterviewerMapperList = new ArrayList<>();
        for (Integer id:skillsId){
            SkillEntity skilsave = skillEntityRepository.findByActiveAndId(true, id);
            SkillInterviewerMapper skillInterviewerMapper=new SkillInterviewerMapper();
            skillInterviewerMapper.setInterviewer(save);
            skillInterviewerMapper.setSkillEntity(skilsave);
            skillInterviewerMapperList.add(skillInterviewerMapper);
        }
        skillInterviewerMapperRepository.saveAll(skillInterviewerMapperList);
        UserRequest userRequest=new UserRequest();
        userRequest.setUsername(interviewer.getInterviewerEmail());
        userRequest.setUserType(4);
        userRequest.setUserFirstName(interviewer.getInterviewerFirstName());
        userRequest.setUserLastName(interviewer.getInterviewerLastName());
        userRequest.setUserContact(interviewer.getInterviewerContactNo());
        userRequest.setUserEmailId(interviewer.getInterviewerEmail());

        UserResponse userResponse = userServiceImpl.saveUser(userRequest);
        User user = userRepository.findByActiveAndUserId(true,userResponse.getUserId());
        save.setUserId(user);
        this.interviewerRepository.save(save);

        InterviewerResponse interviewerResponse = interviewerEntityToInterviewerResponse(save);

        return interviewerResponse;
    }
    @Override
    public String deleteInterviewerById(Integer interviewerId) {
        Optional<Interviewer> interviewer = interviewerRepository.findById(interviewerId);

        if (interviewer.isPresent()) {
            Interviewer interviewerObj = interviewer.get();
            interviewerObj.setActive(false);
            User user = interviewerObj.getUserId();
            if (user != null) {
                user.setActive(false);
                userRepository.save(user);
            }
            interviewerRepository.save(interviewerObj);

            return "Interviewer and associated User successfully deleted.";
        } else {
            return "Interviewer not found.";
        }
    }

    @Override
    public InterviewerResponse getInterviewerById(Integer interviewerId) {
     Interviewer interviewer=interviewerRepository.findByActiveAndInterviewerId(true,interviewerId);
        InterviewerResponse interviewerResponse=new InterviewerResponse();
        interviewerResponse.setInterviewerId(interviewer.getInterviewerId());
        interviewerResponse.setInterviewerFirstName(interviewer.getInterviewerFirstName());
        interviewerResponse.setInterviewerLastName(interviewer.getInterviewerLastName());
        interviewerResponse.setInterviewerExperience(interviewer.getInterviewerExperience());
        interviewerResponse.setInterviewerEmail(interviewer.getInterviewerEmail());
        interviewerResponse.setInterviewerContactNo(interviewer.getInterviewerContactNo());
        interviewerResponse.setUserId(new OwnerResponse(interviewer.getUserId().getUserId(),interviewer.getUserId().getUserType(),interviewer.getUserId().getUserFirstName(),interviewer.getUserId().getUserLastName(),interviewer.getUserId().getUserContact(),interviewer.getUserId().getUserEmailId()));

        List<SkillResponse> skillResponseList =new ArrayList<>();
        List<SkillInterviewerMapper> skillInterviewerMappers =skillInterviewerMapperRepository.findByActiveAndInterviewer(true,interviewer);
        for(SkillInterviewerMapper skillInterviewerMapper:skillInterviewerMappers){
            SkillResponse skillResponse=new SkillResponse();
            if(skillInterviewerMapper.getSkillEntity()!=null) {
                skillResponse.setSkillSet(skillInterviewerMapper.getSkillEntity().getSkillSet());
                skillResponse.setSkillType(new SkillTypeResponse(skillInterviewerMapper.getSkillEntity().getSkillType().getId(),skillInterviewerMapper.getSkillEntity().getSkillType().getSkillTypeName()));
                skillResponse.setId(skillInterviewerMapper.getSkillEntity().getId());
                skillResponseList.add(skillResponse);
            }
        }
        interviewerResponse.setSkillsId(skillResponseList);
        return interviewerResponse;
    }

    @Override
    public InterviewerResponse updateInterviewer(Integer interviewerId, InterviewerRequest interviewerRequest) {
        Interviewer interviewer=interviewerRepository.findByActiveAndInterviewerId(true,interviewerId);
        interviewer.setInterviewerFirstName(interviewerRequest.getInterviewerFirstName());
        interviewer.setInterviewerLastName(interviewerRequest.getInterviewerLastName());
        interviewer.setInterviewerEmail(interviewerRequest.getInterviewerEmail());
        interviewer.setInterviewerExperience(interviewerRequest.getInterviewerExperience());
        interviewer.setInterviewerContactNo(interviewerRequest.getInterviewerContactNo());
        Interviewer update= this.interviewerRepository.save(interviewer);
        List<Integer> skillsId = interviewerRequest.getSkillsId();
        List<SkillInterviewerMapper> skillInterviewerMapperList = new ArrayList<>();
        for (Integer id:skillsId) {
            SkillEntity skilsave = skillEntityRepository.findByActiveAndId(true, id);
            SkillInterviewerMapper skillInterviewerMapper=new SkillInterviewerMapper();
            skillInterviewerMapper.setInterviewer(update);
            skillInterviewerMapper.setSkillEntity(skilsave);
            skillInterviewerMapperList.add(skillInterviewerMapper);
        }
       // skillInterviewerMapperRepository.deleteByInterviewer(update);

        List<SkillInterviewerMapper> existingSkillMapperList = skillInterviewerMapperRepository.findByInterviewer(interviewer);
        for (SkillInterviewerMapper existingMapper : existingSkillMapperList) {
            existingMapper.setActive(false); // Soft-delete by setting 'active' to false
        }

        skillInterviewerMapperRepository.saveAll(skillInterviewerMapperList);

       InterviewerResponse interviewerResponse= interviewerEntityToInterviewerResponse(update);
        return interviewerResponse;
    }
    @Override
    public List<InterviewerResponse> getListInterviewer() {
        List<Interviewer> all =interviewerRepository.findByActive(true);
        List<InterviewerResponse> interviewerResponseList = new ArrayList<>();
        for (Interviewer interviewer:all) {
            interviewerResponseList.add(interviewerEntityToInterviewerResponse(interviewer));
        }
        return interviewerResponseList;
    }

    @Override
    public List<InterviewerResponse> getAllInterviewer(Integer pageNumber, String searchKey) {
        Pageable pageable= PageRequest.of(pageNumber,7);

        if(searchKey.equals("")){
            List<Interviewer> all1= interviewerRepository.findByActive(true,pageable);
            List<InterviewerResponse> interviewerResponseList1 = new ArrayList<>();
            for (Interviewer interviewer: all1){
                interviewerResponseList1.add(interviewerEntityToInterviewerResponse(interviewer));
            }
            return interviewerResponseList1;
        }else {
            List<Interviewer> all2= interviewerRepository.findByActiveAndInterviewerFirstNameContainingIgnoreCaseOrInterviewerLastNameContainingIgnoreCaseOrInterviewerContactNoContainingIgnoreCaseOrInterviewerEmailContainingIgnoreCase(true,searchKey,searchKey,searchKey,searchKey,pageable);

            List<InterviewerResponse> interviewerResponseList2 = new ArrayList<>();
            for (Interviewer interviewer: all2){
                interviewerResponseList2.add(interviewerEntityToInterviewerResponse(interviewer));
            }
            return interviewerResponseList2;
    }
}
    @Override
    public InterviewerListResponse getListInterviewersPg(Integer pageNumber, Integer pageSize, String searchTerm) {
        List<Interviewer> all;
        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        long totalInterviewers;

        if (searchTerm != null && !searchTerm.isEmpty()) {
            all = interviewerRepository.findBySearchTerm(searchTerm, pageable);
            totalInterviewers = interviewerRepository.countBySearchTerm(searchTerm); // Get the count from the list size
        } else {
            Page<Interviewer> interviewerPage = interviewerRepository.findByActiveOrderByInterviewerIdDesc(true,pageable);
            all = interviewerPage.getContent();
            totalInterviewers = interviewerRepository.countByActive(true); // Get the total count separately
        }

        List<InterviewerResponse> interviewerResponseList=new ArrayList<>();
        for (Interviewer interviewer:all) {
            interviewerResponseList.add(interviewerEntityToInterviewerResponse(interviewer));
        }

        System.out.println("Total candidates: " + totalInterviewers);

        return new InterviewerListResponse(totalInterviewers, interviewerResponseList);
    }
}
