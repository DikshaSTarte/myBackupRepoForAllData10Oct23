package com.hrms.demo.dto.request;

import com.hrms.demo.model.RRStatus;
import com.hrms.demo.model.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.bytebuddy.asm.Advice;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateRrRequest {
    private Integer ownerId;

    private Integer experience;

    private Integer requiredCount;

    private Integer rrStatus;

    private List<Integer> skillSetId ;

    private LocalDate startDate;

    private LocalDate endDate;
    private Integer companyId;

    private Integer fileId;

    private Integer checkId=0;
}
