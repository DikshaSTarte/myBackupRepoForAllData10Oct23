
package com.hrms.demo.repository;

import com.hrms.demo.model.BaseEntity;
import com.hrms.demo.model.RRMaster;
import com.hrms.demo.model.RRStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RRStatusRepository extends JpaRepository<RRStatus,Integer> {

    RRStatus findByActiveAndRrStatusId(boolean active, Integer rrStatusId);
    List<RRStatus> findByActive(boolean b);
    RRStatus findByRrStatusId(Integer rrStatusId);

    RRStatus findByActiveAndRrStatusName(boolean b, String fulfilled);
}

