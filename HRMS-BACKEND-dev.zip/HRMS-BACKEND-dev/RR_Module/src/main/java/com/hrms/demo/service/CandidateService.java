package com.hrms.demo.service;

import com.hrms.demo.dto.request.CandidateRequest;
import com.hrms.demo.dto.response.CandidateListResponse;
import com.hrms.demo.dto.response.CandidateResponse;
import com.hrms.demo.dto.response.CandidateRrDTO;

import java.util.List;
import java.util.Set;

public interface CandidateService {
    CandidateResponse saveCandidate(CandidateRequest candidateRequest);

    String deleteCandidateById(Integer candidateId);

    CandidateResponse getCandidateById(Integer candidateId);

    CandidateResponse updateCandidate(Integer candidateId, CandidateRequest candidateRequest);

    List<CandidateResponse> getListCandidates();

    List<CandidateResponse> getListCandidatesNew(Integer pageNumber, Integer pageSize, String sortBy, String sortDir);

    List<CandidateResponse> getAllCandidate(Integer pageNumber, String searchKey);

    CandidateListResponse getListCandidatesOp(Integer pageNumber, Integer pageSize, String searchTerm);

    Set<CandidateRrDTO> getListOfCandidatesBySkillType(Integer skillTypeId);
}
