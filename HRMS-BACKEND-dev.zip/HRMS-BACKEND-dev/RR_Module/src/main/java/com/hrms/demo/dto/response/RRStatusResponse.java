package com.hrms.demo.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RRStatusResponse
{
    private Integer rrStatusId ;

    private String rrStatusName ;
}
