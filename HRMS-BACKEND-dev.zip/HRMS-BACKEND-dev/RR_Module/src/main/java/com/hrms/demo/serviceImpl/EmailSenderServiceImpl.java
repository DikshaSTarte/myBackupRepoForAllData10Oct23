package com.hrms.demo.serviceImpl;

import com.hrms.demo.dto.request.EmailRequest;
import com.hrms.demo.model.*;
import com.hrms.demo.repository.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.io.File;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;




@Slf4j

@Service
public class EmailSenderServiceImpl {

    @Autowired
    private JavaMailSender javaMailSender;

    @Autowired
    SkillInterviewerMapperRepository skmr;
    @Autowired
    CompanyRepository cmpr;
    @Autowired
    CandidateRepository cndr;

    @Autowired
    InterviewerRepository intr;

    @Autowired
    EmailTemplatesRepository email_repository;

    @Autowired
    SaveEmailRepository saveMailRepo;

    @Autowired
    RRMasterRepository rrMasterRepository;
    public void scheduleInterview(EmailRequest request) {
        log.info("EmailSenderServiceImpl---------------scheduleInterview-----------{}",request);
        SaveEmail saveMail=new SaveEmail();

        Candidate candidate = cndr.findByCandidateId(request.getStudentId());

        LocalDateTime dateTime = request.getInterviewDateTime();

        LocalDate interviewDate = dateTime.toLocalDate();
        LocalTime interviewTime = dateTime.toLocalTime();
        RRMaster rrMaster=rrMasterRepository.findByActiveAndRrMasterId(true,request.getRrId());

// Send email to the interviewer
        Interviewer interviewer = intr.findByInterviewerId(request.getInterviewerId());
        String nameOfInterviewer = interviewer.getInterviewerFirstName();
        String nameOfCandidate = candidate.getCandidateFirstName();
        String interviewerSubject = "Interview Schedule Notification";
        EmailTemplates emailTemplate = email_repository.getEmailTemplatesByTemplateName("Interviewer");
        String interviewerBody = emailTemplate.getTemplateBody();
        interviewerBody = interviewerBody.replace("{nameOfInterviewer}", nameOfInterviewer);
        interviewerBody = interviewerBody.replace("{roleToHireFor}", request.getRoleToHireFor());
        interviewerBody = interviewerBody.replace("{companyName}", cmpr.findByCompanyId(request.getCompanyId()).getCompanyName());
        interviewerBody = interviewerBody.replace("{interviewDate}", interviewDate.toString());
        interviewerBody = interviewerBody.replace("{interviewTime}", interviewTime.toString());
        interviewerBody = interviewerBody.replace("{candidateName}", nameOfCandidate);
        interviewerBody = interviewerBody.replace("{candidateLastName}", candidate.getCandidateLastName());
        interviewerBody = interviewerBody.replace("{candidateExperience}", Float.toString(candidate.getCandidateExperience()));


        interviewerBody.length();
        saveMail.setEmailBody(interviewerBody);
        saveMail.setReceiver(interviewer.getInterviewerEmail());
        saveMail.setIsSend(false);
        saveMail.setTimeOfSending(dateTime);
        saveMail.setSubjectForEmail(interviewerSubject);
        saveMail.setFilePathJd(rrMaster.getFileId().getFilePath());
        saveMail.setReceiverName("Interviewer");
        saveMail.setFilePathRm(candidate.getFileId().getFilePath());
        saveMailRepo.save(saveMail);

// Send email to the student
        emailTemplate = email_repository.getEmailTemplatesByTemplateName("candidate");
        String studentSubject = "Interview Schedule Notification";
        String studentBody = emailTemplate.getTemplateBody();
        studentBody = studentBody.replace("{nameOfCandidate}", nameOfCandidate);
        studentBody = studentBody.replace("{dateTime.toLocalDate()}", interviewDate.toString());
        studentBody = studentBody.replace("{dateTime.toLocalTime()}", interviewTime.toString());
        studentBody = studentBody.replace("{nameOfInterviewer}", nameOfInterviewer);


        SaveEmail saveMail2=new SaveEmail();
        saveMail2.setEmailBody(studentBody);
        saveMail2.setReceiver(candidate.getCandidateEmail());
        saveMail2.setIsSend(false);
        saveMail2.setTimeOfSending(dateTime);
        saveMail2.setSubjectForEmail(studentSubject);
        saveMail2.setReceiverName("Candidate");
        saveMail2.setFilePathJd(rrMaster.getFileId().getFilePath());
        saveMail2.setFilePathRm(candidate.getFileId().getFilePath());
        saveMailRepo.save(saveMail2);
        log.info("EmailSenderServiceImpl---------------scheduleInterview-----------{}",request);
    }
    public void sendEmail(SaveEmail email) {
        log.info("EmailSenderServiceImpl---------------sendEmail-----------{}",email);
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        try {
            MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            messageHelper.setTo(email.getReceiver());
            messageHelper.setSubject(email.getSubjectForEmail());
            messageHelper.setText(email.getEmailBody(), true);

            String description="";

            if(email.getReceiverName()!=null)
            {
                if(email.getReceiverName().equalsIgnoreCase("Interviewer") && email.getFilePathRm()!=null && email.getFilePathJd()!=null) {

                    // Add file attachment
                    description = "Resume of Candidate And Job Description is provided above ";

                    File jdFile = new File(email.getFilePathJd());
                    if (jdFile.exists()) {
                        FileSystemResource file = new FileSystemResource(jdFile);
                        messageHelper.addAttachment(file.getFilename(), file);
                    } else {
                        log.warn("Job Description file not found at the specified path: {}", email.getFilePathJd());
                    }

                    File rmFile=new File(email.getFilePathRm());
                    if(rmFile.exists())
                    {
                        FileSystemResource file1 = new FileSystemResource(rmFile);
                        messageHelper.addAttachment(file1.getFilename(), file1);
                    } else {
                        log.warn("Resume file not found at the specified path: {}", email.getFilePathJd());
                    }


                }
                else if(email.getReceiverName().equalsIgnoreCase("Candidate") && email.getFilePathJd()!=null){
                    description=" Please Go through Job Description given above once";


                    FileSystemResource file = new FileSystemResource(new File(email.getFilePathJd()));
                    messageHelper.addAttachment(file.getFilename(), file);
                }


                // Add file description to the email body
                String messageWithAttachment = description + "\n\n" + email.getEmailBody();
                messageHelper.setText(messageWithAttachment, true);
            }

            javaMailSender.send(mimeMessage);
            System.out.println("Email sent successfully to: " + email.getReceiverName());
        } catch (MessagingException | MailException e) {
            log.error("EmailSenderServiceImpl---------------sendEmail-----------{}",e);
            System.err.println("Failed to send email to " + email.getReceiverName() + ": " + e.getMessage());
        }
    }


//    public void sendEmail(String to, String subject, String body) {
//        // Sender's email credentials
//        String senderEmail = "recruitmenttrackerteams@gmail.com";
//        String senderPassword = "hcvvadymyvzsjmjc";
//
//        // SMTP server configuration
//        String host = "smtp.example.com";
//        int port = 587;
//
//        // Set properties for the email
//        Properties properties = new Properties();
//        properties.put("mail.smtp.auth", "true");
//        properties.put("mail.smtp.starttls.enable", "true");
//        properties.put("mail.smtp.host", "smtp.gmail.com");
//        properties.put("mail.smtp.port", 587);
//
//        // Get the session and create the email message
//        Session session = Session.getInstance(properties, new Authenticator() {
//
//            protected PasswordAuthentication getPasswordAuthentication() {
//                return new PasswordAuthentication(senderEmail, senderPassword);
//            }
//        });
//
//        try {
//            Message message = new MimeMessage(session);
//            message.setFrom(new InternetAddress(senderEmail));
//            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
//            message.setSubject(subject);
//            message.setText(body);
//
//            // Send the email
//            Transport.send(message);
//        } catch (MessagingException e) {
//            e.printStackTrace();
//            // Handle the exception or log the error as per your application's requirement
//        }
  //  }

//public void sendEmail(String recipientEmail, String subject, String body) {
//    MimeMessage mimeMessage = javaMailSender.createMimeMessage();
//
//    try {
//        MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
//        messageHelper.setTo(recipientEmail);
//        messageHelper.setSubject(subject);
//        messageHelper.setText(body, true);
//
//        // Add file attachment
////        FileSystemResource file = new FileSystemResource(new File(filePath));
////        messageHelper.addAttachment(file.getFilename(), file);
////
////        FileSystemResource file1 = new FileSystemResource(new File(filePath1));
////        messageHelper.addAttachment(file.getFilename(), file1);
//
//        // Add file description to the email body
////        String messageWithAttachment = fileDescription + "\n\n" + body;
////        messageHelper.setText(messageWithAttachment, true);
//
//        javaMailSender.send(mimeMessage);
//        System.out.println("Email sent successfully to: " + recipientEmail);
//    } catch (MessagingException | MailException e) {
//        System.err.println("Failed to send email to " + recipientEmail + ": " + e.getMessage());
//    }
//}

}