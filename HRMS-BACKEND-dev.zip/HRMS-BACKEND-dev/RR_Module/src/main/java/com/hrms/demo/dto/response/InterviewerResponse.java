package com.hrms.demo.dto.response;

import com.hrms.demo.model.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class InterviewerResponse {
    private Integer interviewerId;
    private String interviewerFirstName;
    private String interviewerLastName;
    private float interviewerExperience;
    private String interviewerContactNo;
    private String interviewerEmail;
    private List<SkillResponse> skillsId;
    private OwnerResponse userId;
}
