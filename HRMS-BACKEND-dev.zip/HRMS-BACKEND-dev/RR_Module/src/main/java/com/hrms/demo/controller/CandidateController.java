package com.hrms.demo.controller;

import com.hrms.demo.dto.request.CandidateRequest;
import com.hrms.demo.dto.response.CandidateListResponse;
import com.hrms.demo.dto.response.CandidateResponse;

import com.hrms.demo.dto.response.CandidateRrDTO;
import com.hrms.demo.service.CandidateService;

import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;

@Slf4j
@RestController
@RequestMapping("/api/v1/candidate")
public class CandidateController {
    @Autowired
    private CandidateService candidateService;

    @PostMapping("/save")
    public CandidateResponse SaveCandidateData(@Valid @RequestBody CandidateRequest candidateRequest) {
        log.info("CandidateController----------SaveCandidateData----------{}",candidateRequest);
        return candidateService.saveCandidate(candidateRequest);

    }

    @DeleteMapping("/delete/{candidateId}")
    public ResponseEntity<Void> deleteCandidateById(@PathVariable Integer candidateId) {
        candidateService.deleteCandidateById(candidateId);
        log.info("CandidateController----------deleteCandidateById---------{}",candidateId);
        return ResponseEntity.noContent().build();
    }

    //Confirm are we using this API?
    @GetMapping("/list")
    public List<CandidateResponse> getCandidates() {
        log.info("CandidateController----------getCandidates------------{}");
        return this.candidateService.getListCandidates();
    }

    @GetMapping("/get/{candidateId}")
    public CandidateResponse getCandidateById(@PathVariable Integer candidateId) {
        log.info("CandidateController----------getCandidateById---------{}",candidateId);
        return this.candidateService.getCandidateById(candidateId);
    }
    //create a common method for save and update
    @PutMapping("/update/{candidateId}")
    public ResponseEntity<CandidateResponse> updateCandidateData(@Valid @PathVariable Integer candidateId, @RequestBody CandidateRequest candidateRequest) {
        CandidateResponse candidateResponse = candidateService.updateCandidate(candidateId, candidateRequest);
        if (candidateResponse != null) {
            log.info("CandidateController----------updateCandidateData---------{}",candidateId,candidateRequest);
            return ResponseEntity.ok(candidateResponse);
        } else {
            log.info("CandidateController----------updateCandidateData--------{}",candidateId,candidateRequest);
            return ResponseEntity.notFound().build();
        }
    }

    //Test this API
    @GetMapping("/getAllCandidate")
    public ResponseEntity<List<CandidateResponse>> getAllCandidates(@RequestParam(defaultValue = "0") Integer pageNumber, @RequestParam(defaultValue = "") String searchKey) {
        List<CandidateResponse> result = candidateService.getAllCandidate(pageNumber, searchKey);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/listcandidate")
    public List<CandidateResponse> getShowListCandidates(@RequestParam(value = "pageNumber", defaultValue = "0", required = false) Integer pageNumber,
                                                         @RequestParam(value = "pageSize", defaultValue = "10", required = false) Integer pageSize,
                                                         @RequestParam(value = "sortBy", defaultValue = "candidateId", required = false) String sortBy,
                                                         @RequestParam(value = "sortDir", defaultValue = "des", required = false) String sortDir) {

        return this.candidateService.getListCandidatesNew(pageNumber, pageSize, sortBy, sortDir);
    }

    //Need to discuss with UI team members also
    @GetMapping("/list/check")
    public ResponseEntity<CandidateListResponse> getShowListCandidates(@RequestParam(value = "pageNumber", defaultValue = "0", required = false) Integer pageNumber,
                                                                       @RequestParam(value = "pageSize", defaultValue = "10", required = false) Integer pageSize,
                                                                       @RequestParam(value = "searchTerm", defaultValue = "", required = false) String searchTerm) {

        CandidateListResponse candidateListResponse = candidateService.getListCandidatesOp(pageNumber, pageSize, searchTerm);
        log.info("CandidateController----------getShowListCandidates-----------{}",pageNumber,pageSize,searchTerm);
        return ResponseEntity.ok(candidateListResponse);
    }
    @GetMapping("/getRole/{skillTypeId}")
    public Set<CandidateRrDTO> getCandidateListByRole(@PathVariable Integer skillTypeId) {
        log.info("CandidateController----------getCandidateById---------{}",skillTypeId);
        return this.candidateService.getListOfCandidatesBySkillType(skillTypeId);
    }
}