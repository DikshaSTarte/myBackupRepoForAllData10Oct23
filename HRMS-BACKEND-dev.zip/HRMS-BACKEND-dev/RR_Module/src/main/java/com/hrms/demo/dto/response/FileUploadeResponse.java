package com.hrms.demo.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.Column;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FileUploadeResponse {
    private Integer fileId;
    private String fileName;
    private Long fileSize;
    private String fileType;
    private String filePath;
}
