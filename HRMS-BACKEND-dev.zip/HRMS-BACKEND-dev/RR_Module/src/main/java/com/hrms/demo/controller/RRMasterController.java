package com.hrms.demo.controller;

import com.hrms.demo.dto.request.CreateRrRequest;
import com.hrms.demo.dto.request.RRMasterRequest;
import com.hrms.demo.dto.request.RrFilterRequest;
import com.hrms.demo.dto.response.*;
import com.hrms.demo.model.Candidate;
import com.hrms.demo.model.RRMaster;
import com.hrms.demo.repository.RRMasterRepository;
import com.hrms.demo.service.RRCountService;
import com.hrms.demo.service.RRMasterService;
import javax.validation.Valid;
import javax.validation.constraints.Null;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Set;

@Slf4j
@RestController
@RequestMapping("/api/v1/rr")
public class RRMasterController {
    @Autowired
    private RRMasterService rrMasterService;
    @Autowired
    private RRMasterRepository rrMasterRepository;
    @Autowired
    private RRCountService rrCountService;
    @PostMapping("/save")
    public RRMasterResponse saveRrMasterData(@Valid @RequestBody CreateRrRequest createRrRequest){
        System.out.println("RR Added Successfully...");
        log.info("RRMasterController------saveRrMasterData--{}",createRrRequest);
        return rrMasterService.createRRMaster(createRrRequest);
    }
    @DeleteMapping("/delete/{rrMasterId}")
    public ResponseEntity<Void> deleteRrMasterData(@PathVariable Integer rrMasterId){
        rrMasterService.deleteRRMasterById(rrMasterId);
        System.out.println("RR Deleted Successfully...");
        log.info("RRMasterController------deleteRrMasterData--{}",rrMasterId);
        return ResponseEntity.noContent().build();
    }
    @GetMapping("/list")
    public List<RRMasterResponse> getShowListOfRRMaster() {
        log.info("RRMasterController------getShowListOfRRMaster--{}");
        return this.rrMasterService.getAllRRMaster();
    };
    @GetMapping("/ownerList")
    public Set<OwnerResponse> getListOfOwnerID() {
        log.info("RRMasterController------getListOfOwners--{}");
        return this.rrMasterService.getListOfOwners();
    };
    @GetMapping("/listOfCandidates/{rrId}")
    public List<CandidateForRrResponse> getShowListOfCandidatesByRR(@PathVariable Integer rrId) {
        log.info("RRMasterController------getShowListOfCandidatesByRR--{}",rrId);
        return this.rrMasterService.getAllCandidatesByRrId(rrId);
    }
    @GetMapping("/get/{rrMasterId}")
    public RrResponse getRrMasterById(@PathVariable Integer rrMasterId){
        log.info("RRMasterController------getRrMasterById--{}",rrMasterId);
        return this.rrMasterService.getRRMasterById(rrMasterId);
    }
    @PutMapping("/update/{rrMasterId}")
    public ResponseEntity<RrUpdateResponse> updateRRMasterData(@Valid @PathVariable Integer rrMasterId , @RequestBody RRMasterRequest rrMasterRequest ){
        RrUpdateResponse rrMasterResponse= rrMasterService.updateRRMasterById(rrMasterId,rrMasterRequest);
        if(rrMasterResponse!=null){
            System.out.println("RR updated successfully...");
            log.info("RRMasterController------updateRRMasterData--{}",rrMasterId,rrMasterRequest);
            return ResponseEntity.ok(rrMasterResponse);
        }else {
            System.out.println("Check for RR once again...\n RR not found!!!");
            log.error("RRMasterController------updateRRMasterData--{}",rrMasterId,rrMasterRequest);
            return ResponseEntity.notFound().build();
        }
    }
    @GetMapping("/getOwner/{ownerId}")
    public List<RrResponse> getRrListByOwnerId(@PathVariable Integer ownerId){
        log.info("RRMasterController----------getRrListByOwnerId--------{}");
        return this.rrMasterService.getRRByOwnerId(ownerId);
    }
    @GetMapping("/listRR")
    public ResponseEntity<RRlistResponse> getShowListRRMaster(@RequestParam(value = "pageNumber",defaultValue = "0",required = false) Integer pageNumber,
                                                              @RequestParam(value = "pageSize",defaultValue = "10",required = false) Integer pageSize,
                                                              @RequestParam(value = "searchTerm",defaultValue = "",required = false)String searchTerm,
                                                              @RequestParam(required = false) List<String> companyNames,
                                                              @RequestParam(required = false) List<String> userRoles,
                                                              @RequestParam(required = false) List<String> ownerRoles,
                                                              @RequestParam(required = false) List<String> ownerNames ){

        RRlistResponse rRlistResponse=rrMasterService.getAllRRMasterPg(pageNumber, pageSize, searchTerm,companyNames, userRoles, ownerRoles, ownerNames);
        log.info("RRMasterController------getShowListRRMaster--{}",pageNumber, pageSize, searchTerm,companyNames, userRoles, ownerRoles, ownerNames);
        return ResponseEntity.ok(rRlistResponse);
    }

    @PostMapping ("/listRR2")
    public ResponseEntity<RRlistResponse> getShowListRRMaster(@RequestBody RrFilterRequest rrFilterRequest){


        RRlistResponse rRlistResponse=rrMasterService.getAllRRMasterPgx(rrFilterRequest.getPageNumber(), rrFilterRequest.getPageSize(), rrFilterRequest.getSearchTerm(),rrFilterRequest);
        log.info("RRMasterController------getShowListRRMaster--{}",rrFilterRequest.getPageNumber(), rrFilterRequest.getPageSize(), rrFilterRequest.getSearchTerm());
        return ResponseEntity.ok(rRlistResponse);
    }

    @GetMapping("/preMonthTrend")
    public RRStatusTrendsResponse getPreMonthOfRr() {
        log.info("RRMasterController------getPreMonthOfRr--{}");
        return this.rrCountService.getPreMonthTrend();
    }

    @GetMapping("/getRCDataForCustomer")
    public List<RCResponse> getRCForCompany(){
        log.info("RRMasterController------getRCForCompany--{}");
        return this.rrCountService.getRCForCustomer();
    }


    @GetMapping("/listOfCandidatesPg/{rrId}")
    public CandidateListResponseForRR getShowListOfCandidatesByRR(@PathVariable Integer rrId,@RequestParam(value = "pageNumber",defaultValue = "0",required = false) Integer pageNumber,
                                                                  @RequestParam(value = "pageSize",defaultValue = "10",required = false) Integer pageSize,
                                                                  @RequestParam(value = "sortBy",defaultValue = "createdOn",required = false)String sortBy,
                                                                  @RequestParam(value = "sortDir",defaultValue = "des",required = false)String sortDir,
                                                                  @RequestParam(value = "searchTerm",defaultValue = "",required = false)String searchTerm ) {
        log.info("RRMasterController------getShowListOfCandidatesByRR--{}",rrId);
        return this.rrMasterService.getAllCandidatesByRrIdPg(rrId,pageNumber, pageSize, sortBy, sortDir,searchTerm);
    }

//    @GetMapping("/masterFilter")
//    public ResponseEntity<List<RRMasterResponse>> getFilteredRRMasters(
//            @RequestParam(required = false) List<String> companyNames,
//            @RequestParam(required = false) List<String> userRoles,
//            @RequestParam(required = false) List<String> ownerRoles,
//            @RequestParam(required = false) List<String> ownerNames
//    ) {
//        List<RRMasterResponse> filteredRRMasters = rrMasterService.getFilteredData(companyNames, userRoles, ownerRoles, ownerNames);
//        return ResponseEntity.ok(filteredRRMasters);
//    }

    @PostMapping("/getOwner/rrList/{ownerId}")
    public RrListByOwnerResponse getRrListByOwnerIdPagination(@PathVariable Integer ownerId,@RequestBody RrFilterRequest rrFilterRequest){

        log.info("InterviewerMapperController------getAllFeedbacksListByRrOp--{}");

        return this.rrMasterService.getRRByOwnerIdPagination(ownerId,rrFilterRequest.getPageNumber(),rrFilterRequest.getPageSize(),rrFilterRequest.getSearchTerm(),rrFilterRequest);

    }


}
