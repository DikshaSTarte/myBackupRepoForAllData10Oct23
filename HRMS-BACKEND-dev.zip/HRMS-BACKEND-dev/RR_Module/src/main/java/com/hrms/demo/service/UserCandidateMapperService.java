package com.hrms.demo.service;

import com.hrms.demo.dto.request.CandidateForUserRequest;
import com.hrms.demo.dto.request.RRForUserRequest;
import com.hrms.demo.dto.response.UserCandidateMapperResponse;
import com.hrms.demo.model.UserCandidateMapper;

import java.util.List;
public interface UserCandidateMapperService {
    List<UserCandidateMapperResponse> getCandidateUserId(Integer userId);
    UserCandidateMapper saveCandidateForUser(CandidateForUserRequest userRequest);
}