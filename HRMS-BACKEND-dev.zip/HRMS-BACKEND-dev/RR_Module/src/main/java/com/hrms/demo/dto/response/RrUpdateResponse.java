package com.hrms.demo.dto.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrms.demo.model.RRStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RrUpdateResponse {
    private Integer requiredCount ;
    private OwnerResponse ownerId ;
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate startDate ;
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate endDate ;
    private RRStatus rrStatus ;
    private FileUploadeResponse fileId;
    private List<SkillResponse> skillsets;
    private CompanyResponse company;
    private Integer experience;
}