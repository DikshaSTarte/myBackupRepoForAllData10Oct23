package com.hrms.demo.exceptionHandler.exception;

public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String s) {

    super(s);

    }
}
