
package com.hrms.demo.controller;

import com.hrms.demo.constants.ConstantsForApis;
import com.hrms.demo.dto.request.SkillTypeRequest;
import com.hrms.demo.dto.response.CompanyListResponse;
import com.hrms.demo.dto.response.SkillTypeListResponse;
import com.hrms.demo.dto.response.SkillTypeResponse;
import com.hrms.demo.exceptionHandler.exception.ResourceNotFoundException;
import com.hrms.demo.globleexception.SkillTypeAlreadyExistException;
import com.hrms.demo.model.SkillTypeEntity;
import com.hrms.demo.service.SkillTypeService;
import javax.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@Slf4j
@RestController
@RequestMapping("/api/v1/skillTypes")

public class SkillTypeController {

    @Autowired
    private SkillTypeService skillTypeService;

    @GetMapping("/list")
    public List<SkillTypeResponse> getAllSkillTypes() {
        log.info("SkillTypeController-----getAllSkillTypes----{}");
        return skillTypeService.getAllSkillTypes();
    }
    @PostMapping("/save")
    public ResponseEntity<SkillTypeEntity> createSkillType(@Valid @RequestBody SkillTypeRequest skillTypeRequest) throws SkillTypeAlreadyExistException {
        SkillTypeEntity createdSkillType = skillTypeService.createSkillType(skillTypeRequest);
        log.info("SkillTypeController-----createSkillType----{}",skillTypeRequest);
        return new ResponseEntity<>(createdSkillType, HttpStatus.CREATED);
    }

    @PutMapping("/update/{id}")
    public SkillTypeResponse updateSkillType(@PathVariable Integer id, @Valid @RequestBody SkillTypeRequest skillTypeRequest) throws ResourceNotFoundException {
        log.info("SkillTypeController-----updateSkillType----{}",id,skillTypeRequest);
        return skillTypeService.updateSkillType(id, skillTypeRequest);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteSkillType(@PathVariable Integer id) throws ResourceNotFoundException {
        skillTypeService.deleteSkillType(id);
        log.info("SkillTypeController-----deleteSkillType----{}",id);
        return ResponseEntity.noContent().build();
    }
    @GetMapping("/pagination")
    public Page<SkillTypeEntity> searchSkillTypes(
            @RequestParam(required = false) String searchKeyword,
            @RequestParam(defaultValue = "0") int pageNo,
            @RequestParam(defaultValue = "5") int pageSize) {
        return skillTypeService.searchSkillTypes(searchKeyword, pageNo, pageSize);
    }

    @GetMapping("/list/check")
    public ResponseEntity<SkillTypeListResponse> getShowListSkillType(@RequestParam(value = "pageNumber",defaultValue = "0",required = false) Integer pageNumber,
                                                                    @RequestParam(value = "pagesize",defaultValue = "10",required = false) Integer pageSize,
                                                                    @RequestParam(value = "searchTerm",defaultValue = "",required = false)String searchTerm ){


        SkillTypeListResponse skillTypeListResponse=skillTypeService.getListSkillTypeOp(pageNumber, pageSize, searchTerm);
        log.info("SkillTypeController------getShowListCompany--{}");
        return ResponseEntity.ok(skillTypeListResponse);
    }

}

