package com.hrms.demo.globleexception;

public class RRAlreadyExistsException extends RuntimeException {

    public RRAlreadyExistsException() {
        super("RRMaster with the same Company and SkillEntity combination already exists.");
    }

    public RRAlreadyExistsException(String message) {
        super(message);
    }
}