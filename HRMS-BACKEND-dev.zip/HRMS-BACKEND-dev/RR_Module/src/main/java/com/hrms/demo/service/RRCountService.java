package com.hrms.demo.service;

import com.hrms.demo.dto.response.RCResponse;
import com.hrms.demo.dto.response.RRStatusTrendsResponse;

import java.util.List;

public interface RRCountService {
    RRStatusTrendsResponse getPreMonthTrend();
    List<RCResponse> getRCForCustomer();
}
