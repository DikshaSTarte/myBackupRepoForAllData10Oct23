package com.hrms.demo.serviceImpl;

import com.hrms.demo.globleexception.NoDataFoundException;
import com.hrms.demo.model.User;
import com.hrms.demo.repository.UserRepository;
import com.hrms.demo.service.ResetService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.Optional;
@Slf4j
@Service
public class ResetServiceImpl implements ResetService {
    @Autowired
    private UserRepository usersRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;


    @Override
    public void updatePassword(String username, String newPassword) {
        log.info("ResetServiceImpl----------updatePassword------{}",username,newPassword);
        Optional<User> optionalUser = usersRepository.findByUsername(username);
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();

// Set the new password
            user.setPassword(passwordEncoder.encode(newPassword));

// Save the updated user to the database
            usersRepository.save(user);
        } else {
            log.error("ResetServiceImpl----------updatePassword------{}",username,"User not found with username");
            throw new UsernameNotFoundException("User not found with username: " + username);
        }
    }
    @Override
    public User findByUsername(String username) {
        log.info("ResetServiceImpl------------findByUsername-------{}",username);
        Optional<User> user = usersRepository.findByUsername(username);
        if (user.isPresent()) {
            return user.get();
        } else {
            log.error("ResetServiceImpl------------findByUsername-------{}",username,"User not found with username");
            throw new NoDataFoundException("User not found with username: " + username);
        }
    }
}
