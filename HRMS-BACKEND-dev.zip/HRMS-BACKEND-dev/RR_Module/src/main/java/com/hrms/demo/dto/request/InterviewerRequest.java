package com.hrms.demo.dto.request;

import javax.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InterviewerRequest {
 @NotBlank(message = "InterviewerFirstName must not be blank.")
 @Pattern(regexp = "^[a-zA-Z ]+$", message = "InterviewerFirstName can only contain letters and spaces.")
 private String interviewerFirstName;
 @NotBlank(message = "InterviewerLastName must not be blank.")
 @Pattern(regexp = "^[a-zA-Z ]+$", message = "InterviewerLastName can only contain letters and spaces.")
 private String interviewerLastName;
 @NotNull
 @Min(value = 0, message = "Interviewer experience must be greater than or equal to 0.")
 private float interviewerExperience;

 @NotBlank(message = "Interviewer contact number is required")
 @Pattern(regexp = "\\d{10}", message = "Interviewer contact number must be a 10-digit number")
 private String interviewerContactNo;

 @NotBlank(message = "Interviewer email must not be blank.")
 @Email(message = "Interviewer email is not valid.")
 private String interviewerEmail;
 private List<Integer> skillsId;
// private Integer userId;
}
