package com.hrms.demo.service;
import com.hrms.demo.dto.request.CandidateStatusRequest;
import com.hrms.demo.dto.response.CandidateStatusResponse;
import java.util.List;

public interface CandidateStatusService {
    CandidateStatusResponse saveCandidateStatus(CandidateStatusRequest candidateStatusRequest);
    public String deleteCandidateStatusById(Integer candidateStatusId);
    CandidateStatusResponse getCandidateStatusById(Integer candidateStatusId);
//    CandidateStatusResponse updateCandidateStatus(Integer candidateStatusId,CandidateStatusRequest candidateStatusRequest);
    List<CandidateStatusResponse> getListCandidateStatus();
}
