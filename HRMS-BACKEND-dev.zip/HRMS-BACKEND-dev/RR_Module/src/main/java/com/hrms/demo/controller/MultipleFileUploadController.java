package com.hrms.demo.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

@RestController
public class MultipleFileUploadController {
    @PostMapping("/upload/multiple")
    public ResponseEntity<String> handleFileUpload(@RequestParam("files") MultipartFile[] files) {
        // Handle the uploaded files
        for (MultipartFile file : files) {
            // Process each file
            if (!file.isEmpty()) {
                // Save or process the file
                // Example: file.transferTo(new File("path/to/save/" + file.getOriginalFilename()));
                try {
                    // Save or process the file
                    file.transferTo(new File("C:\\Users\\MFSPC004\\Downloads\\uploadMultipleFileshere\\" + file.getOriginalFilename()));
                } catch (IOException e) {
                    // Handle the exception if the file transfer fails
                    return new ResponseEntity<>("Failed to upload file: " + file.getOriginalFilename(), HttpStatus.INTERNAL_SERVER_ERROR);
                }
            }
        }

        return new ResponseEntity<>("Files uploaded successfully.", HttpStatus.OK);
    }
}
