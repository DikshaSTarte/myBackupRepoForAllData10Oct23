package com.hrms.demo.dto.response;

import com.hrms.demo.model.Candidate;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InterviewerFeedbackResponse {
    private Integer interviewerFdbkId;
    private Candidate candidateDetails;
    private Integer interviewerFdbkRatings;
    private String interviewerFdbkDescp;
}
