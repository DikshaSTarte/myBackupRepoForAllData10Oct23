package com.hrms.demo.mapper;

import com.hrms.demo.dto.response.CandidateStatusResponse;
import com.hrms.demo.dto.response.RRMasterResponse;
import com.hrms.demo.model.CandidateStatus;
import com.hrms.demo.model.RRMaster;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class RRMapper {

    @Autowired
    private ModelMapper modelMapper;

    public RRMasterResponse rrMasterMapper(RRMaster rrMaster)
    {
        RRMasterResponse rrMasterResponse=new RRMasterResponse();
        rrMasterResponse=modelMapper.map(rrMaster,RRMasterResponse.class);
        return  rrMasterResponse;
    }

    public List<RRMasterResponse>rrMasterListMpper(List<RRMaster> rrMasterList)
    {
        List<RRMasterResponse> rrMasterResponseList=rrMasterList.stream()
                .map(rrMaster->modelMapper.map(rrMaster,RRMasterResponse.class))
                .collect(Collectors.toList());
        return rrMasterResponseList;
    }

}
