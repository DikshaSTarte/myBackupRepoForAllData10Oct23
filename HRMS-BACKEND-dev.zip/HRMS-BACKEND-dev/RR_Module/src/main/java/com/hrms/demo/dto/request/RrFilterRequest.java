package com.hrms.demo.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class  RrFilterRequest{
   private List<Integer> companyIds;
   private  List<Integer> userRolesIds;
   private List<Integer> ownerRoleIds;
   private List<Integer> ownerNamesIds;
   private Integer pageNumber=0;
   private Integer pageSize=10;
   private String searchTerm=" ";
}
