package com.hrms.demo.serviceImpl;

import com.hrms.demo.dto.request.CreateSkillRequest;
import com.hrms.demo.dto.response.*;
import com.hrms.demo.exceptionHandler.exception.ResourceNotFoundException;
import com.hrms.demo.globleexception.SkillAlreadyExistForSKillTypeException;
import com.hrms.demo.globleexception.SkillSetAlreadyExistException;
import com.hrms.demo.model.*;
import com.hrms.demo.repository.SkillEntityRepository;
import com.hrms.demo.repository.SkillTypeEntityRepository;
import com.hrms.demo.dto.request.SkillRequest;

import com.hrms.demo.service.SkillService;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.*;

@Slf4j
@Service
public class SkillServiceImpl implements SkillService {

    @Autowired
    private SkillEntityRepository skillRepository;

    @Autowired
    private SkillTypeEntityRepository skillTypeRepository;

    @Override
    public List<SkillResponse> getAllSkills() {
        log.info("SkillServiceImpl----------------getAllSkills-----------{}");
        List<SkillEntity> skills = skillRepository.findByActive(true);
        List<SkillResponse> responses = new ArrayList<>();
        for (SkillEntity skill : skills) {
            SkillResponse response = new SkillResponse();
            response.setId(skill.getId());
            response.setSkillSet(skill.getSkillSet());
            response.setSkillType(new SkillTypeResponse(skill.getSkillType().getId(),skill.getSkillType().getSkillTypeName()));

            responses.add(response);
        }
        log.info("SkillServiceImpl----------------getAllSkills-----------{}");
        return responses;
    }

    @Override
    public SkillResponse getSkillById(Integer id) {
        log.info("SkillServiceImpl----------------getSkillById-----------{}",id);
        SkillEntity skillOptional = skillRepository.findByActiveAndId(true,id);
        if (skillOptional.isActive()) {
            SkillEntity skill = skillOptional;
            SkillResponse response = new SkillResponse();
            response.setId(skill.getId());
            response.setSkillSet(skill.getSkillSet());
            response.setSkillType(new SkillTypeResponse(skill.getSkillType().getId(),skill.getSkillType().getSkillTypeName()));
            return response;
        }
        log.error("SkillServiceImpl---------------getSkillById-------{}",id,"Skill not found with id ");
        throw new ResourceNotFoundException("Skill not found with id " + id);
    }
    @Override
//    public SkillResponse createSkill(CreateSkillRequest skillRequest) throws SkillSetAlreadyExistException {
//        log.info("SkillServiceImpl---------------createSkill----------{}",skillRequest);
////       Optional<SkillEntity> existSkillSet=skillRepository.findByActiveAndSkillSet(true,skillRequest.getSkillSet());
////        if(existSkillSet.isPresent()){
////            log.error("SkillServiceImpl---------------createSkill----------{}",skillRequest.getSkillSet(),"SkillSet Already Exist");
////            throw new SkillSetAlreadyExistException("SkillSetAlreadyExistException");
////        }
//        SkillEntity skill = new SkillEntity();
//
////        skill.setSkillSet(skillRequest.getSkillSet());
//        for (String skill1 : skillRequest.getSkillSet()){
//            Optional<SkillEntity> skillEntity = skillRepository.findBySkillSet(skill1);
//            SkillResponse response = new SkillResponse();
//            response.setSkillSet(skillEntity.get().getSkillSet());
//            return response;
//        }
//
//        Optional<SkillTypeEntity> skillTypeOptional = skillTypeRepository.findById(skillRequest.getSkillType());
//
//        if (skillTypeOptional.isPresent()) {
//            skill.setSkillType(skillTypeOptional.get());
//            SkillEntity savedSkill = skillRepository.save(skill);
//            SkillResponse response = new SkillResponse();
//            response.setId(savedSkill.getId());
//            response.setSkillSet(savedSkill.getSkillSet());
//            response.setSkillType(new SkillTypeResponse(skill.getSkillType().getId(),skill.getSkillType().getSkillTypeName()));
//            return response;
//        }
//        log.error("SkillServiceImpl------------createSkill-----------{}",skillRequest.getSkillType(),"Skill type not found with id");
//        throw new ResourceNotFoundException("Skill type not found with id " + skillRequest.getSkillType());
//    }
    //===========================================================>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    public SkillDTO createSkill(CreateSkillRequest skillRequest) throws SkillSetAlreadyExistException, SkillAlreadyExistForSKillTypeException {
        log.info("SkillServiceImpl---------------createSkillsForSkillType----------{}", skillRequest);

        Optional<SkillTypeEntity> skillTypeOptional = skillTypeRepository.findByActiveAndId(true, skillRequest.getSkillType());
        if (!skillTypeOptional.isPresent()) {
            log.error("SkillServiceImpl------------createSkill-----------{}", skillRequest.getSkillType(), "Skill type not found with id");
            throw new ResourceNotFoundException("Role not found with id " + skillRequest.getSkillType());
        }
        SkillTypeEntity skillType = skillTypeOptional.get();
        SkillDTO response = new SkillDTO();
        List<SkillDTO> skillList = new ArrayList<>();

        for (String skillSet : skillRequest.getSkillSet()) {
            Optional<SkillEntity> existingSkill = skillRepository.findByActiveAndSkillSetAndSkillType_skillTypeName(true, skillSet, skillType.getSkillTypeName());

            if (existingSkill.isPresent()) {
                log.error("SkillServiceImpl---------------createSkill----------{}", skillSet, "SkillSet Already Exist");
                throw new SkillAlreadyExistForSKillTypeException(" This skillSet already exists for " + skillTypeOptional.get().getSkillTypeName() + " role");
            }
            SkillEntity skill = new SkillEntity();
            skill.setSkillSet(skillSet);
            skill.setSkillType(skillType);
            SkillEntity savedSkill = skillRepository.save(skill);

// Create a SkillResponse for the saved skill and add it to the list
            SkillDTO skillResponse = new SkillDTO();
            skillResponse.setId(savedSkill.getId());
            skillResponse.setSkillType(new SkillTypeResponse(skillType.getId(), skillType.getSkillTypeName()));
            skillResponse.setSkillSet(skill.getSkillSet());
            skillList.add(skillResponse);
        }
        response.setSkillResponseList(skillList);

        return response;
    }
    @Override
    public SkillResponse updateSkill(Integer id, SkillRequest skillRequest) {
        log.info("SkillServiceImpl-------------updateSkill-----------{}",id,skillRequest);
        Optional<SkillEntity> skillOptional = skillRepository.findById(id);
        if (skillOptional.isPresent()) {
            SkillEntity skill = skillOptional.get();
            skill.setSkillType(skillOptional.get().getSkillType());
            skill.setSkillSet(skillRequest.getSkillSet());
                SkillEntity savedSkill = skillRepository.save(skill);
                SkillResponse response = new SkillResponse();
                response.setId(savedSkill.getId());
                response.setSkillSet(savedSkill.getSkillSet());
                response.setSkillType(new SkillTypeResponse(skill.getSkillType().getId(),skill.getSkillType().getSkillTypeName()));
                return response;
        }
        log.error("SkillServiceImpl-----------updateSkill---------{}",id,"Skill not found with id");
        throw new ResourceNotFoundException("Skill not found with id " + id);
    }
    @Override
    public void deleteSkill(Integer id) {
        log.info("SkillServiceImpl----------------deleteSkill-----------{}",id);
         Optional<SkillEntity> skill = skillRepository.findById(id);
        skill.get().setActive(false);
        skillRepository.save(skill.get());
        System.out.println("Skill Successfully Deleted");
    }

    @Override
//    public List<SkillTypeDTO> getSkillsBySkillTypeId(Integer skillTypeId) {
//        log.info("SkillServiceImpl---------------getSkillsBySkillTypeId-------{}",skillTypeId);
//        Optional<SkillTypeEntity> skillOptional = skillTypeRepository.findByActiveAndId(true,skillTypeId);
//         List<SkillEntity> skills = skillRepository.findByActiveAndSkillType(true,skillOptional.get());
//        List<SkillTypeDTO> responses = new ArrayList<>();
//        for (SkillEntity skill : skills) {
//            SkillTypeDTO response = new SkillTypeDTO();
//            response.setId(skill.getId());
//            response.setSkillSet(skill.getSkillSet());
//            responses.add(response);
//        }
//        return responses ;
//    }
    public List<SkillTypeDTO> getSkillsBySkillTypeId(Integer skillTypeId) {
        log.info("SkillServiceImpl---------------getUniqueSkillsBySkillTypeId-------{}", skillTypeId);
        Optional<SkillTypeEntity> skillOptional = skillTypeRepository.findByActiveAndId(true, skillTypeId);
        List<SkillEntity> skills = skillRepository.findByActiveAndSkillType(true, skillOptional.get());

        Set<String> uniqueSkillSet = new HashSet<>();  // Using HashSet to store unique skills
        List<SkillTypeDTO> responses = new ArrayList<>();

        for (SkillEntity skill : skills) {
            String skillSet = skill.getSkillSet();

            // Check if the skill is unique before adding it to the response
            if (!uniqueSkillSet.contains(skillSet)) {
                uniqueSkillSet.add(skillSet);  // Add the skill to the unique set
                SkillTypeDTO response = new SkillTypeDTO();
                response.setId(skill.getId());
                response.setSkillSet(skillSet);
                responses.add(response);
            }
        }

        return responses;
    }
    @Override
    public SkillEntityListResponse getListSkillsPg(Integer pageNumber, Integer pageSize, String searchTerm) {
        log.info("SkillServiceImpl-----------getListSkillsPg----------{}",pageNumber,pageSize,searchTerm);
        List<SkillEntity> all;
        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        long totalSkillEntities;

        if (searchTerm != null && !searchTerm.isEmpty()) {
            all = skillRepository.findBySearchTermAndActive(searchTerm, pageable);
            totalSkillEntities = all.size(); // Get the count from the list size
        } else {
            Page<SkillEntity> skillEntityPage = skillRepository.findByActiveOrderByIdDesc(true,pageable);
            all = skillEntityPage.getContent();
            totalSkillEntities = skillRepository.countByActive(true); // Get the total count separately
        }

        List<SkillResponse> responses = new ArrayList<>();
        for (SkillEntity skill : all) {
            SkillResponse response = new SkillResponse();
            response.setId(skill.getId());
            response.setSkillType(new SkillTypeResponse(skill.getSkillType().getId(),skill.getSkillType().getSkillTypeName()));
            response.setSkillSet(skill.getSkillSet());

            responses.add(response);
        }

    //    System.out.println("Total candidates: " + totalSkillEntities);
        log.info("SkillServiceImpl-----------getListSkillsPg----------{}",pageNumber,pageSize,searchTerm);
        return new SkillEntityListResponse(totalSkillEntities, responses);
    }

    /*  @Override
    public SkillEntityListResponse getListSkillsPg(Integer pageNumber, Integer pageSize, String searchTerm) {
        log.info("SkillServiceImpl-----------getListSkillsPg----------{}",pageNumber,pageSize,searchTerm);
        List<SkillEntity> all;
        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        long totalSkillEntities;

        if (searchTerm != null && !searchTerm.isEmpty()) {
            all = skillRepository.findBySearchTerm(searchTerm, pageable);
            totalSkillEntities= skillRepository.countByActiveAndSearchTerm(searchTerm) ;
           // totalSkillEntities = all.size(); // Get the count from the list size
        } else {
            all = skillRepository.findByActiveOrderByIdDesc(true, pageable).getContent();
            totalSkillEntities = skillRepository.countByActive(true);
        }

        List<SkillResponse> responses = new ArrayList<>();
        for (SkillEntity skill : all) {
            SkillResponse response = new SkillResponse();
            response.setId(skill.getId());
            response.setSkillType(new SkillTypeResponse(skill.getSkillType().getId(),skill.getSkillType().getSkillTypeName()));
            response.setSkillSet(skill.getSkillSet());

            responses.add(response);
        }

    //    System.out.println("Total candidates: " + totalSkillEntities);
        log.info("SkillServiceImpl-----------getListSkillsPg----------{}",pageNumber,pageSize,searchTerm);
        return new SkillEntityListResponse(totalSkillEntities, responses);
    }*/
}

