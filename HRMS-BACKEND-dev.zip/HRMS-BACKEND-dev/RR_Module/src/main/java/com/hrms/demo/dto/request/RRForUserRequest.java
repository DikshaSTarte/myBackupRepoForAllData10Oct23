package com.hrms.demo.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RRForUserRequest {
    private Integer userId;
    private List<Integer> rrId;
}