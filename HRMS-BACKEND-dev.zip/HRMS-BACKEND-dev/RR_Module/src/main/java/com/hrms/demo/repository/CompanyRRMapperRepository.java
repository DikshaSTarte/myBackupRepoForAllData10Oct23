package com.hrms.demo.repository;

import com.hrms.demo.model.CompanyRRMapper;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CompanyRRMapperRepository extends JpaRepository<CompanyRRMapper,Integer>{
    CompanyRRMapper findByActiveAndCompanyRRMapperId(boolean active, Integer CompanyRRMapperId);
}
