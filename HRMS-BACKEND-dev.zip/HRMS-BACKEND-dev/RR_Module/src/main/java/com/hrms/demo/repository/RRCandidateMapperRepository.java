
package com.hrms.demo.repository;
import com.hrms.demo.model.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
@Repository
public interface RRCandidateMapperRepository extends JpaRepository<RRCandidateMapper,Integer> {
   List<RRCandidateMapper> findByActive(boolean b);
   List<RRCandidateMapper> findByRrId_RrMasterIdAndActive(Integer rrId,boolean b);
//      List<RRCandidateMapper> findByRrIdAndCandidateId(Integer rrId , Integer candidateId);
List<RRCandidateMapper> findByRrIdAndCandidateId_candidateFirstNameStartingWith(RRMaster rrMaster,String candiName);
   List<RRCandidateMapper> findByRrIdAndCandidateId_candidateFirstNameStartingWithOrCandidateId_candidateLastNameStartingWith(RRMaster rrMaster, String firstName, String lastName);

   Page<RRCandidateMapper> findByRrId_RrMasterIdAndActive(Integer rrId, boolean b, Pageable pageable);

   List<RRCandidateMapper> findByActiveAndRrId(boolean active, RRMaster rrMaster);

//   Boolean findByActiveAndCandidateIdAndCandidateStatus(boolean active,Candidate candidate,CandidateStatus candidateStatus);

   Integer countByActiveAndCandidateIdAndCandidateStatus(boolean active,Candidate candidate,CandidateStatus candidateStatus);
   RRCandidateMapper findByActiveAndCandidateIdAndRrId(boolean b, Candidate candidate, RRMaster rrMaster);

   Page<RRCandidateMapper> findByRrId_RrMasterIdAndActiveOrderByRrId_RrMasterIdDesc(Integer rrId, boolean b, Pageable pageable);


//   Integer countByCandidateIdAndCandidateStatusAndDateBetween(CandidateStatus selected, LocalDate sDate, LocalDate eDate);
}

