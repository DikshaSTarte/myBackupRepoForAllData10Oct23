package com.hrms.demo.repository;
import com.hrms.demo.model.CandidateStatus;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface CandidateStatusRepository extends JpaRepository<CandidateStatus, Integer> {
    CandidateStatus findByActiveAndCandidateStatusId(boolean active, Integer CandidateStatusId);
    List<CandidateStatus> findByActive(boolean b);
    CandidateStatus findByActiveAndCandidateStatusName(boolean active, String CandidateStatusName);

    CandidateStatus getCandidateStatusBycandidateStatusId(int i);
    // List<CandidateStatus> findByActiveAndCandidateStatusNameContaining(boolean active, String candidateStatusName);
}


