package com.hrms.demo.serviceImpl;

import com.hrms.demo.dto.request.CandidateFeedbackFormRequest;

import com.hrms.demo.dto.request.InterviewerCandidateRequest;
import com.hrms.demo.dto.request.InterviewerMapperRequest;

import com.hrms.demo.dto.response.*;

//import com.hrms.demo.globleexception.ObjectNotExistException;
import com.hrms.demo.globleexception.NotFoundException;
import com.hrms.demo.globleexception.ObjectNotExistException;
import com.hrms.demo.model.*;
import com.hrms.demo.repository.*;
import com.hrms.demo.service.InterviewerMapperService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Slf4j
@Service
public class InterviewerMapperServiceImpl implements InterviewerMapperService {
    @Autowired
    private InterviewerMapperRepository interviewerMapperRepository;
    @Autowired
    private CandidateRepository candidateRepository;
    @Autowired
    private InterviewerRepository interviewerRepository;
    @Autowired
    private RRMasterRepository rrMasterRepository;
    @Autowired
    private InterviewerFeedbackRepository interviewerFeedbackRepository;
    @Autowired
    private CandidateStatusRepository candidateStatusRepository;

    @Autowired
    private InterviewerCandidateRepository interviewerCandidateRepository;
    @Autowired
    private SelectedCandidateMapperRepository selectedCandidateMapperRepository;

    @Override
    public InterviewerMapperResponse saveInterviewerFeedbackStatus(InterviewerMapperRequest interviewerMapperRequest) {
log.info("InterviewerMapperServiceImpl---------------saveInterviewerFeedbackStatus--------{}",interviewerMapperRequest);
//        InterviewerMapper interviewerMapper = new InterviewerMapper();
//          InterviewerMapper interviewerMapper = interviewerMapperRepository.findById(interviewerMapperRequest.getInterviewerMapperId()).get();
        InterviewerMapper interviewerMapper = new InterviewerMapper();
        Interviewer interviewer = interviewerRepository.findByActiveAndInterviewerId(true, interviewerMapperRequest.getInterviewerId());

        if (interviewer == null) {
            log.error("InterviewerMapperServiceImpl---------------saveInterviewerFeedbackStatus--------{}",interviewerMapperRequest.getInterviewerId(),"interviewer does not exist");
            throw new ObjectNotExistException("interviewer does not exist");
        } else {
            interviewerMapper.setInterviewerId(interviewer);
        }

        Candidate candidate = candidateRepository.findByActiveAndCandidateId(true, interviewerMapperRequest.getCandidateId());

        if (candidate == null)
            throw new ObjectNotExistException("Candidate does not exist !");

        interviewerMapper.setCandidateId(candidate);

            //System.out.println("candidate status"+candidate.getCandidateStatus());
            candidate.setParticipationInRecruitment(candidate.getParticipationInRecruitment()+1);




        RRMaster rrMaster = rrMasterRepository.findByActiveAndRrMasterId(true, interviewerMapperRequest.getRrId());

        if (rrMaster == null)

            throw new ObjectNotExistException("RR does not exist !");

        else if (rrMaster.getRrStatus().getRrStatusId() == 3) {

            throw new ObjectNotExistException("RR has been canceled !");
        }

        interviewerMapper.setRrId(rrMaster);

        boolean isFeedbackCaptured = false;

        if (!isFeedbackCaptured) {
            interviewerMapper.setFeedBackDescription(interviewerMapperRequest.getFeedBackDescription());
            isFeedbackCaptured = true; // Set the flag to true to indicate that the feedback has been captured
            interviewerMapper.setFeedbackGiven(interviewerMapperRequest.isFeedbackGiven());
            interviewerMapper.setFeedbackGiven(true);
        }
        interviewerMapper.setOverallRating(interviewerMapperRequest.getOverallRating());

        interviewerMapper.setSoftSkillRating(interviewerMapperRequest.getSoftskillRating());

        interviewerMapper.setBehaviourRating(interviewerMapperRequest.getBehaviourRating());

        interviewerMapper.setTechnicalRating(interviewerMapperRequest.getTechnicalRating());

        //        interviewerMapper.setInterviewerMapperId(interviewerMapperRequest.getInterviewerMapperId());

        interviewerMapperRequest.getInterviewerCandidateMapperId();
        Optional<InterviewerCandidateMapper> candidateRepositoryById = interviewerCandidateRepository.findById(interviewerMapperRequest.getInterviewerCandidateMapperId());
        InterviewerCandidateMapper interviewerCandidateMapper = new InterviewerCandidateMapper();
        interviewerCandidateMapper.setDate(interviewerMapperRequest.getInterviewDate());
        interviewerCandidateMapper.setTime(interviewerMapperRequest.getInterviewTime());
        interviewerMapper.setInterviewerCandidateMapper(candidateRepositoryById.get());
        interviewerMapper.setCandidateStatus(candidateStatusRepository.findByActiveAndCandidateStatusId(true, interviewerMapperRequest.getCandidateStatus()));

        InterviewerMapper saveData = this.interviewerMapperRepository.save(interviewerMapper);

        InterviewerMapperResponse response = interviewerMapperToInterviewerMapperResponse(saveData);
        return response;
    }

    private InterviewerMapperResponse interviewerMapperToInterviewerMapperResponse(InterviewerMapper interviewerMapper) {

        InterviewerMapperResponse interviewerMapperResponse = new InterviewerMapperResponse();

        interviewerMapperResponse.setInterviewerId(interviewerMapper.getInterviewerId());

        interviewerMapperResponse.setRrId(interviewerMapper.getRrId());

        interviewerMapperResponse.setCandidateId(interviewerMapper.getCandidateId());

        interviewerMapperResponse.setBehaviourRating(interviewerMapper.getBehaviourRating());

        interviewerMapperResponse.setTechnicalRating(interviewerMapper.getTechnicalRating());

        interviewerMapperResponse.setSoftskillRating(interviewerMapper.getSoftSkillRating());

        interviewerMapperResponse.setCandidateStatus(interviewerMapper.getCandidateStatus());

        interviewerMapperResponse.setOverallRating(interviewerMapper.getOverallRating());

        interviewerMapperResponse.setFeedBackDescription(interviewerMapper.getFeedBackDescription());

        interviewerMapperResponse.setFeedbackGiven(interviewerMapper.isFeedbackGiven());

        interviewerMapperResponse.setInterviewDate(interviewerMapper.getInterviewerCandidateMapper().getDate());

        interviewerMapperResponse.setInterviewTime(interviewerMapper.getInterviewerCandidateMapper().getTime());

        interviewerMapperResponse.setInterviewerMapperId(interviewerMapper.getInterviewerMapperId());
        return interviewerMapperResponse;

    }

    @Override
    public List<InterviewerMapperResponse> getAllFeedbacks() {
log.info("InterviewerMapperServiceImpl----------------getAllFeedbacks---------{}");
        List<InterviewerMapper> all = interviewerMapperRepository.findByActive(true);

        List<InterviewerMapperResponse> interviewerMapperResponseList1 = new ArrayList<>();
        for (InterviewerMapper interviewerMapper : all) {
            interviewerMapperResponseList1.add(interviewerMapperEntityToInterviewerMapperResponse(interviewerMapper));
        }
        return interviewerMapperResponseList1;
    }

    private InterviewerMapperResponse interviewerMapperEntityToInterviewerMapperResponse(InterviewerMapper interviewerMapper) {

        InterviewerMapperResponse interviewerMapperResponse = new InterviewerMapperResponse();

//        interviewerMapperResponse.setInterviewerMapperId(interviewerMapper.getInterviewerMapperId());
        interviewerMapperResponse.setInterviewerMapperId(interviewerMapper.getInterviewerMapperId());

        interviewerMapperResponse.setCandidateId(interviewerMapper.getCandidateId());

        interviewerMapperResponse.setFeedBackDescription(interviewerMapper.getFeedBackDescription());

        interviewerMapperResponse.setOverallRating(interviewerMapper.getOverallRating());

        interviewerMapperResponse.setBehaviourRating(interviewerMapper.getBehaviourRating());

        interviewerMapperResponse.setSoftskillRating(interviewerMapper.getSoftSkillRating());

        interviewerMapperResponse.setTechnicalRating(interviewerMapper.getTechnicalRating());

        interviewerMapperResponse.setCandidateStatus(interviewerMapper.getCandidateStatus());

        interviewerMapperResponse.setRrId(interviewerMapper.getRrId());

        interviewerMapperResponse.setInterviewerId(interviewerMapper.getInterviewerId());

        interviewerMapperResponse.setFeedbackGiven(interviewerMapper.isFeedbackGiven());

        return interviewerMapperResponse;

    }

    @Override

    public List<InterviewerMapperResponse> getAllFeedbacksByRrId(Integer rrId) {
log.info("InterviewerMapperServiceImpl---------------getAllFeedbacksByRrId----------{}",rrId);
        List<InterviewerMapperResponse> responses = new ArrayList<>();

        RRMaster rrMaster = rrMasterRepository.findByActiveAndRrMasterId(true, rrId);

        List<InterviewerMapper> feedbackList = interviewerMapperRepository.findByActiveAndRrId(true, rrMaster);

        for (InterviewerMapper interviewerMapper : feedbackList) {
            InterviewerMapperResponse interviewerMapperResponse = new InterviewerMapperResponse();

            interviewerMapperResponse.setInterviewerId(interviewerMapper.getInterviewerId());

            interviewerMapperResponse.setFeedBackDescription(interviewerMapper.getFeedBackDescription());

            interviewerMapperResponse.setRrId(interviewerMapper.getRrId());

            interviewerMapperResponse.setCandidateId(interviewerMapper.getCandidateId());

            interviewerMapperResponse.setCandidateStatus(interviewerMapper.getCandidateStatus());

            interviewerMapperResponse.setBehaviourRating(interviewerMapper.getBehaviourRating());

            interviewerMapperResponse.setTechnicalRating(interviewerMapper.getTechnicalRating());

            interviewerMapperResponse.setSoftskillRating(interviewerMapper.getSoftSkillRating());

            interviewerMapperResponse.setOverallRating(interviewerMapper.getOverallRating());

//            interviewerMapperResponse.setInterviewerMapperId(interviewerMapper.getInterviewerMapperId());

            interviewerMapperResponse.setFeedbackGiven(interviewerMapper.isFeedbackGiven());

            interviewerMapperResponse.setInterviewerMapperId(interviewerMapper.getInterviewerMapperId());

            responses.add(interviewerMapperResponse);
        }

        return responses;
    }

    @Override
    public InterviewerCandidateResponse saveCandidatesForInterviewer(InterviewerCandidateRequest interviewerCandidateRequest) {
        log.info("InterviewerMapperServiceImpl----------saveCandidatesForInterviewer----------{}",interviewerCandidateRequest);
        InterviewerMapper interviewerCandidateMapper = new InterviewerMapper();

        interviewerCandidateMapper.setRrId(rrMasterRepository.findByActiveAndRrMasterId(true, interviewerCandidateRequest.getRrId()));

        interviewerCandidateMapper.setInterviewerId(interviewerRepository.findByActiveAndInterviewerId(true, interviewerCandidateRequest.getInterviewerId()));

        interviewerCandidateMapper.setCandidateId(candidateRepository.findByActiveAndCandidateId(true, interviewerCandidateRequest.getCandidateId()));

        InterviewerMapper save = this.interviewerMapperRepository.save(interviewerCandidateMapper);

        InterviewerCandidateResponse interviewerCandidateResponse = interviewerCandidateToInterviewerCandidateResponse(save);

        return interviewerCandidateResponse;

    }

    private InterviewerCandidateResponse interviewerCandidateToInterviewerCandidateResponse(InterviewerMapper interviewerMapper) {

        InterviewerCandidateResponse interviewerCandidateResponse = new InterviewerCandidateResponse();
        interviewerCandidateResponse.setInterviewerId(interviewerMapper.getInterviewerId());
        interviewerCandidateResponse.setCandidateId(interviewerMapper.getCandidateId());
        interviewerCandidateResponse.setRrId(interviewerMapper.getRrId());
        return interviewerCandidateResponse;
    }

    @Override
    public List<InterviewerMapperResponse> getCandidatesByInterviewerId(Integer interviewerId) {
        log.info("InterviewerMapperServiceImpl---------------getCandidatesByInterviewerId-------------{}",interviewerId);
        List<InterviewerMapperResponse> candidates = new ArrayList<>();
        List<InterviewerMapper> interviewerCandidateList1 = interviewerMapperRepository.findByInterviewerId(interviewerRepository.findById(interviewerId).get());
        for (InterviewerMapper interviewerMapper : interviewerCandidateList1) {
            InterviewerMapperResponse interviewerMapperResponse = new InterviewerMapperResponse();
            interviewerMapperResponse.setCandidateId(interviewerMapper.getCandidateId());
            interviewerMapperResponse.setRrId(interviewerMapper.getRrId());
            interviewerMapperResponse.setInterviewerId(interviewerMapper.getInterviewerId());
            interviewerMapperResponse.setFeedbackGiven(interviewerMapper.isFeedbackGiven());
            interviewerMapperResponse.setFeedBackDescription(interviewerMapper.getFeedBackDescription());
            interviewerMapperResponse.setOverallRating(interviewerMapper.getOverallRating());
            interviewerMapperResponse.setBehaviourRating(interviewerMapper.getBehaviourRating());
            interviewerMapperResponse.setTechnicalRating(interviewerMapper.getTechnicalRating());
            interviewerMapperResponse.setSoftskillRating(interviewerMapper.getSoftSkillRating());
            interviewerMapperResponse.setInterviewerMapperId(interviewerMapper.getInterviewerMapperId());
            interviewerMapperResponse.setOverallRating(interviewerMapper.getOverallRating());
            interviewerMapperResponse.setCandidateStatus(interviewerMapper.getCandidateStatus());
            candidates.add(interviewerMapperResponse);
        }
        return candidates;
    }

    @Override
    public List<InterviewerCandidateResponse> getAllCandidatesForInterviewer() {
        log.info("InterviewerMapperServiceImpl-----------getAllCandidatesForInterviewer---------{}");
        List<InterviewerCandidateMapper> all = interviewerCandidateRepository.findByActive(true);

        List<InterviewerCandidateResponse> interviewerCandidateResponseList1 = new ArrayList<>();

        for (InterviewerCandidateMapper interviewerCandidateMapper : all) {

            interviewerCandidateResponseList1.add(interviewerCandidateMapToInterviewerCandidateResponse(interviewerCandidateMapper));

        }
        return interviewerCandidateResponseList1;
    }

    private InterviewerCandidateResponse interviewerCandidateMapToInterviewerCandidateResponse(InterviewerCandidateMapper interviewerCandidateMapper) {

        InterviewerCandidateResponse interviewerCandidateResponse = new InterviewerCandidateResponse();

        interviewerCandidateResponse.setInterviewerId(interviewerCandidateMapper.getInterviewerId());

        interviewerCandidateResponse.setCandidateId(interviewerCandidateMapper.getCandidateId());

        interviewerCandidateResponse.setRrId(interviewerCandidateMapper.getRrId());

        interviewerCandidateResponse.setInterviewerCandidateMapperId(interviewerCandidateMapper.getInterviewerCandidateMapperId());

//        interviewerCandidateResponse.setFeedbackGiven(interviewerCandidateMapper.isFeedbackGiven());

        return interviewerCandidateResponse;
    }

    @Override
    public InterviewerFeedbackOnCandidateResponse saveFeedbackForCandidate(CandidateFeedbackFormRequest feedbackFormRequest) {
        log.info("InterviewerMapperServiceImpl------------saveFeedbackForCandidate---------{}",feedbackFormRequest);
        InterviewerMapper interviewerCandidateMapper = new InterviewerMapper();

        interviewerCandidateMapper.setCandidateId(candidateRepository.findByActiveAndCandidateId(true, feedbackFormRequest.getCandidateId()));

        InterviewerMapper save = this.interviewerMapperRepository.save(interviewerCandidateMapper);

        InterviewerFeedbackOnCandidateResponse interviewerFeedbackOnCandidateResponse = interviewerFeedbackToCandidateResponse(save);

        return interviewerFeedbackOnCandidateResponse;
    }

    private InterviewerFeedbackOnCandidateResponse interviewerFeedbackToCandidateResponse(InterviewerMapper interviewerCandidateMapper) {
        InterviewerFeedbackOnCandidateResponse interviewerFeedbackOnCandidateResponse = new InterviewerFeedbackOnCandidateResponse();

        interviewerFeedbackOnCandidateResponse.setCandidateId(interviewerMapperRepository.findByCandidateId(interviewerCandidateMapper.getCandidateId()));

        interviewerFeedbackOnCandidateResponse.setDescription(interviewerCandidateMapper.getFeedBackDescription());

        return interviewerFeedbackOnCandidateResponse;
    }

    @Override
    public void deleteCandidateByInterviewerCandidateMapperId(Integer interviewerCandidateMapperId) {
log.info("InterviewerMapperServiceImpl-----------------deleteCandidateByInterviewerCandidateMapperId------------{}",interviewerCandidateMapperId);
        Optional<InterviewerMapper> interviewerCandidateMapper = interviewerMapperRepository.findById(interviewerCandidateMapperId);

        interviewerCandidateMapper.get().setActive(false);

        interviewerMapperRepository.save(interviewerCandidateMapper.get());

        System.out.println("Candidate Successfully Deleted");
    }

    @Override
    public InterviewerListResponse getListInterviewerMappersPg(Integer pageNumber, Integer pageSize, String searchTerm) {
        return null;
    }

    /* @Override
     public InterviewerMapperListResponse getCandidatesByInterviewerIds(Integer interviewerId, Integer pageNumber, Integer pageSize, String searchTerm) {

         List<InterviewerMapper> all;
         Pageable pageable = PageRequest.of(pageNumber, pageSize);
         long totalInterviewerMappers;
         if (searchTerm != null && !searchTerm.isEmpty()) {
             all = interviewerMapperRepository.findBySearchTerm(searchTerm, pageable);
 // totalInterviewerMappers= all.size(); // Get the count from the list size
         } else {
             Page<InterviewerMapper> interviewerMapperPage = interviewerMapperRepository.findByActiveOrderByInterviewerIdDesc(true,pageable);
             all = interviewerMapperPage.getContent();
 //totalInterviewerMappers = interviewerRepository.countByActive(true); // Get the total count separately
         }
         List<InterviewerCandidateResponse> candidates = new ArrayList<>();
 // List<InterviewerMapper> interviewerCandidateList1 = interviewerMapperRepository.findByInterviewerId(interviewerRepository.findById(interviewerId).get());
         for (InterviewerMapper interviewerMapper : all) {
             InterviewerCandidateResponse interviewerCandidateResponse1 = new InterviewerCandidateResponse();
             interviewerCandidateResponse1.setCandidateId(interviewerMapper.getCandidateId());
             interviewerCandidateResponse1.setRrId(interviewerMapper.getRrId());
             interviewerCandidateResponse1.setInterviewerId(interviewerMapper.getInterviewerId());

 //            interviewerCandidateResponse1.setFeedbackGiven(interviewerMapper.isFeedbackGiven());
             candidates.add(interviewerCandidateResponse1);
         }
         return new InterviewerMapperListResponse(candidates.size(),candidates);
     }
 */
    @Override
    public InterviewerMapperFeedbacksResponse getAllFeedbacksOp(Integer pageNumber, Integer pageSize, String searchTerm) {
        log.info("InterviewerMapperServiceImpl-------------getAllFeedbacksOp---------{}",pageNumber,pageSize,searchTerm);
        List<InterviewerMapper> allFeedbacks;
        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        Page<InterviewerMapper> page;

        if (searchTerm != null && !searchTerm.isEmpty()) {
            page = interviewerMapperRepository.findByActiveAndSearchTerm(true, searchTerm, pageable);

        } else {
            page = interviewerMapperRepository.findByActiveOrderByInterviewerMapperIdDesc(true, pageable);
        }
        List<InterviewerMapper> all = page.getContent();
        List<InterviewerMapperResponse> interviewerMapperResponseList1 = new ArrayList<>();

        for (InterviewerMapper interviewerMapper : all) {
            interviewerMapperResponseList1.add(interviewerMapperEntityToInterviewerMapperResponse(interviewerMapper));
        }
     //   System.out.println("here is the size................." + page.getTotalElements());
        log.info("here is the size................." , page.getTotalElements());
        return new InterviewerMapperFeedbacksResponse(page.getTotalElements(), interviewerMapperResponseList1);
    }

 /*public InterviewerMapperFeedbacksListByRrIdResponse getAllFeedbacksListByRrOp(Integer rrId,Integer pageNumber, Integer pageSize, String searchTerm) {
     List<InterviewerMapper> allFeedbacksListByRr;
     Pageable pageable = PageRequest.of(pageNumber, pageSize);
     Page<InterviewerMapper> page;

     if (searchTerm != null && !searchTerm.isEmpty()) {
         RRMaster rrMaster = rrMasterRepository.findByActiveAndRrMasterId(true,rrId);
         page = interviewerMapperRepository.findByActiveAndRrIdAndSearchTerm(true,rrMaster,searchTerm,pageable);

     } else {
         RRMaster rrMaster = rrMasterRepository.findByActiveAndRrMasterId(true,rrId);
         page = interviewerMapperRepository.findByActiveRrIdOrderByInterviewerMapperIdDesc(true,rrMaster,pageable);
     }
     List<InterviewerMapper> all=page.getContent();
     List<InterviewerMapperResponse> interviewerMapperResponseList12 = new ArrayList<>();

     for (InterviewerMapper interviewerMapper : all) {
         InterviewerMapperResponse interviewerMapperResponse = new InterviewerMapperResponse();

         interviewerMapperResponse.setInterviewerId(interviewerMapper.getInterviewerId());

         interviewerMapperResponse.setFeedBackDescription(interviewerMapper.getFeedBackDescription());

         interviewerMapperResponse.setRrId(interviewerMapper.getRrId());

         interviewerMapperResponse.setCandidateId(interviewerMapper.getCandidateId());

         interviewerMapperResponse.setCandidateStatus(interviewerMapper.getCandidateStatus());

         interviewerMapperResponse.setBehaviourRating(interviewerMapper.getBehaviourRating());

         interviewerMapperResponse.setTechnicalRating(interviewerMapper.getTechnicalRating());

         interviewerMapperResponse.setSoftskillRating(interviewerMapper.getSoftSkillRating());

         interviewerMapperResponse.setOverallRating(interviewerMapper.getOverallRating());

//            interviewerMapperResponse.setInterviewerMapperId(interviewerMapper.getInterviewerMapperId());

         interviewerMapperResponse.setFeedbackGiven(interviewerMapper.isFeedbackGiven());



         interviewerMapperResponse.setInterviewerMapperId(interviewerMapper.getInterviewerMapperId());

         interviewerMapperResponseList12.add(interviewerMapperResponse);
     }
     System.out.println("here is the size................."+ page.getTotalElements());
     return new InterviewerMapperFeedbacksListByRrIdResponse(page.getTotalElements(), interviewerMapperResponseList12);

 }*/


@Override
 public InterviewerMapperFeedbacksListByRrIdResponse getAllFeedbacksListByRrOp(Integer rrId, Integer pageNumber, Integer pageSize, String searchTerm) {
    log.info("InterviewerMapperServiceImpl--------------getAllFeedbacksListByRrOp----------{}", rrId, pageNumber, pageSize, searchTerm);
    RRMaster rrMaster = rrMasterRepository.findByActiveAndRrMasterId(true, rrId);

    if (rrMaster == null) {
        throw new NotFoundException("RRMaster not found for rrId: " + rrId);
    }

    Pageable pageable = PageRequest.of(pageNumber, pageSize);
    Page<InterviewerMapper> page;

    if (searchTerm != null && !searchTerm.isEmpty()) {
        page = interviewerMapperRepository.findByRrId_RrMasterIdAndSearchTerm(rrId, searchTerm, pageable);
    } else {
        page = interviewerMapperRepository.findByRrIdOrderByInterviewerMapperIdDesc(rrMaster, pageable);
    }

    List<InterviewerMapper> all = page.getContent();
    List<InterviewerMapperResponse> interviewerMapperResponseList = new ArrayList<>();

    for (InterviewerMapper interviewerMapper : all) {
        InterviewerMapperResponse interviewerMapperResponse = new InterviewerMapperResponse();

        interviewerMapperResponse.setInterviewerId(interviewerMapper.getInterviewerId());
        interviewerMapperResponse.setFeedBackDescription(interviewerMapper.getFeedBackDescription());
        interviewerMapperResponse.setRrId(interviewerMapper.getRrId());
        interviewerMapperResponse.setCandidateId(interviewerMapper.getCandidateId());
        interviewerMapperResponse.setCandidateStatus(interviewerMapper.getCandidateStatus());
        interviewerMapperResponse.setBehaviourRating(interviewerMapper.getBehaviourRating());
        interviewerMapperResponse.setTechnicalRating(interviewerMapper.getTechnicalRating());
        interviewerMapperResponse.setSoftskillRating(interviewerMapper.getSoftSkillRating());
        interviewerMapperResponse.setOverallRating(interviewerMapper.getOverallRating());
        interviewerMapperResponse.setFeedbackGiven(interviewerMapper.isFeedbackGiven());
        interviewerMapperResponse.setInterviewerMapperId(interviewerMapper.getInterviewerMapperId());
        interviewerMapperResponse.setInterviewDate(interviewerMapper.getInterviewerCandidateMapper().getDate());
        interviewerMapperResponse.setInterviewTime(interviewerMapper.getInterviewerCandidateMapper().getTime());



         interviewerMapperResponseList.add(interviewerMapperResponse);
     }
    List<Candidate> finalisedForRR= selectedCandidateMapperRepository.findDistinctCandidateIdsByRrId(rrMaster);
   List<Integer> finalisedcandidateIds=new ArrayList<>();
   for(Candidate candidate:finalisedForRR)
   {
       finalisedcandidateIds.add(candidate.getCandidateId());
   }
    Integer totalselectionForRR=selectedCandidateMapperRepository.countByActiveAndRrId(true,rrMaster);
    Integer updatedRequiredCount=totalselectionForRR;
     return new InterviewerMapperFeedbacksListByRrIdResponse(page.getTotalElements(), interviewerMapperResponseList,finalisedcandidateIds,updatedRequiredCount);
 }


}
