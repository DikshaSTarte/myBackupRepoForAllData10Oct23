package com.hrms.demo.service;

import com.hrms.demo.dto.response.RRStatusResponse;

import java.util.List;

public interface RRStatusService {
    List<RRStatusResponse> getListOfRr();
}
