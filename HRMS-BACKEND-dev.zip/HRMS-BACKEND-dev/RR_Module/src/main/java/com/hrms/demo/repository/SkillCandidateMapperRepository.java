package com.hrms.demo.repository;

import com.hrms.demo.model.Candidate;
import com.hrms.demo.model.SkillCandidateMapper;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface SkillCandidateMapperRepository extends JpaRepository<SkillCandidateMapper, Integer> {

    SkillCandidateMapper findByActiveAndSkillCandidateMapperId(boolean active, Integer skillCandidateMapperId);
    List<SkillCandidateMapper> findByActive(boolean b);

    public List<SkillCandidateMapper> findByActive(boolean active, Pageable pageable);
   // public List<SkillCandidateMapper>
   List<SkillCandidateMapper> findByActiveAndCandidate(boolean b,Candidate candidate);

    List<SkillCandidateMapper> findByActiveAndSkillEntity_skillType_id(boolean b, Integer skillTypeId);
}
