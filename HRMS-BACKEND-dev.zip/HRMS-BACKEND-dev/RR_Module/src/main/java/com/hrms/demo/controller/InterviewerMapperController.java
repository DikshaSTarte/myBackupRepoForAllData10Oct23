package com.hrms.demo.controller;

import com.hrms.demo.dto.request.InterviewerMapperRequest;
import com.hrms.demo.dto.response.InterviewerMapperFeedbacksListByRrIdResponse;
import com.hrms.demo.dto.response.InterviewerMapperFeedbacksResponse;
import com.hrms.demo.dto.response.InterviewerMapperResponse;
import com.hrms.demo.service.InterviewerMapperService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import java.util.List;
@Slf4j
@RestController
@RequestMapping("/api/v1/interviewerMapper")
public class InterviewerMapperController {
    @Autowired
    private InterviewerMapperService interviewerMapperService;
    @PostMapping("/feedbackSave")
    public InterviewerMapperResponse saveInterviewerFeedbackStatusForRR(@Valid @RequestBody InterviewerMapperRequest interviewerMapperRequest){
        System.out.println("Interviewer feedback save successfully for candidate");
        log.info("InterviewerMapperController------saveInterviewerFeedbackStatusForRR--{}",interviewerMapperRequest);
        return interviewerMapperService.saveInterviewerFeedbackStatus(interviewerMapperRequest);
    }
    @GetMapping("/listOfFeedbacksStatus")
    public List<InterviewerMapperResponse> getListOfFeedbacks() {
        log.info("InterviewerMapperController------getListOfFeedbacks--{}");
        return this.interviewerMapperService.getAllFeedbacks();
    }
    @GetMapping("/get/feedbackList/{rrId}")
    public List<InterviewerMapperResponse> getListOfFeedbackByRr(@PathVariable Integer rrId) {
        log.info("InterviewerMapperController------getListOfFeedbackByRr--{}");
        return this.interviewerMapperService.getAllFeedbacksByRrId(rrId);
    }
    @GetMapping("/get/{interviewerId}")
    public List<InterviewerMapperResponse> getCandidateDataByInterviewerId(@PathVariable Integer interviewerId){
        System.out.println("candidates data fetched successfully...");
        log.info("InterviewerCandidateController------getCandidateDataByInterviewerId--{}",interviewerId);
        return this.interviewerMapperService.getCandidatesByInterviewerId(interviewerId);
    }
   @GetMapping("/feedbacks/paginations")
    public ResponseEntity<InterviewerMapperFeedbacksResponse> getAllFeedbacksOp(
            @RequestParam(defaultValue = "0") Integer pageNumber,
            @RequestParam(defaultValue = "7") Integer pageSize,
            @RequestParam(required = false) String searchTerm
    ) {
        Pageable pageable = PageRequest.of(pageNumber, pageSize);

        InterviewerMapperFeedbacksResponse response = interviewerMapperService.getAllFeedbacksOp(pageNumber,pageSize,searchTerm);
       log.info("InterviewerMapperController------getAllFeedbacksOp--{}",pageNumber,pageSize,searchTerm);
        return ResponseEntity.ok(response);
    }
 @GetMapping("/get/feedbackList/{rrId}/paginations")
  public ResponseEntity<InterviewerMapperFeedbacksListByRrIdResponse> getAllFeedbacksListByRrOp(
          @PathVariable Integer rrId,
          @RequestParam(defaultValue = "0") Integer pageNumber,
          @RequestParam(defaultValue = "7") Integer pageSize,
          @RequestParam(required = false) String searchTerm
  ) {
      Pageable pageable = PageRequest.of(pageNumber, pageSize);
      InterviewerMapperFeedbacksListByRrIdResponse response = interviewerMapperService.getAllFeedbacksListByRrOp(rrId,pageNumber,pageSize,searchTerm);

     log.info("InterviewerMapperController------getAllFeedbacksListByRrOp--{}",rrId,pageNumber,pageSize,searchTerm);
      return ResponseEntity.ok(response);
  }
}