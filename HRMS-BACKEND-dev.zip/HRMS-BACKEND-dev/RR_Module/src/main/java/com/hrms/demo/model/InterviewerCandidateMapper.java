package com.hrms.demo.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name ="InterviewerCandidateMapper")
public class InterviewerCandidateMapper extends BaseEntity {
   /* @Id
    @GeneratedValue(strategy=GenerationType.AUTO)*/
   @Id
   @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "InterviewerCandidateMapper_generator")
   @SequenceGenerator(name = "InterviewerCandidateMapper_generator", sequenceName = "InterviewerCandidateMapper_SEQUENCE", initialValue = 7500, allocationSize = 1)
    private Integer interviewerCandidateMapperId;
    @ManyToOne
    private Candidate candidateId;
    @ManyToOne
    private Interviewer interviewerId ;
    @ManyToOne
    private RRMaster rrId;
    private LocalDate date;
    private LocalTime time;
    private boolean isFeedbackGiven;
}