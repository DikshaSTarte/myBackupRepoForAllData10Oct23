package com.hrms.demo.serviceImpl;

import com.hrms.demo.constants.ErrorCodes;
import com.hrms.demo.dto.request.CreateRrRequest;
import com.hrms.demo.dto.request.RRMasterRequest;
import com.hrms.demo.dto.request.RrFilterRequest;
import com.hrms.demo.dto.response.*;

import com.hrms.demo.globleexception.RRAlreadyExistsException;

import com.hrms.demo.mapper.RRMapper;
import com.hrms.demo.model.*;
import com.hrms.demo.repository.*;
import com.hrms.demo.service.RRMasterService;
import com.hrms.demo.sprinfDataSpecificationalongwithCrieteriaBuilder.RRMasterSpecifications;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import java.io.File;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;
@Slf4j
@Service
public class RRMasterServiceImpl implements RRMasterService {
    @Autowired
    private RRMasterRepository rrMasterRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private SkillCandidateMapperRepository skillCandidateMapperRepository;
    @Autowired
    private RRCandidateMapperRepository rrCandidateMapperRepository;
    @Autowired
    private CandidateRepository candidateRepository;
    @Autowired
    private SkillMapperRrRepository skillMapperRrRepository;
    @Autowired
    private RRStatusRepository rrStatusRepository;
    @Autowired
    private SkillEntityRepository skillEntityRepository;
    @Autowired
    private InterviewerCandidateRepository interviewerCandidateRepository;
    @Autowired
    private CompanyRepository companyRepository;
    @Autowired
    private FileUploadeRepository fileUploadeRepository;
    @Autowired
    private InterviewerMapperRepository interviewerMapperRepository;
    @Autowired
    private RRMapper rrMapper;
    @Autowired
    private SkillTypeEntityRepository skillTypeEntityRepository;
    @Autowired
    private UserTypeRepository userTypeRepository;
    @Override
    public List<CandidateForRrResponse> getAllCandidatesByRrId(Integer rrId) {
        log.info("RRMasterServiceImpl-------------getAllCandidatesByRrId----------{}",rrId);
        List<CandidateForRrResponse> candidates = new ArrayList<>();
        List<RRCandidateMapper> candidateMapperList = rrCandidateMapperRepository.findByRrId_RrMasterIdAndActive(rrId, true);
        for (RRCandidateMapper rrCandidateMapper : candidateMapperList) {
            CandidateForRrResponse candidateForRrResponse = new CandidateForRrResponse();
            candidateForRrResponse.setRrId(rrCandidateMapper.getRrId());
            candidateForRrResponse.setCandidateId(rrCandidateMapper.getCandidateId());
            List<InterviewerCandidateMapper> interviewerCandidateMappers = interviewerCandidateRepository.findByActiveAndRrIdAndCandidateId(true, rrCandidateMapper.getRrId(), rrCandidateMapper.getCandidateId());
            if (!interviewerCandidateMappers.isEmpty()) {
                InterviewerCandidateMapper interviewerCandidateMapper1 = interviewerCandidateMappers.get(0);
                candidateForRrResponse.setInterviewDate(interviewerCandidateMapper1.getDate());
                candidateForRrResponse.setInterviewTime(interviewerCandidateMapper1.getTime());
                candidateForRrResponse.setFeedbackGiven(interviewerCandidateMapper1.isFeedbackGiven());
                candidateForRrResponse.setInterviewer(interviewerCandidateMapper1.getInterviewerId());
            }
            candidates.add(candidateForRrResponse);
        }
        log.info("RRMasterServiceImpl-------------getAllCandidatesByRrId----------{}",rrId);
        return candidates;
    }
    @Override
    public List<RRMasterResponse> getAllRRMaster() {
        log.info("RRMasterServiceImpl---------------getAllRRMaster------{}");
        List<RRMaster> all = rrMasterRepository.findByActive(true);
        List<RRMasterResponse> rrMasterResponseList = new ArrayList<>();
        for (RRMaster rrMaster : all) {
            rrMasterResponseList.add(rrMasterEntityToRrMasterResponse(rrMaster));
        }
        log.info("RRMasterServiceImpl---------------getAllRRMaster------{}");
        return rrMasterResponseList;
    }
    private RRMasterResponse rrMasterEntityToRrMasterResponse(RRMaster rrMaster) {
        RRMasterResponse rrMasterResponse = new RRMasterResponse();
        rrMasterResponse.setRrMasterId(rrMaster.getRrMasterId());
        rrMasterResponse.setOwnerId(new OwnerResponse(rrMaster.getOwnerId().getUserId(),rrMaster.getOwnerId().getUserType(), rrMaster.getOwnerId().getUserFirstName(),rrMaster.getOwnerId().getUserLastName(),rrMaster.getOwnerId().getUserContact(),rrMaster.getOwnerId().getUserEmailId()));
        rrMasterResponse.setRequiredCount(rrMaster.getRequiredCount());
        rrMasterResponse.setExperience(rrMaster.getExperience());
        rrMasterResponse.setRrStatus(rrMaster.getRrStatus());
        rrMasterResponse.setStartDate(rrMaster.getStartDate());
        rrMasterResponse.setEndDate(rrMaster.getEndDate());
        rrMasterResponse.setCompany(rrMaster.getCompany());

        if (rrMaster.getFileId() != null) {
            rrMasterResponse.setFileId(new FileUploadeResponse(rrMaster.getFileId().getFileId(), rrMaster.getFileId().getFileName(), rrMaster.getFileId().getFileSize(), rrMaster.getFileId().getFileType(), rrMaster.getFileId().getFilePath()));
        }
        List<SkillResponse> skillResponseList = new ArrayList<>();
        List<SkillMapperRR> skillMapperRRS = skillMapperRrRepository.findByActiveAndRrMasterId(true,rrMaster);

        for (SkillMapperRR skillMapperRR : skillMapperRRS) {
            SkillResponse skillResponse = new SkillResponse();
            if (skillMapperRR.getSkillsId()!= null) {
                skillResponse.setId(skillMapperRR.getSkillsId().getId());
                skillResponse.setSkillSet(skillMapperRR.getSkillsId().getSkillSet());
                skillResponse.setSkillType(new SkillTypeResponse(skillMapperRR.getSkillsId().getSkillType().getId(),skillMapperRR.getSkillsId().getSkillType().getSkillTypeName()));
                skillResponseList.add(skillResponse);
            }
        }
        rrMasterResponse.setSkillsId(skillResponseList);
        LocalDate endDate = rrMaster.getEndDate();
        LocalDate today = LocalDate.now();
        LocalDate sevenDaysLater = today.plusDays(7);
        if (endDate.isBefore(sevenDaysLater)||endDate.isEqual(sevenDaysLater)) {
            rrMasterResponse.setRrAlertFlag(1);
        }if (endDate.isAfter(today) ) {
            rrMasterResponse.setRrAlertFlag(0);
        }if(endDate.isBefore(today)){
            rrMasterResponse.setRrAlertFlag(2);
        }
        return rrMasterResponse;
    }
    @Override
    public RrResponse getRRMasterById(Integer id) {
        log.info("RRMasterServiceImpl---------------getRRMasterById------{}",id);
        RRMaster rrMaster = rrMasterRepository.findByActiveAndRrMasterId(true, id);
        RrResponse rrResponse = new RrResponse();
        OwnerResponse ownerResponse = new OwnerResponse();
        ownerResponse.setUserId(rrMaster.getOwnerId().getUserId());
        ownerResponse.setUserFirstName(rrMaster.getOwnerId().getUserFirstName());
        ownerResponse.setUserLastName(rrMaster.getOwnerId().getUserLastName());
        ownerResponse.setUserType(rrMaster.getOwnerId().getUserType());
        rrResponse.setOwnerId(ownerResponse);
        rrResponse.setRrId(rrMaster.getRrMasterId());
        rrResponse.setStartDate(rrMaster.getStartDate());
        rrResponse.setEndDate(rrMaster.getEndDate());
        rrResponse.setCompany(rrMaster.getCompany());
        rrResponse.setRrStatus(rrMaster.getRrStatus());
        rrResponse.setFileId(rrMaster.getFileId());
        rrResponse.setExperience(rrMaster.getExperience());
        List<SkillResponse> skillResponseList = new ArrayList<>();
        List<SkillMapperRR> skillMapperRRS = skillMapperRrRepository.findByActiveAndRrMasterId(true,rrMaster);

        for (SkillMapperRR skillMapperRR : skillMapperRRS) {
            SkillResponse skillResponse = new SkillResponse();
            if (skillMapperRR.getSkillsId() != null) {
                skillResponse.setId(skillMapperRR.getSkillsId().getId());
                skillResponse.setSkillSet(skillMapperRR.getSkillsId().getSkillSet());
                skillResponse.setSkillType(new SkillTypeResponse(skillMapperRR.getSkillsId().getSkillType().getId(),skillMapperRR.getSkillsId().getSkillType().getSkillTypeName()));
                skillResponseList.add(skillResponse);
            }
        }
        rrResponse.setSkillsId(skillResponseList);
        rrResponse.setRequiredCount(rrMaster.getRequiredCount());
        log.info("RRMasterServiceImpl---------------getRRMasterById------{}",id);
        return rrResponse;
    }

    @Override
    public RRMasterResponse createRRMaster(@RequestBody CreateRrRequest createRrRequest) {
        if(createRrRequest.getCheckId()==0)
        {
            System.out.println("condition is valid........-----------------------------------------------------");
            Integer companyId=createRrRequest.getCompanyId();
            List<Integer> skillSetIds=createRrRequest.getSkillSetId();
            Optional<SkillEntity> skillEntity = skillEntityRepository.findById(skillSetIds.get(0));
            SkillEntity skEnttity=skillEntity.get();
           SkillTypeEntity skillTypeEntity= skEnttity.getSkillType();
            System.out.println("_-----------------------------------------------------"+skillTypeEntity.getSkillTypeName());
          List<Integer> skilltypes = new ArrayList<>();
           skilltypes.add(skillTypeEntity.getId());
            // Check if an RRMaster with the same Company and any of the specified SkillEntity IDs exists
//            boolean rrMasterExists = skillMapperRrRepository.existsByActiveAndRrMasterId_Company_CompanyIdAndSkillsId_SkillType_IdIn(true,companyId,skilltypes);
//            System.out.println("condition is valid........-----------------------------------------------------"+rrMasterExists);
//            if (rrMasterExists) {
//                throw new RRAlreadyExistsException("RRMaster with the same Company and SkillEntity combination already exists.");
//            }

            List<RRMaster> rrMasterList=skillMapperRrRepository.findDistinctRrMastersByCriteria(true,companyId,2,skilltypes);
            if(rrMasterList.size()>0)
            {
               Company company= companyRepository.findByActiveAndCompanyId(true,createRrRequest.getCompanyId());
                String companyName=company.getCompanyName();
                if(rrMasterList.size()==1)
                    throw new RRAlreadyExistsException( " RR with the Company "+companyName+ " and Role "+skillTypeEntity.getSkillTypeName()+" combination already exists and It is Open");
                else
                    throw new RRAlreadyExistsException( rrMasterList.size()+" RRs with the Company "+companyName+ " and Role "+skillTypeEntity.getSkillTypeName()+" combination already exists and They are Open");
            }
        }
        log.info("RRMasterServiceImpl------------createRRMaster------{}",createRrRequest);

        RRMaster rrMaster = new RRMaster();
        rrMaster.setOwnerId(userRepository.findByUserId(createRrRequest.getOwnerId()));
        rrMaster.setExperience(createRrRequest.getExperience());
        rrMaster.setRrStatus(rrStatusRepository.findByRrStatusId(createRrRequest.getRrStatus()));
        rrMaster.setRequiredCount(createRrRequest.getRequiredCount());
        rrMaster.setStartDate(createRrRequest.getStartDate());
        rrMaster.setEndDate(createRrRequest.getEndDate());
        rrMaster.setCompany(companyRepository.findById(createRrRequest.getCompanyId()).get());

        Optional<FileUploade> fileUploade1 = fileUploadeRepository.findById(createRrRequest.getFileId());
        rrMaster.setFileId(fileUploade1.get());

        RRMaster saved = rrMasterRepository.save(rrMaster);
        List<SkillMapperRR> skillMapperRRs = new ArrayList<>();
        for (Integer skillId : createRrRequest.getSkillSetId()) {
            Optional<SkillEntity> skillEntity = skillEntityRepository.findById(skillId);
            SkillMapperRR skillMapperRR = new SkillMapperRR();
            skillMapperRR.setRrMasterId(saved);
            System.out.println("_-----------------------------------------------------"+skillEntity.get());
            skillMapperRR.setSkillsId(skillEntity.get());
            skillMapperRRs.add(skillMapperRR);
        }
        skillMapperRrRepository.saveAll(skillMapperRRs);
        return null;
    }
@Override
public RrUpdateResponse updateRRMasterById(Integer id, RRMasterRequest rrMasterRequest) {
    log.info("RRMasterServiceImpl------------updateRRMasterById------{}",id,rrMasterRequest);
    RRMaster rrMaster = rrMasterRepository.findByActiveAndRrMasterId(true, id);

    rrMaster.setOwnerId(userRepository.findByUserId(rrMasterRequest.getOwnerId()));
    rrMaster.setRequiredCount(rrMasterRequest.getRequiredCount());
    rrMaster.setStartDate(rrMasterRequest.getStartDate());
    rrMaster.setEndDate(rrMasterRequest.getEndDate());
    rrMaster.setRrStatus(rrStatusRepository.findByRrStatusId(rrMasterRequest.getRrStatus()));
    rrMaster.setExperience(rrMasterRequest.getExperience());
    rrMaster.setCompany(companyRepository.findByActiveAndCompanyId(true,rrMasterRequest.getCompany()));
    if(rrMasterRequest.getFileId()!=0){
        Optional<FileUploade> fileUploade1 = fileUploadeRepository.findByActiveAndFileId(true,rrMasterRequest.getFileId());
        deleteFile(rrMaster.getFileId().getFilePath());
        rrMaster.setFileId(fileUploade1.get());
    }
    RRMaster update = this.rrMasterRepository.save(rrMaster);
    List<SkillMapperRR> list = new ArrayList<>();
    List<Integer> skillSet = rrMasterRequest.getSkillsets();

    if(skillSet!=null){
        for (Integer skillId:skillSet){
            SkillEntity skill= skillEntityRepository.findByActiveAndId(true,skillId);
            SkillMapperRR skillMapperRR =new SkillMapperRR();
            skillMapperRR.setRrMasterId(update);
            skillMapperRR.setSkillsId(skill);
            list.add(skillMapperRR);
        }
    }
    List<SkillMapperRR> existingSkillMapperList = skillMapperRrRepository.findByActiveAndRrMasterId(true,rrMaster);
    for (SkillMapperRR existingMapper : existingSkillMapperList){
        existingMapper.setActive(false);
    }
    skillMapperRrRepository.saveAll(list);
    RrUpdateResponse response = mapRRMasterToRRMasterResponse(rrMaster);
    log.info("RRMasterServiceImpl------------updateRRMasterById------{}",id,rrMasterRequest);
    return response;
}
    public  void deleteFile(String filePath) {
        File fileToDelete = new File(filePath);
        if (fileToDelete.exists()) {
            boolean isDeleted = fileToDelete.delete();
            if (isDeleted) {
                System.out.println("File deleted successfully: " + filePath);
            } else {
                System.out.println("Failed to delete the file: " + filePath);
            }
        } else {
            System.out.println("File does not exist: " + filePath);
        }
    }
    private RrUpdateResponse mapRRMasterToRRMasterResponse(RRMaster rrMaster) {
        RrUpdateResponse rrUpdateResponse = new RrUpdateResponse();
        OwnerResponse ownerResponse = new OwnerResponse();
        ownerResponse.setUserId(rrMaster.getOwnerId().getUserId());
        ownerResponse.setUserFirstName(rrMaster.getOwnerId().getUserFirstName());
        ownerResponse.setUserLastName(rrMaster.getOwnerId().getUserLastName());
        ownerResponse.setUserType(rrMaster.getOwnerId().getUserType());
        rrUpdateResponse.setOwnerId(ownerResponse);
        rrUpdateResponse.setRequiredCount(rrMaster.getRequiredCount());
        rrUpdateResponse.setStartDate(rrMaster.getStartDate());
        rrUpdateResponse.setEndDate(rrMaster.getEndDate());
        rrUpdateResponse.setRrStatus(rrMaster.getRrStatus());
        rrUpdateResponse.setFileId(new FileUploadeResponse(rrMaster.getFileId().getFileId(),rrMaster.getFileId().getFileName(),rrMaster.getFileId().getFileSize(),rrMaster.getFileId().getFileType(),rrMaster.getFileId().getFilePath()));
        List<SkillResponse> skillResponseList = new ArrayList<>();
        List<SkillMapperRR> skillMapperRRS = skillMapperRrRepository.findByActiveAndRrMasterId(true,rrMaster);

        for (SkillMapperRR skillMapperRR : skillMapperRRS) {
            SkillResponse skillResponse = new SkillResponse();
            if (skillMapperRR.getSkillsId() != null) {
                skillResponse.setId(skillMapperRR.getSkillsId().getId());
                skillResponse.setSkillSet(skillMapperRR.getSkillsId().getSkillSet());
                skillResponse.setSkillType(new SkillTypeResponse(skillMapperRR.getSkillsId().getSkillType().getId(),skillMapperRR.getSkillsId().getSkillType().getSkillTypeName()));
                skillResponseList.add(skillResponse);
            }
        }
        rrUpdateResponse.setSkillsets(skillResponseList);
        rrUpdateResponse.setCompany(new CompanyResponse(rrMaster.getCompany().getCompanyId(),rrMaster.getCompany().getCompanyName()));
        rrUpdateResponse.setExperience(rrMaster.getExperience());
        return rrUpdateResponse;
    }
    @Override
    public void deleteRRMasterById(Integer id) {
        log.info("RRMasterServiceImpl------------deleteRRMasterById------{}",id);
        Optional<RRMaster> rrMaster = rrMasterRepository.findById(id);
        rrMaster.get().setActive(false);
        List<SkillMapperRR> existingSkillMapperList = skillMapperRrRepository.findByActiveAndRrMasterId(true,rrMaster.get());
        for (SkillMapperRR existingMapper : existingSkillMapperList){
            existingMapper.setActive(false);
        }
        rrMasterRepository.save(rrMaster.get());
        log.info("RRMasterServiceImpl------------deleteRRMasterById------{}",id);
        System.out.println("RR Successfully Deleted");
    }
    @Override
    public List<RrResponse> getRRByOwnerId(Integer ownerId) {
        log.info("RRMasterServiceImpl------------getRRByOwnerId------{}",ownerId);
        List<RrResponse> rrList = new ArrayList<>();
        User byUserId = userRepository.findByUserId(ownerId);
        List<RRMaster> rrMasters = rrMasterRepository.findByActiveAndOwnerId(true, byUserId);
        System.out.println(rrMasters.size());
        for (RRMaster rrMaster1 : rrMasters) {
            RrResponse rrResponse = new RrResponse();
            OwnerResponse ownerResponse = new OwnerResponse();
            ownerResponse.setUserId(rrMaster1.getOwnerId().getUserId());
            ownerResponse.setUserFirstName(rrMaster1.getOwnerId().getUserFirstName());
            ownerResponse.setUserLastName(rrMaster1.getOwnerId().getUserLastName());
            ownerResponse.setUserType(rrMaster1.getOwnerId().getUserType());
            ownerResponse.setUserContact(rrMaster1.getOwnerId().getUserContact());
            ownerResponse.setUserEmailId(rrMaster1.getOwnerId().getUserEmailId());
            rrResponse.setOwnerId(ownerResponse);
            rrResponse.setRrId(rrMaster1.getRrMasterId());
            rrResponse.setExperience(rrMaster1.getExperience());
            rrResponse.setRequiredCount(rrMaster1.getRequiredCount());
            rrResponse.setCompany(rrMaster1.getCompany());
            rrResponse.setStartDate(rrMaster1.getStartDate());
            rrResponse.setEndDate(rrMaster1.getEndDate());
            rrResponse.setRrStatus(rrMaster1.getRrStatus());
            rrResponse.setFileId(rrMaster1.getFileId());
            List<SkillResponse> skillResponseList = new ArrayList<>();
            List<SkillMapperRR> skillMapperRRS = skillMapperRrRepository.findByRrMasterId(rrMaster1);
            for (SkillMapperRR skillMapperRR : skillMapperRRS) {
                SkillResponse skillResponse = new SkillResponse();
                if (skillMapperRR.getSkillsId() != null) {
                    skillResponse.setId(skillMapperRR.getSkillsId().getId());
                    skillResponse.setSkillSet(skillMapperRR.getSkillsId().getSkillSet());
                    skillResponse.setSkillType(new SkillTypeResponse(skillMapperRR.getSkillsId().getSkillType().getId(),skillMapperRR.getSkillsId().getSkillType().getSkillTypeName()));
                    skillResponseList.add(skillResponse);
                }
            }
            rrResponse.setSkillsId(skillResponseList);
            rrList.add(rrResponse);
        }
        log.info("RRMasterServiceImpl------------getRRByOwnerId------{}",ownerId);
        return rrList;
    }
    @Override
    public RRlistResponse getAllRRMasterPg(Integer pageNumber, Integer pageSize, String searchTerm,List<String> companyNames, List<String> userRoles, List<String> ownerRoles, List<String> ownerNames) {
        log.info("RRMasterServiceImpl------------getAllRRMasterPg------{}",pageNumber,pageSize,searchTerm,companyNames,userRoles,ownerRoles,ownerNames);
        List<RRMaster> rrMasterList;
        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        long totalRRPresent;

        boolean activeOnly = true;

        if (searchTerm != null && !searchTerm.isEmpty()) {
            rrMasterList = rrMasterRepository.findByActiveAndSearchTerm(true, searchTerm, pageable);
            totalRRPresent = rrMasterRepository.countByActiveAndSearchTerm(true, searchTerm); // Get the count from the list size
        } else {

            Specification<RRMaster> specification = RRMasterSpecifications.withFilters(companyNames, userRoles, ownerRoles, ownerNames,true);
            Page<RRMaster> rrMasterPage =  rrMasterRepository.findAll(specification,pageable);
             rrMasterList = rrMasterPage.getContent();
            totalRRPresent = rrMasterRepository.count(specification);
            int totalPages = rrMasterPage.getTotalPages();
        }

        List<RRMasterResponse> rrMasterResponseList = new ArrayList<>();
        for (RRMaster rrMaster : rrMasterList) {
            rrMasterResponseList.add(rrMasterEntityToRrMasterResponse(rrMaster));
        }
        System.out.println("Total PRESENT " + totalRRPresent);
        log.info("RRMasterServiceImpl------------getAllRRMasterPg------{}",pageNumber,pageSize,searchTerm,companyNames,userRoles,ownerRoles,ownerNames);

        return new RRlistResponse(totalRRPresent, rrMasterResponseList);
    }

    @Override
    public RRlistResponse getAllRRMasterPgx(Integer pageNumber, Integer pageSize, String searchTerm, RrFilterRequest rrFilterRequest) {

        List<RRMaster> rrMasterList;
        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        long totalRRPresent;

        if (searchTerm != null && !searchTerm.isEmpty()) {
            rrMasterList = rrMasterRepository.findByActiveAndSearchTerm(true, searchTerm, pageable);
            totalRRPresent = rrMasterRepository.countByActiveAndSearchTerm(true, searchTerm); // Get the count from the list size
        } else {
            List<Integer> companyIds = rrFilterRequest.getCompanyIds();
            List<Integer> userRolesIds = rrFilterRequest.getUserRolesIds();
            List<Integer> ownerRoleIds = rrFilterRequest.getOwnerRoleIds();
            List<Integer> ownerNamesIds = rrFilterRequest.getOwnerNamesIds();

            Page<RRMaster> rrMasterPage;
            rrMasterPage = skillMapperRrRepository.filterDistinctRRMastersOrderByRrMasterIdDesc(companyIds, userRolesIds, ownerRoleIds, ownerNamesIds,pageable);
            rrMasterList=rrMasterPage.getContent();
            totalRRPresent = skillMapperRrRepository.countDistinctFilteredRRMasters(companyIds, userRolesIds, ownerRoleIds, ownerNamesIds);

//            if (companyIds != null && userRolesIds != null && ownerRoleIds != null && ownerNamesIds != null) {
//                rrMasterList = skillMapperRrRepository.filterRRMasters(companyIds, userRolesIds, ownerRoleIds, ownerNamesIds);
//                totalRRPresent = skillMapperRrRepository.countFilteredRRMasters(companyIds, userRolesIds, ownerRoleIds, ownerNamesIds);
//            } else {
//                rrMasterList = Collections.emptyList();
//                totalRRPresent = 0;
//            }
        }

        List<RRMasterResponse> rrMasterResponseList = new ArrayList<>();
       for (RRMaster rrMaster : rrMasterList) {
            rrMasterResponseList.add(rrMasterEntityToRrMasterResponse(rrMaster));
        }

        System.out.println("Total PRESENT " + totalRRPresent);

        return new RRlistResponse(totalRRPresent, rrMasterResponseList);
    }
    @Override
    public RRlistResponse getAllRRMasterPg(Integer pageNumber, Integer pageSize, String searchTerm, RrFilterRequest rrFilterRequest) {
        log.info("RRMasterServiceImpl-----------getAllRRMasterPg------{}",pageNumber,pageSize,searchTerm,rrFilterRequest);
        List<RRMaster> rrMasterList;
        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        long totalRRPresent;

        List<String> companyNames = null;
        List<String> userRoleNames = null;
        List<String> ownerRoleNames = null;
        List<String> ownerNames = null;

        if (searchTerm != null && !searchTerm.isEmpty()) {
            rrMasterList = rrMasterRepository.findByActiveAndSearchTerm(true, searchTerm, pageable);
            totalRRPresent = rrMasterRepository.countByActiveAndSearchTerm(true, searchTerm);
        } else {
            if (rrFilterRequest.getCompanyIds() != null && !rrFilterRequest.getCompanyIds().isEmpty()) {
                List<Company> companies = companyRepository.findAllById(rrFilterRequest.getCompanyIds());
                companyNames = companies.stream().map(Company::getCompanyName).collect(Collectors.toList());
            }


            if (rrFilterRequest.getUserRolesIds() != null && !rrFilterRequest.getUserRolesIds().isEmpty()) {

                List<SkillTypeEntity> userRoles = skillTypeEntityRepository.findAllById(rrFilterRequest.getUserRolesIds());
                userRoleNames = userRoles.stream().map(SkillTypeEntity::getSkillTypeName).collect(Collectors.toList());
            }

            if (rrFilterRequest.getOwnerRoleIds() != null && !rrFilterRequest.getOwnerRoleIds().isEmpty()) {
                List<UserType> ownerRoles = userTypeRepository.findAllById(rrFilterRequest.getOwnerRoleIds());
                ownerRoleNames = ownerRoles.stream().map(UserType::getUserTypeName).collect(Collectors.toList());
            }

            if (rrFilterRequest.getOwnerNamesIds() != null && !rrFilterRequest.getOwnerNamesIds().isEmpty()) {
                List<User> owners = userRepository.findAllById(rrFilterRequest.getOwnerNamesIds());
                ownerNames = owners.stream()
                        .map(user -> user.getUserFirstName() + " " + user.getUserLastName())
                        .collect(Collectors.toList());
            }


            Specification<RRMaster> specification = RRMasterSpecifications.withFilters(
                    companyNames, userRoleNames, ownerRoleNames, ownerNames, true);

            Page<RRMaster> rrMasterPage = rrMasterRepository.findAll(specification, pageable);
            rrMasterList = rrMasterPage.getContent();
            totalRRPresent = rrMasterRepository.count(specification);
            int totalPages = rrMasterPage.getTotalPages();
        }

        List<RRMasterResponse> rrMasterResponseList = new ArrayList<>();
        for (RRMaster rrMaster : rrMasterList) {
            rrMasterResponseList.add(rrMasterEntityToRrMasterResponse(rrMaster));
        }
//        List<RRMasterResponse> rrMasterResponseList = rrMasterList.stream()
//                .map(this::rrMasterEntityToRrMasterResponse)
//                .collect(Collectors.toList());

        System.out.println("Total PRESENT " + totalRRPresent);
        log.info("RRMasterServiceImpl-----------getAllRRMasterPg------{}",pageNumber,pageSize,searchTerm,rrFilterRequest);
        return new RRlistResponse(totalRRPresent, rrMasterResponseList);
    }

    @Override
    public CandidateListResponseForRR getAllCandidatesByRrIdPg(Integer rrId, Integer pageNumber, Integer pageSize, String sortBy, String sortDir, String searchTerm) {
        log.info("RRMasterServiceImpl------------getAllCandidatesByRrIdPg------{}",rrId,pageNumber,pageSize,sortBy,sortDir,searchTerm);

        Sort sort = null;
        if (sortDir.equalsIgnoreCase("asc")) {
            sort = Sort.by(sortBy).ascending();
        } else {
            sort = Sort.by(sortBy).descending();
            System.out.println("sorted in descending order");
        }
        long totalCandidatesForInterviewer;
        List<CandidateForRrResponse> candidates = new ArrayList<>();
        if (searchTerm != null && !searchTerm.isEmpty()) {

//            List<InterviewerCandidateMapper> interviewerCandidateMappers = interviewerCandidateRepository.findByActiveAndRrIdAndCandidateIdCandidateFirstNameStartingWithOrCandidateIdCandidateLastNameStartingWithOrInterviewerIdInterviewerFirstNameStartingWithOrInterviewerIdInterviewerLastNameStartingWith(true, rrMasterRepository.findByActiveAndRrMasterId(true,rrId),searchTerm,searchTerm,searchTerm,searchTerm);
            List<InterviewerCandidateMapper> interviewerCandidateMappers =
                    interviewerCandidateRepository.findBySearchTerm(
                            true,
                            rrMasterRepository.findByActiveAndRrMasterId(true, rrId),
                            searchTerm
                    );
            if (!interviewerCandidateMappers.isEmpty()) {
                CandidateForRrResponse candidateForRrResponse = new CandidateForRrResponse();
                for (InterviewerCandidateMapper interviewerCandidateMapper : interviewerCandidateMappers) {
                    candidateForRrResponse.setRrId(interviewerCandidateMapper.getRrId());
                    candidateForRrResponse.setCandidateId(interviewerCandidateMapper.getCandidateId());
                    candidateForRrResponse.setInterviewDate(interviewerCandidateMapper.getDate());
                    candidateForRrResponse.setInterviewTime(interviewerCandidateMapper.getTime());
                    candidateForRrResponse.setFeedbackGiven(interviewerCandidateMapper.isFeedbackGiven());
                    candidateForRrResponse.setInterviewer(interviewerCandidateMapper.getInterviewerId());
                }
                candidates.add(candidateForRrResponse);
            }
            totalCandidatesForInterviewer = candidates.size();
            return new CandidateListResponseForRR(totalCandidatesForInterviewer, candidates);
        }
        Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);

        Page<InterviewerCandidateMapper> pageInterviewerCandidateMappers   = interviewerCandidateRepository.findByActiveAndRrId_RrMasterIdOrderByInterviewerCandidateMapperIdDesc(true, rrId,pageable);
        List<InterviewerCandidateMapper> interviewerCandidateMappers=pageInterviewerCandidateMappers.getContent();
        if (!interviewerCandidateMappers.isEmpty()) {

            for (InterviewerCandidateMapper interviewerCandidateMapper : interviewerCandidateMappers) {
                CandidateForRrResponse candidateForRrResponse = new CandidateForRrResponse();
                candidateForRrResponse.setRrId(interviewerCandidateMapper.getRrId());
                candidateForRrResponse.setCandidateId(interviewerCandidateMapper.getCandidateId());
                candidateForRrResponse.setInterviewDate(interviewerCandidateMapper.getDate());
                candidateForRrResponse.setInterviewTime(interviewerCandidateMapper.getTime());
                candidateForRrResponse.setFeedbackGiven(interviewerCandidateMapper.isFeedbackGiven());
                candidateForRrResponse.setInterviewer(interviewerCandidateMapper.getInterviewerId());
                candidates.add(candidateForRrResponse);
            }

        }
        totalCandidatesForInterviewer = candidates.size();
        System.out.println("Total candidates: " + totalCandidatesForInterviewer);
        log.info("RRMasterServiceImpl------------getAllCandidatesByRrIdPg------{}",rrId,pageNumber,pageSize,sortBy,sortDir,searchTerm);
        return new CandidateListResponseForRR(totalCandidatesForInterviewer, candidates);
    }

   @Override
   public RrListByOwnerResponse getRRByOwnerIdPagination(Integer ownerId, Integer pageNumber, Integer pageSize, String searchTerm,RrFilterRequest rrFilterRequest) {
       log.info("RRMasterServiceImpl------------getRRByOwnerIdPagination------{}",ownerId,pageNumber,pageSize,searchTerm);

//       if (ownerId == null || pageNumber == null || pageSize == null) {
//           // Handle invalid input, e.g., throw an IllegalArgumentException
//           log.error("RRMasterServiceImpl--------------getRRByOwnerIdPagination--------{}",ownerId,pageNumber,pageSize,"ownerId, pageNumber, and pageSize cannot be null");
//           throw new IllegalArgumentException("ownerId, pageNumber, and pageSize cannot be null.");
//       }

       List<RRMaster> rrMasterList;
       long totalRRPresent;

       Pageable pageable = PageRequest.of(pageNumber, pageSize);
       Page<RRMaster> rrMasterPage;

       User userId = userRepository.findByUserId(ownerId);
       if (userId == null) {
           // Handle the case where the user is not found with the given ownerId.
           // You can throw an exception, log an error, or return an empty response.
           return new RrListByOwnerResponse(0, new ArrayList<>());
       }

       if (searchTerm != null && !searchTerm.isEmpty()) {
           rrMasterPage = rrMasterRepository.findByOwnerIdAndSearchTerm(userId.getUserId(), searchTerm, pageable);
           rrMasterList=rrMasterPage.getContent();
           totalRRPresent=rrMasterRepository.countByOwnerIdAndSearchTerm(userId.getUserId(),searchTerm);
       } else {

           List<Integer> companyIds = rrFilterRequest.getCompanyIds();
           List<Integer> userRolesIds = rrFilterRequest.getUserRolesIds();
           List<Integer> ownerRoleIds = rrFilterRequest.getOwnerRoleIds();
           List<Integer> ownerNamesIds = rrFilterRequest.getOwnerNamesIds();

           ownerNamesIds.add(ownerId);

           rrMasterPage = skillMapperRrRepository.filterDistinctRRMastersOrderByRrMasterIdDesc(companyIds, userRolesIds, ownerRoleIds, ownerNamesIds,pageable);
           rrMasterList=rrMasterPage.getContent();
           totalRRPresent = skillMapperRrRepository.countDistinctFilteredRRMasters(companyIds, userRolesIds, ownerRoleIds, ownerNamesIds);
       }
       List<RrResponse> rrList = new ArrayList<>();

       for (RRMaster rrMaster1 : rrMasterList) {
           RrResponse rrResponse = new RrResponse();
           OwnerResponse ownerResponse = new OwnerResponse();
           ownerResponse.setUserId(rrMaster1.getOwnerId().getUserId());
           ownerResponse.setUserFirstName(rrMaster1.getOwnerId().getUserFirstName());
           ownerResponse.setUserLastName(rrMaster1.getOwnerId().getUserLastName());
           ownerResponse.setUserType(rrMaster1.getOwnerId().getUserType());
           ownerResponse.setUserContact(rrMaster1.getOwnerId().getUserContact());
           ownerResponse.setUserEmailId(rrMaster1.getOwnerId().getUserEmailId());
           rrResponse.setOwnerId(ownerResponse);
           rrResponse.setRrId(rrMaster1.getRrMasterId());
           rrResponse.setExperience(rrMaster1.getExperience());
           rrResponse.setRequiredCount(rrMaster1.getRequiredCount());
           rrResponse.setCompany(rrMaster1.getCompany());
           rrResponse.setStartDate(rrMaster1.getStartDate());
           rrResponse.setEndDate(rrMaster1.getEndDate());
           rrResponse.setRrStatus(rrMaster1.getRrStatus());
           rrResponse.setFileId(rrMaster1.getFileId());
           LocalDate endDate = rrMaster1.getEndDate();
           LocalDate today = LocalDate.now();
           LocalDate sevenDaysLater = today.plusDays(7);
           if (endDate.isBefore(sevenDaysLater)||endDate.isEqual(sevenDaysLater)) {
               rrResponse.setRrAlertFlag(1);
           }if (endDate.isAfter(today) ) {
               rrResponse.setRrAlertFlag(0);
           }if(endDate.isBefore(today)){
               rrResponse.setRrAlertFlag(2);
           }

           List<SkillResponse> skillResponseList = new ArrayList<>();
           List<SkillMapperRR> skillMapperRRS = skillMapperRrRepository.findByRrMasterId(rrMaster1);
           for (SkillMapperRR skillMapperRR : skillMapperRRS) {
               SkillResponse skillResponse = new SkillResponse();
               if (skillMapperRR.getSkillsId() != null) {
                   skillResponse.setId(skillMapperRR.getSkillsId().getId());
                   skillResponse.setSkillSet(skillMapperRR.getSkillsId().getSkillSet());
                   skillResponse.setSkillType(new SkillTypeResponse(skillMapperRR.getSkillsId().getSkillType().getId(),skillMapperRR.getSkillsId().getSkillType().getSkillTypeName()));
                   skillResponseList.add(skillResponse);
               }
           }
           rrResponse.setSkillsId(skillResponseList);
           rrList.add(rrResponse);
       }
       log.info("RRMasterServiceImpl------------getRRByOwnerIdPagination------{}",ownerId,pageNumber,pageSize,searchTerm);

       return new RrListByOwnerResponse(totalRRPresent, rrList);
   }
    @Override
    public Set<OwnerResponse> getListOfOwners() {
        log.info("RRMasterServiceImpl----------getListOfOwners--------{}");
        List<RRMaster> all = rrMasterRepository.findByActive(true);
        Set<OwnerResponse> ownerList = new HashSet<>();
        for (RRMaster rrMaster : all) {
            ownerList.add(rrMasterEntityToOwnerResponse(rrMaster));
        }
        return ownerList;
    }
    private OwnerResponse rrMasterEntityToOwnerResponse(RRMaster rrMaster) {
        OwnerResponse response  = new OwnerResponse();
        response.setUserId(rrMaster.getOwnerId().getUserId());
        response.setUserType(rrMaster.getOwnerId().getUserType());
        response.setUserFirstName(rrMaster.getOwnerId().getUserFirstName());
        response.setUserLastName(rrMaster.getOwnerId().getUserLastName());
        return response;
    }
}

