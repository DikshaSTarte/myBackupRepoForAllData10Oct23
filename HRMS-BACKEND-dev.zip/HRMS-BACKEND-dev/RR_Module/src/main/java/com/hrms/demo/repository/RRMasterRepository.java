package com.hrms.demo.repository;

import com.hrms.demo.dto.response.DashboardCountDTO;
import com.hrms.demo.model.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;
@Repository
public interface RRMasterRepository extends JpaRepository<RRMaster,Integer>, JpaSpecificationExecutor<RRMaster> {
    RRMaster findByActiveAndRrMasterId(boolean active, Integer rrMasterId);

    List<RRMaster> findByActive(boolean b);

    List<RRMaster> findByActiveAndOwnerId(boolean b, User ownerId);

    //    @Query("SELECT r FROM RRMaster r WHERE " +
//            "r.ownerId.username LIKE CONCAT(:searchTerm, '%') OR " +
//            "CONCAT(r.experience, '') LIKE CONCAT(:searchTerm, '%') OR " +
//            "CONCAT(r.requiredCount, '') LIKE CONCAT(:searchTerm, '%') OR " +
//            "r.rrStatus.rrStatusName LIKE CONCAT(:searchTerm, '%') OR " +
//            "r.company.companyName LIKE CONCAT(:searchTerm, '%') ")
//    List<RRMaster> findByActiveAndSearchTerm(boolean active,String searchTerm);

//    @Query("SELECT r FROM RRMaster r WHERE (r.ownerId.userFirstName LIKE CONCAT(:searchTerm, '%')   OR r.rrStatus.rrStatusName LIKE CONCAT(:searchTerm, '%') OR r.company.companyName LIKE CONCAT(:searchTerm, '%')) AND r.active = :active")
//    List<RRMaster> findByActiveAndSearchTerm(boolean active, String searchTerm,Pageable pageable);

//    @Query("SELECT r FROM RRMaster r WHERE " +
//            "((r.ownerId.userFirstName LIKE CONCAT(:searchTerm, '%') OR r.ownerId.userLastName LIKE CONCAT(:searchTerm, '%')) " +
//            "OR r.rrStatus.rrStatusName LIKE CONCAT(:searchTerm, '%') OR r.company.companyName LIKE CONCAT(:searchTerm, '%')) " +
//            "AND r.active = :active")

    @Query("SELECT r FROM RRMaster r WHERE " +
            "((r.ownerId.userFirstName LIKE CONCAT(:searchTerm, '%') OR r.ownerId.userLastName LIKE CONCAT(:searchTerm, '%')) " +
            "OR r.rrStatus.rrStatusName LIKE CONCAT(:searchTerm, '%') OR r.company.companyName LIKE CONCAT(:searchTerm, '%')) " +
            " OR (CONCAT(r.ownerId.userFirstName, ' ', r.ownerId.userLastName) LIKE CONCAT(:searchTerm, '%')) " +
            "AND r.active = :active")
    List<RRMaster> findByActiveAndSearchTerm(@Param("active") boolean active, @Param("searchTerm") String searchTerm, Pageable pageable);

    @Query("SELECT COUNT(r) FROM RRMaster r WHERE " +
            "((r.ownerId.userFirstName LIKE CONCAT(:searchTerm, '%') OR r.ownerId.userLastName LIKE CONCAT(:searchTerm, '%')) " +
            "OR r.rrStatus.rrStatusName LIKE CONCAT(:searchTerm, '%') OR r.company.companyName LIKE CONCAT(:searchTerm, '%')) " +
            " OR (CONCAT(r.ownerId.userFirstName, ' ', r.ownerId.userLastName) LIKE CONCAT(:searchTerm, '%')) " +
            "AND r.active = :active")
    Long countByActiveAndSearchTerm(@Param("active") boolean active, @Param("searchTerm") String searchTerm);




//    @Query("SELECT DISTINCT rr FROM RRMaster rr " +
//            "LEFT JOIN SkillMapperRR.skillsId skillEntity " +
//            "WHERE rr.active = true " +
//            "AND (coalesce(:companyIds, null) IS NULL OR rr.company.companyId IN :companyIds) " +
//            "AND (coalesce(:ownerRoleIds, null) IS NULL OR rr.ownerId.userType.userTypeId IN :ownerRoleIds) " +
//            "AND (coalesce(:ownerNamesIds, null) IS NULL OR rr.ownerId.userId IN :ownerNamesIds) " +
//            "AND (coalesce(:userRolesIds, null) IS NULL OR skillEntity.skillType.id IN :userRolesIds)")
//    List<RRMaster> filterRRMasters(
//            @Param("companyIds") List<Integer> companyIds,
//            @Param("userRolesIds") List<Integer> userRolesIds,
//            @Param("ownerRoleIds") List<Integer> ownerRoleIds,
//            @Param("ownerNamesIds") List<Integer> ownerNamesIds);



//    @Query("SELECT COUNT(DISTINCT rr) FROM RRMaster rr " +
//            "LEFT JOIN SkillMapperRR.skillsId skillEntity " +
//            "WHERE rr.active = true " +
//            "AND (coalesce(:companyIds, null) IS NULL OR rr.company.companyId IN :companyIds) " +
//            "AND (coalesce(:ownerRoleIds, null) IS NULL OR rr.ownerId.userType.userTypeId IN :ownerRoleIds) " +
//            "AND (coalesce(:ownerNamesIds, null) IS NULL OR rr.ownerId.userId IN :ownerNamesIds) " +
//            "AND (coalesce(:userRolesIds, null) IS NULL OR skillEntity.skillType.id IN :userRolesIds)")
//    Long countFilteredRRMasters(
//            @Param("companyIds") List<Integer> companyIds,
//            @Param("userRolesIds") List<Integer> userRolesIds,
//            @Param("ownerRoleIds") List<Integer> ownerRoleIds,
//            @Param("ownerNamesIds") List<Integer> ownerNamesIds);




    @Query("SELECT COUNT(r) FROM RRMaster r WHERE r.active =:active AND (r.ownerId.userFirstName LIKE CONCAT(:searchTerm, '%')OR r.ownerId.userLastName LIKE CONCAT(:searchTerm, '%') OR CONCAT(r.experience, '') LIKE CONCAT(:searchTerm, '%') OR CONCAT(r.requiredCount, '') LIKE CONCAT(:searchTerm, '%') OR r.rrStatus.rrStatusName LIKE CONCAT(:searchTerm, '%') OR r.company.companyName LIKE CONCAT(:searchTerm, '%'))")
    long countByActiveAndSearchTerm1(boolean active, String searchTerm);

    long countByActive(boolean active);

    Page<RRMaster> findByActiveOrderByRrMasterIdDesc(boolean active, Pageable pageable);

    Integer countByRrStatusAndStartDateBetween(RRStatus rrStatus, LocalDate previousMonth, LocalDate currentMonth);

    @Query("SELECT new com.hrms.demo.dto.response.DashboardCountDTO(COUNT(rrm.rrMasterId), rrm.company.companyId) " +
            " FROM RRMaster rrm WHERE " +
            "rrm.active = true and rrm.startDate BETWEEN :sevenDay and NOW() GROUP BY rrm.company.companyId ")
    List<DashboardCountDTO> findRrCountLessThanSevenDays(LocalDate sevenDay);

    @Query("SELECT new com.hrms.demo.dto.response.DashboardCountDTO(COUNT(rrm.rrMasterId), rrm.company.companyId) " +
            " FROM RRMaster rrm WHERE " +
            "rrm.active = true and rrm.startDate BETWEEN :thirtyDate and :sevenDay GROUP BY rrm.company.companyId ")
    List<DashboardCountDTO> findRrCountBetweenSevenAndThirtyDays(LocalDate sevenDay, LocalDate thirtyDate);

    @Query("SELECT new com.hrms.demo.dto.response.DashboardCountDTO(COUNT(rrm.rrMasterId), rrm.company.companyId) " +
            " FROM RRMaster rrm WHERE " +
            "rrm.active = true and rrm.startDate <= :thirtyDate GROUP BY rrm.company.companyId ")
    List<DashboardCountDTO> findRrCountGreaterThanThirtyDays(LocalDate thirtyDate);

    //List<RRMaster> findByActiveAndRRStatusRrStatusId(boolean active,Integer rrStatusId);

    List<RRMaster> findByActiveAndRrStatusRrStatusId(boolean active, Integer statusId);

    //long countByActiveAndRRStatusRrStatusId(boolean active,Integer rrStatusId);


    Integer countByActiveAndRrStatusRrStatusId(boolean active, Integer statusId);


    //    Integer countByRrMasterIdAndCompany(RRMaster rrMasterId, Company company);
    @Query("SELECT new com.hrms.demo.dto.response.DashboardCountDTO(COUNT(rrm.rrMasterId),rrm.company.companyId)" +
            "FROM RRMaster rrm  where " +
            " rrm.active = true group by rrm.company.companyId ")
    List<DashboardCountDTO> findRrCount();


    @Query("SELECT rr FROM RRMaster rr WHERE rr.active=true AND " +
            "(rr.ownerId.userId = :byUserId) AND " +
            "(LOWER(rr.company.companyName) LIKE LOWER(CONCAT(:searchTerm,'%')))")
    Page<RRMaster> findByOwnerIdAndSearchTerm(@Param("byUserId") Integer byUserId, @Param("searchTerm") String searchTerm, Pageable pageable);

    @Query("SELECT COUNT(rr) FROM RRMaster rr WHERE rr.active=true AND " +
            "(rr.ownerId.userId = :byUserId) AND " +
            "(LOWER(rr.company.companyName) LIKE LOWER(CONCAT(:searchTerm,'%')))")
    long  countByOwnerIdAndSearchTerm(@Param("byUserId") Integer byUserId, @Param("searchTerm") String searchTerm);

    Page<RRMaster> findByActiveAndOwnerId_UserIdOrderByRrMasterIdDesc(boolean b, Integer userId, Pageable pageable);

    List<RRMaster> findByEndDateBetween(LocalDate localDate, LocalDate localDate1);

    List<RRMaster> findByActiveAndEndDateBetween(boolean Active, LocalDate localDate, LocalDate localDate1);

    List<RRMaster> findByActiveAndEndDateBetweenAndRrStatus_RrStatusId(boolean b, LocalDate localDate, LocalDate localDate1, int i);


    boolean existsByActiveAndCompany(boolean b, Integer companyId);

    boolean existsByActiveAndStartDate(boolean b, LocalDate startDate);

    boolean existsByActiveAndEndDate(boolean b, LocalDate endDate);

    List<RRMaster> findByActiveAndEndDate(boolean active,LocalDate tomorrow);

    List<RRMaster> findDistinctRrMastersByCompanyAndActiveIsTrue(Company company);

}


