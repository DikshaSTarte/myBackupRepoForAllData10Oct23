package com.hrms.demo.model;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "user_type")
public class UserType extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)

    @Column(name = "userTypeId")
    private  Integer userTypeId ;

    @Column(name = "userTypeName")
    private String userTypeName ;

}
