package com.hrms.demo.dto.request;

import com.hrms.demo.dto.response.CandidateResponse;
import com.hrms.demo.model.Candidate;
import com.hrms.demo.model.RRMaster;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RRCandidateMapperRequest {
    private Integer rrId;
    private List<Integer> candidateId;
}