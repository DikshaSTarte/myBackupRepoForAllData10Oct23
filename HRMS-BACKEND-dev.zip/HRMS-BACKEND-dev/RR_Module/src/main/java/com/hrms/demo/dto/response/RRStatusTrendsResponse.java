package com.hrms.demo.dto.response;

import com.hrms.demo.model.RRMaster;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RRStatusTrendsResponse {

    private LocalDate month;

    private Integer fulfilled;

    private Integer open;

    private Integer cancel;

    private Integer hold;
}