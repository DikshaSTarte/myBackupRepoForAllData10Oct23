package com.hrms.demo.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DashboardResponse {
    private LocalDate month;

    private Long selected;

    private Long onHold;

    private Long rejected;
}
