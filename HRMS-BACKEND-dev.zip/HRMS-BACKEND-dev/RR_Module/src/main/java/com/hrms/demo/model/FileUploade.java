package com.hrms.demo.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name="file")
@AllArgsConstructor
@NoArgsConstructor
public class FileUploade extends BaseEntity{
   /* @Id
    @GeneratedValue(strategy = GenerationType.AUTO)*/
   @Id
   @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "file_generator")
   @SequenceGenerator(name = "file_generator", sequenceName = "file_SEQUENCE", initialValue = 7504, allocationSize = 1)
   @Column(name = "fileId")
    private Integer fileId;
    @Column(name = "fileName")
    private String fileName;
    @Column(name = "fileSize")
    private Long fileSize;
    @Column(name = "fileType")
    private String fileType;
    @Column(name = "filePath")
    private String filePath;

}
