package com.hrms.demo.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Entity
@Table(name="users")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class User extends BaseEntity implements UserDetails {

   /* @Id
    @GeneratedValue (strategy = GenerationType.AUTO )*/

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "users_generator")
    @SequenceGenerator(name = "users_generator", sequenceName = "users_SEQUENCE", initialValue = 7494, allocationSize = 1)
    private Integer userId;
    private String Otp;
    private String username;

    private String password;

    @ManyToOne
    @JoinColumn(name = "userTypeId")
    private  UserType userType;

    private String userFirstName;


    private String userLastName ;

    //@Column(name = "user_contact",unique = true)
    @Column(name = "user_contact")
    private String userContact;

    @Column(name = "user_email_id")
    private String userEmailId;

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        List<SimpleGrantedAuthority> authorities = new ArrayList<>();

        authorities.add(new SimpleGrantedAuthority(userType.getUserTypeName()));
        // authorities.add(new SimpleGrantedAuthority(role.getRole()));
        return authorities;
    }
    @Override
    public boolean isAccountNonExpired() {
        return isActive();
    }

    @Override
    public boolean isAccountNonLocked() {
        return isActive();
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return isActive();
    }

    @Override
    public boolean isEnabled() {
        return isActive();
    }

    /*@ManyToOne
    @JoinColumn(name = "fileId")
    private FileUploade fileId;  */

}
