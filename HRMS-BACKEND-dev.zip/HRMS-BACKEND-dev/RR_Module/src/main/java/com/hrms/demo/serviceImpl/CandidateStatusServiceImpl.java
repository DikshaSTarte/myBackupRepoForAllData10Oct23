package com.hrms.demo.serviceImpl;

import com.hrms.demo.exceptionHandler.exception.NoDataFoundException;
import com.hrms.demo.mapper.CandidateMapper;
import com.hrms.demo.repository.CandidateStatusRepository;
import com.hrms.demo.dto.request.CandidateStatusRequest;
import com.hrms.demo.dto.response.CandidateStatusResponse;
import com.hrms.demo.model.CandidateStatus;
import com.hrms.demo.service.CandidateStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CandidateStatusServiceImpl implements CandidateStatusService {
    @Autowired
    private CandidateStatusRepository candidateStatusRepository;

    @Autowired
    private CandidateMapper candidateMapper;

    @Override
    public CandidateStatusResponse saveCandidateStatus(CandidateStatusRequest candidateStatusRequest) {
        CandidateStatus candidateStatus = new CandidateStatus();
        candidateStatus.setCandidateStatusName(candidateStatusRequest.getCandidateStatusName());
        CandidateStatus save = this.candidateStatusRepository.save(candidateStatus);
        CandidateStatusResponse candidateStatusResponse = candidateMapper.candidateStatusMapper(save);
        return candidateStatusResponse;
    }

    @Override
    public String deleteCandidateStatusById(Integer candidateStatusId) {
        Optional<CandidateStatus> candidateStatus = candidateStatusRepository.findById(candidateStatusId);
        if (candidateStatus.get() != null) {
            candidateStatus.get().setActive(false);
            candidateStatusRepository.save(candidateStatus.get());
        } else {
            throw new NoDataFoundException("Candidate Status Not Found");
        }
        return "Success";
    }

    @Override
    public CandidateStatusResponse getCandidateStatusById(Integer candidateStatusId) {
        CandidateStatus candidateStatus = candidateStatusRepository.findByActiveAndCandidateStatusId(true, candidateStatusId);
        CandidateStatusResponse candidateStatusResponse = candidateMapper.candidateStatusMapper(candidateStatus);
        return candidateStatusResponse;
    }

   /* @Override
    public CandidateStatusResponse updateCandidateStatus(Integer candidateStatusId, CandidateStatusRequest candidateStatusRequest) {
        CandidateStatus candidateStatus = candidateStatusRepository.findByActiveAndCandidateStatusId(true, candidateStatusId);
        candidateStatus.setCandidateStatusName(candidateStatusRequest.getCandidateStatusName());
        return null;
    }*/

    @Override
    public List<CandidateStatusResponse> getListCandidateStatus() {
        List<CandidateStatus> candidateStatuses = candidateStatusRepository.findByActive(true);
        return candidateMapper.candidateStatusListMapper(candidateStatuses);
    }
}
