package com.hrms.demo.repository;


import com.hrms.demo.model.InterviewerRating;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InterviewerRatingRepository extends JpaRepository<InterviewerRating, Integer> {
    InterviewerRating findByActiveAndInterviwerRatingId(boolean active,Integer InterviwerRatingId);
    List<InterviewerRating> findByActive(boolean b);
}
