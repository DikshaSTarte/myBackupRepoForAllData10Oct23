package com.hrms.demo.serviceImpl;

import com.hrms.demo.repository.UserTypeRepository;
import com.hrms.demo.dto.response.UserTypeResponse;
import com.hrms.demo.model.UserType;
import com.hrms.demo.service.UserTypeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.ArrayList;
import java.util.List;
@Slf4j
public class UserTypeServiceImpl implements UserTypeService {
    @Autowired
    UserTypeRepository userTypeRepository ;
    @Override
    public List<UserTypeResponse> getListOfUsers() {
        log.info("UserTypeServiceImpl-------------getListOfUsers-----------{}");
        List<UserType> all = userTypeRepository.findByActive(true);
        List<UserTypeResponse> userTypeResposeList= new ArrayList<>();
        for (UserType userType:all) {
            userTypeResposeList.add(userTypeEntityToUserTypeResponse(userType));
        }
        log.info("UserTypeServiceImpl-------------getListOfUsers-----------{}");
        return userTypeResposeList;
    }
    private UserTypeResponse userTypeEntityToUserTypeResponse(UserType userType) {
        UserTypeResponse userTypeResponse = new UserTypeResponse();
        userTypeResponse.setUserTypeId(userType.getUserTypeId());

        return userTypeResponse ;
    }
}
