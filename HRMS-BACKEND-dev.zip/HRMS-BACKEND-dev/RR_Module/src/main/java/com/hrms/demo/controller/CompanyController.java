package com.hrms.demo.controller;

import com.hrms.demo.dto.request.CompanyRequest;
import com.hrms.demo.dto.response.CompanyListResponse;
import com.hrms.demo.dto.response.CompanyResponse;
import com.hrms.demo.dto.response.GenericResponseDTO;
import com.hrms.demo.globleexception.CompanyAlreadyExistsException;
import com.hrms.demo.model.Company;

import com.hrms.demo.service.CompanyService;

import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/v1/company")
public class CompanyController {
    @Autowired
    private CompanyService companyService;

    @PostMapping("/save")
    public GenericResponseDTO SaveCompanyData(@Valid @RequestBody CompanyRequest companyRequest) throws CompanyAlreadyExistsException {
        log.info("CompanyController------SaveCompData--{}", companyRequest);
        return companyService.saveCompany(companyRequest);

    }

    @DeleteMapping("/delete/{companyId}")
    public ResponseEntity<Void> deleteCompanyData(@PathVariable Integer companyId) {
        log.info("CompanyController------deleteCompanyData()--{}", companyId);
        companyService.deleteCompanyById(companyId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/list")
    public List<CompanyResponse> getShowListCompany() {
        log.info("CompanyController------getShowListCompany--{}");
        return this.companyService.getListCompany();
    }
    
    @GetMapping("/get/{companyId}")
    public CompanyResponse getCompById(@PathVariable Integer companyId) {
        log.info("CompanyController------getCompById--{}", companyId);
        return this.companyService.getCompanyById(companyId);
    }

    @PutMapping("/update/{companyId}")
    public ResponseEntity<CompanyResponse> updateCompanyData(@Valid @PathVariable Integer companyId, @RequestBody CompanyRequest companyRequest) {
        CompanyResponse companyResponse = companyService.updateCompany(companyId, companyRequest);
        if (companyResponse != null) {
            log.info("CompanyController------updateCompData--{}", companyRequest);
            return ResponseEntity.ok(companyResponse);
        } else {
            log.error("CompanyController------updateCompData--{}", companyRequest);
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/getAllCompany")
    public ResponseEntity<List<CompanyResponse>> getAllCompany(@RequestParam(defaultValue = "0") Integer pageNumber, @RequestParam(defaultValue = "") String searchKey) {
        List<CompanyResponse> result = companyService.getAllCompany(pageNumber, searchKey);
        log.info("CompanyController------getAllCompany--{}", pageNumber, searchKey);
        return ResponseEntity.ok(result);
    }

    /*@GetMapping("/pagination")
    public Page<Company> searchCompany(
            @RequestParam(required = false) String searchKeyword,
            @RequestParam(defaultValue = "0") int pageNo,
            @RequestParam(defaultValue = "5") int pageSize) {
        return companyService.searchCompany(searchKeyword, pageNo, pageSize);
    }*/
    @GetMapping("/pagination")
    public Page<Company> searchCompany(
            @RequestParam(required = false) String searchKeyword,
            @RequestParam(defaultValue = "0") int pageNo,
            @RequestParam(defaultValue = "5") int pageSize) {
        return companyService.searchCompany(searchKeyword, pageNo, pageSize);
    }

    //Change the endpoint name -- remove the check
    @GetMapping("/list/check")
    public ResponseEntity<CompanyListResponse> getListOfCompany(@RequestParam(value = "pageNumber", defaultValue = "0", required = false) Integer pageNumber,
                                                                  @RequestParam(value = "pagesize", defaultValue = "10", required = false) Integer pageSize,
                                                                  @RequestParam(value = "searchTerm", defaultValue = "", required = false) String searchTerm) {

        CompanyListResponse companyListResponse = companyService.getListCompanyOp(pageNumber, pageSize, searchTerm);
        log.info("CompanyController------getShowListCompany--{}");
        return ResponseEntity.ok(companyListResponse);
    }
}
