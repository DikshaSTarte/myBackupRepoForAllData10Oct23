package com.hrms.demo.controller;
import com.hrms.demo.dto.request.InterviewerRequest;
import com.hrms.demo.dto.response.CandidateResponse;
import com.hrms.demo.dto.response.InterviewerListResponse;
import com.hrms.demo.dto.response.InterviewerResponse;
import com.hrms.demo.service.InterviewerService;
import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@Slf4j
@RestController
@RequestMapping("/api/v1/interviewer")
public class InterviewerController {
    @Autowired
    private InterviewerService interviewerService;
    @PostMapping("/save")
    public InterviewerResponse SaveIntervData(@Valid @RequestBody InterviewerRequest interviewerRequest){

        log.info("InterviewerController------SaveIntervData--{}",interviewerRequest);
        return interviewerService.saveInterviewer(interviewerRequest);
    }
    @DeleteMapping("/delete/{interviewerId}")
    public ResponseEntity<Void> deleteInterviewerData(@PathVariable Integer interviewerId){
        interviewerService.deleteInterviewerById(interviewerId);
        log.info("InterviewerController------deleteInterviewerData--{}",interviewerId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/list")
    public List<InterviewerResponse> getShowListInterviewer() {
        log.info("InterviewerController------getShowListInterviewer--{}");
        return this.interviewerService.getListInterviewer();
    }


    @GetMapping("/get/{interviewerId}")
    public InterviewerResponse getIntervById(@PathVariable Integer interviewerId){
        log.info("InterviewerController------getIntervById--{}",interviewerId);
        return this.interviewerService.getInterviewerById(interviewerId);
    }
    @PutMapping("/update/{interviewerId}")
    public ResponseEntity<InterviewerResponse> updateIntervData(@Valid @PathVariable Integer interviewerId ,@RequestBody InterviewerRequest interviewerRequest ){
        InterviewerResponse interviewerResponse=interviewerService.updateInterviewer(interviewerId,interviewerRequest);
        if(interviewerResponse!=null){
            log.info("InterviewerController------updateIntervData--{}",interviewerRequest);
            return ResponseEntity.ok(interviewerResponse);
        }else {
            log.error("InterviewerController------updateIntervData--{}",interviewerRequest,"update interviewer failed");
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/getAllInterviewer")
    public ResponseEntity<List<InterviewerResponse>> getAllInterviewer(@RequestParam(defaultValue = "0") Integer pageNumber, @RequestParam(defaultValue = "") String searchKey){
        List<InterviewerResponse>result= interviewerService.getAllInterviewer(pageNumber, searchKey);
        System.out.println("Result Size Is >> "+result.size());
        log.info("InterviewerController------getAllInterviewer--{}",pageNumber,searchKey);
        return ResponseEntity.ok(result);
    }
    @GetMapping("/listInterviewer")
    public ResponseEntity<InterviewerListResponse> getShowListCandidates(@RequestParam(value = "pageNumber",defaultValue = "0",required = false) Integer pageNumber,
                                                                         @RequestParam(value = "pageSize",defaultValue = "10",required = false) Integer pageSize,
                                                                         @RequestParam(value = "searchTerm",defaultValue = "",required = false)String searchTerm ){
// log.info("CandidateController------getShowListCandidates--{}");

        InterviewerListResponse intRes=interviewerService.getListInterviewersPg(pageNumber, pageSize, searchTerm);
        log.info("InterviewerController------getShowListCandidates--{}",pageNumber,pageSize,searchTerm);
        return ResponseEntity.ok(intRes);
    }
}
