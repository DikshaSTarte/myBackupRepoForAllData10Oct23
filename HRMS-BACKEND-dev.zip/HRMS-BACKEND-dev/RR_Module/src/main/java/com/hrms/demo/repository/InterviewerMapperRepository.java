package com.hrms.demo.repository;

import com.hrms.demo.model.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
@Repository
public interface InterviewerMapperRepository extends JpaRepository<InterviewerMapper,Integer> {



    List<InterviewerMapper> findByInterviewerCandidateMapper(InterviewerCandidateMapper interviewerCandidateMapper);
    List<InterviewerMapper> findByActive(boolean b);

    List<InterviewerMapper> findByActiveAndRrId(boolean b, RRMaster rrMaster);

    List<InterviewerMapper> findByInterviewerId(Interviewer interviewerId);

    Candidate findByCandidateId(Candidate candidateId);


    long countByActive(boolean active);

    List<InterviewerMapper> findByActiveAndRrIdAndCandidateId(boolean b , RRMaster rrMaster, Candidate candidate);
    Page<InterviewerMapper> findByActiveOrderByInterviewerIdDesc(boolean active, Pageable pageable);

    @Query("SELECT r FROM InterviewerMapper r WHERE (r.candidateId.candidateFirstName LIKE CONCAT(:searchTerm, '%') " +
//            "OR r.candidateId.candidateStatus LIKE CONCAT(:searchTerm, '%')" +
            " OR r.interviewerId.interviewerFirstName LIKE CONCAT(:searchTerm, '%')) AND r.active = :active")
    Page<InterviewerMapper> findByActiveAndSearchTerm(boolean active, String searchTerm, Pageable pageable);

     Page<InterviewerMapper> findByActiveOrderByInterviewerMapperIdDesc(boolean active, Pageable pageable);



 /*   @Query("SELECT im FROM InterviewerMapper im WHERE im.active=true AND " +
            "(icm.RRMaster.rrId = :rrId) AND " +
            "((LOWER(icm.candidateId.candidateFirstName) LIKE LOWER(CONCAT(:searchTerm,'%'))) OR " +
            "(LOWER(icm.candidateId.candidateStatus) LIKE LOWER(CONCAT(:searchTerm,'%'))) OR " +
            "(LOWER(icm.interviewerId.interviewerFirstName) LIKE LOWER(CONCAT(:searchTerm,'%'))))")
    Page<InterviewerMapper> findByActiveAndRrIdAndSearchTerm(boolean active,@Param("rrId") RRMaster rrMaster, @Param("searchTerm") String searchTerm, Pageable pageable);
    Page<InterviewerMapper> findByActiveRrIdOrderByInterviewerMapperIdDesc(boolean active,RRMaster rrMaster,Pageable pageable);*/


/* @Query("SELECT r FROM InterviewerMapper r WHERE (r.candidateId.candidateFirstName LIKE CONCAT(:searchTerm, '%') OR r.candidateId.candidateStatus LIKE CONCAT(:searchTerm, '%') OR r.interviewerId.interviewerFirstName LIKE CONCAT(:searchTerm, '%')) AND r.active = :active")
 Page<InterviewerMapper> findByActiveAndRrIdAndSearchTerm(boolean active,RRMaster rrMaster, String searchTerm, Pageable pageable);

    Page<InterviewerMapper> findByActiveRrIdOrderByInterviewerMapperIdDesc(boolean active,RRMaster rrMaster, Pageable pageable);*/
/*
@Query("SELECT r FROM InterviewerMapper r WHERE (r.candidateId.candidateFirstName LIKE CONCAT(:searchTerm, '%') OR r.candidateId.candidateStatus LIKE CONCAT(:searchTerm, '%') OR r.interviewerId.interviewerFirstName LIKE CONCAT(:searchTerm, '%')) AND r.active = :active")
Page<InterviewerMapper> findByActiveAndRrIdAndSearchTerm(boolean active, RRMaster rrMaster, String searchTerm, Pageable pageable);

    Page<InterviewerMapper> findByActiveRrIdOrderByInterviewerMapperIdDesc(boolean active, RRMaster rrMaster, Pageable pageable);
*/



  /*  @Query("SELECT r FROM InterviewerMapper r WHERE (r.candidateId.candidateFirstName LIKE CONCAT(:searchTerm, '%') OR r.candidateId.candidateStatus LIKE CONCAT(:searchTerm, '%') OR r.interviewerId.interviewerFirstName LIKE CONCAT(:searchTerm, '%')) AND r.active = :active AND r.rrId = :rrMaster")
    Page<InterviewerMapper> findByActiveAndRrIdAndSearchTerm(boolean active, RRMaster rrMaster, String searchTerm, Pageable pageable);

    Page<InterviewerMapper> findByActiveRrIdOrderByInterviewerMapperIdDesc(boolean active, RRMaster rrMaster, Pageable pageable);*/








    /*Page<InterviewerMapper> findByRrIdOrderByInterviewerMapperIdDesc(RRMaster rrMaster,Pageable pageable);
    @Query("SELECT im FROM InterviewerMapper im WHERE im.active=true AND " +
            "(im.rrId.rrMasterId = :rrMasterId) AND " +
            "((LOWER(im.candidateId.candidateFirstName) LIKE LOWER(CONCAT(:searchTerm,'%'))) OR " +
            "((LOWER(im.candidateId.candidateLastName) LIKE LOWER(CONCAT(:searchTerm,'%'))) OR " +
            "(LOWER(im.candidateId.candidateStatus.candidateStatusName) LIKE LOWER(CONCAT(:searchTerm,'%'))) OR " +
            "((LOWER(im.interviewerId.interviewerLastName) LIKE LOWER(CONCAT(:searchTerm,'%'))) OR " +
            "(LOWER(im.interviewerId.interviewerFirstName) LIKE LOWER(CONCAT(:searchTerm,'%'))))")
    Page<InterviewerMapper> findByRrId_RrMasterIdAndSearchTerm(@Param("rrMasterId") Integer rrMasterId, @Param("searchTerm") String searchTerm, Pageable pageable);
*/

    Page<InterviewerMapper> findByRrIdOrderByInterviewerMapperIdDesc(RRMaster rrMaster,Pageable pageable);
    @Query("SELECT im FROM InterviewerMapper im WHERE im.active = true AND " +
            "im.rrId.rrMasterId = :rrMasterId AND " +
            "((LOWER(im.candidateId.candidateFirstName) LIKE LOWER(CONCAT('%', :searchTerm, '%'))) OR " +
            "(LOWER(im.candidateId.candidateLastName) LIKE LOWER(CONCAT('%', :searchTerm, '%'))) OR " +
//            "(LOWER(im.candidateId.candidateStatus.candidateStatusName) LIKE LOWER(CONCAT('%', :searchTerm, '%'))) OR " +
            "(LOWER(im.interviewerId.interviewerLastName) LIKE LOWER(CONCAT('%', :searchTerm, '%'))) OR " +
            "(LOWER(im.interviewerId.interviewerFirstName) LIKE LOWER(CONCAT('%', :searchTerm, '%'))))")
    Page<InterviewerMapper> findByRrId_RrMasterIdAndSearchTerm(@Param("rrMasterId") Integer rrMasterId, @Param("searchTerm") String searchTerm, Pageable pageable);

   // Integer countByCandidateId_CandidateStatusAndDateBetween(CandidateStatus selected, LocalDate sDate, LocalDate eDate);
}
