package com.hrms.demo.serviceImpl;
import com.hrms.demo.dto.request.CandidateForUserRequest;
import com.hrms.demo.dto.request.RRForUserRequest;
import com.hrms.demo.dto.response.UserCandidateMapperResponse;
import com.hrms.demo.model.*;
import com.hrms.demo.repository.CandidateRepository;
import com.hrms.demo.repository.UserCandidateMapperRepository;
import com.hrms.demo.repository.UserRepository;
import com.hrms.demo.service.UserCandidateMapperService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Slf4j
@Service
public class UserCandidateMapperServiceImpl implements UserCandidateMapperService {
    @Autowired
    private UserCandidateMapperRepository userCandidateMapperRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private CandidateRepository candidateRepository;
    @Override
    public List<UserCandidateMapperResponse> getCandidateUserId(Integer userId) {
        log.info("UserCandidateMapperServiceImpl----------------getCandidateUserId-------------{}",userId);
        List<UserCandidateMapperResponse> candidateList = new ArrayList<>();
        User user = userRepository.findById(userId).get();
        List<UserCandidateMapper> candidateMapperList = userCandidateMapperRepository.findByActiveAndUserId(true,user);
        for (UserCandidateMapper userCandidateMapper:candidateMapperList){
            UserCandidateMapperResponse userCandidateMapperResponse = new UserCandidateMapperResponse();
            userCandidateMapperResponse.setUserId(userCandidateMapper.getUserId().getUserId());
            userCandidateMapperResponse.setCandidateId(userCandidateMapper.getCandidateId());
            candidateList.add(userCandidateMapperResponse);
        }
        log.info("UserCandidateMapperServiceImpl----------------getCandidateUserId-------------{}",userId);
        return candidateList;
    }

    @Override

    public UserCandidateMapper saveCandidateForUser(CandidateForUserRequest request) {
        log.info("UserCandidateMapperServiceImpl----------------saveCandidateForUser-------------{}",request);
        UserCandidateMapper userCandidateMapper = new UserCandidateMapper();

        userCandidateMapper.setCandidateId(candidateRepository.findByCandidateId(request.getCandidateId()));

        userCandidateMapper.setUserId(userRepository.findByUserId(request.getUserId()));

        UserCandidateMapper save = this.userCandidateMapperRepository.save(userCandidateMapper);
        log.info("UserCandidateMapperServiceImpl----------------saveCandidateForUser-------------{}",request);
        return save;

    }
}