package com.hrms.demo.controller;

import com.hrms.demo.dto.response.ErrorResponse;
import com.hrms.demo.exceptionHandler.exception.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import com.hrms.demo.globleexception.SkillAlreadyExistForSKillTypeException;
@ControllerAdvice
@RestController
public class CustomExceptionHandler {
    @ExceptionHandler(SkillAlreadyExistForSKillTypeException.class)
    public ResponseEntity<ErrorResponse> handleSkillAlreadyExistException(SkillAlreadyExistForSKillTypeException ex) {
        ErrorResponse errorResponse = new ErrorResponse(ex.getMessage());
        return ResponseEntity.status(HttpStatus.CONFLICT).body(errorResponse);
    }
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleResourceNotFoundException(ResourceNotFoundException ex) {
        ErrorResponse response = new ErrorResponse();
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
    }
//    @ExceptionHandler(Exception.class)
//    public ResponseEntity<String> handleGenericException(Exception ex) {
//        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal Server Error");
//    }
}