package com.hrms.demo.globleexception;

public class newPasswordAndConformPasswordNotMatchesException extends RuntimeException {
    public newPasswordAndConformPasswordNotMatchesException(String s) {
        super(s);
    }
}
