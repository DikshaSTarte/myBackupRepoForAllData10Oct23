package com.hrms.demo.repository;

import com.hrms.demo.model.EmailTemplates;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmailTemplatesRepository extends JpaRepository<EmailTemplates, Integer> {
    EmailTemplates getEmailTemplatesByTemplateName(String templateName);
}
