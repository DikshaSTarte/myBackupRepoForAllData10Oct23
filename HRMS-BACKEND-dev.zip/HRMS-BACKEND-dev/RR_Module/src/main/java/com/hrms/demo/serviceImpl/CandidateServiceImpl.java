package com.hrms.demo.serviceImpl;

import com.hrms.demo.constants.ErrorCodes;
import com.hrms.demo.dto.request.CandidateRequest;
import com.hrms.demo.dto.response.*;
import com.hrms.demo.globleexception.CandiateAlredyExistException;
import com.hrms.demo.model.*;
import com.hrms.demo.repository.*;
import com.hrms.demo.service.CandidateService;
import lombok.extern.slf4j.Slf4j;
import nonapi.io.github.classgraph.json.JSONUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.File;
//import java.sql.SQLOutput;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class CandidateServiceImpl implements CandidateService {
    @Autowired
    private RRCandidateMapperRepository rRCandidateMapperRepository;
    @Autowired
    private CandidateRepository candidateRepository;

    @Autowired
    private CandidateStatusRepository candidateStatusRepository;

    @Autowired
    private SkillEntityRepository skillEntityRepository;

    @Autowired
    private SkillCandidateMapperRepository skillCandidateMapperRepository;
    @Autowired
    private FileUploadeRepository fileUploadeRepository;
    @Override
    public CandidateResponse saveCandidate(CandidateRequest candidateRequest) {
        log.info("CandidateServiceImpl--------------saveCandidate-------{}",candidateRequest);
        if (candidateRepository.existsByActiveAndCandidateEmail(true, candidateRequest.getCandidateEmail())) {
            log.error("CandidateServiceImpl---------saveCandidate------{}",candidateRequest.getCandidateEmail(),"candidate already exist");
            throw new CandiateAlredyExistException(ErrorCodes.CANDIDATE_ALREADY_EXISTS);
        }
        if (candidateRepository.existsByActiveAndCandidateContactNo(true, candidateRequest.getCandidateContactNo())) {
            log.error("CandidateServiceImpl---------saveCandidate------{}",candidateRequest.getCandidateContactNo(),"candidate already exist");
            throw new CandiateAlredyExistException("Candidate ContactNo already exist");
        }
        Candidate candidate = new Candidate();
        Optional<CandidateStatus> candidateStatus = candidateStatusRepository.findById(candidateRequest.getCandidateStatus());
        //Use mapper here for mapping the requestDTO to entity
        candidate.setCandidateFirstName(candidateRequest.getCandidateFirstName());
        candidate.setCandidateLastName(candidateRequest.getCandidateLastName());
        candidate.setCandidateContactNo(candidateRequest.getCandidateContactNo());
        candidate.setCandidateEmail(candidateRequest.getCandidateEmail());
        candidate.setNegotiableNoticePeriod(candidateRequest.isNegotiableNoticePeriod());
        candidate.setCandidateCurrentCompany(candidateRequest.getCandidateCurrentCompany());
        candidate.setCandidateExperience(candidateRequest.getCandidateExperience());
        candidate.setCandidateCurrentCtc(candidateRequest.getCandidateCurrentCtc());
        CandidateStatus candidateStatusId = candidateStatusRepository.findByActiveAndCandidateStatusId(true, candidateRequest.getCandidateStatus());
        Optional<FileUploade> fileUploade1 = fileUploadeRepository.findById(candidateRequest.getFileId());
        candidate.setFileId(fileUploade1.get());
        candidate.setCandidateNoticePeriod(candidateRequest.getCandidateNoticePeriod());
        candidate.setCandidateExpectedCtc(candidateRequest.getCandidateExpectedCtc());
        Candidate save = this.candidateRepository.save(candidate);

        List<Integer> skillsId = candidateRequest.getSkillsId();
        List<SkillCandidateMapper> skillCandidateMapperList = new ArrayList<>();

        List<SkillEntity> skillSave = skillEntityRepository.findByActiveAndIdIn(true, skillsId);

        skillSave.forEach(skill -> {
            SkillCandidateMapper skillCandidateMapper = new SkillCandidateMapper();
            skillCandidateMapper.setCandidate(save);
            skillCandidateMapper.setSkillEntity(skill);
            skillCandidateMapperList.add(skillCandidateMapper);
        });
      /*  for(Integer id : skillsId) {
//            SkillEntity skillSave = skillEntityRepository.findByActiveAndId(true, id);
            SkillCandidateMapper skillCandidateMapper = new SkillCandidateMapper();
            skillCandidateMapper.setCandidate(save);
            skillCandidateMapper.setSkillEntity(skillSave);
            skillCandidateMapperList.add(skillCandidateMapper);
        }*/
        skillCandidateMapperRepository.saveAll(skillCandidateMapperList);
        CandidateResponse candidateResponse = candidateEntityToCandidateResponse(save);
//        candidateResponse.setCandidateStatus(new CandidateStatusResponse(save.getCandidateStatus().getCandidateStatusId(), save.getCandidateStatus().getCandidateStatusName()));

        candidateResponse.setFileId(new FileUploadeResponse(save.getFileId().getFileId(), save.getFileId().getFileName(),save.getFileId().getFileSize(),save.getFileId().getFileType(),save.getFileId().getFilePath()));
        log.info("CandidateServiceImpl--------------saveCandidate-------{}",candidateRequest);
        return candidateResponse;
    }
    @Override
    public String deleteCandidateById(Integer candidateId) {
        log.info("CandidateServiceImpl--------------deleteCandidateById-------{}",candidateId);
        Optional<Candidate> candidate = candidateRepository.findById(candidateId);
        candidate.get().setActive(false);
        candidateRepository.save(candidate.get());
        log.info("CandidateServiceImpl--------------deleteCandidateById-------{}",candidateId);
        return "Candidate Successfully Deleted";
    }

    @Override
    public CandidateResponse getCandidateById(Integer candidateId) {
        log.info("CandidateServiceImpl--------------getCandidateById-------{}",candidateId);
        Candidate candidate = candidateRepository.findByActiveAndCandidateId(true, candidateId);

        return candidateEntityToCandidateResponse(candidate);
    }
    @Override
    public CandidateResponse updateCandidate(Integer candidateId, CandidateRequest candidateRequest) {
        log.info("CandidateServiceImpl--------------updateCandidate-------{}",candidateId,candidateRequest);
        Candidate candidate = candidateRepository.findByActiveAndCandidateId(true, candidateId);
        candidate.setCandidateFirstName(candidateRequest.getCandidateFirstName());
        candidate.setCandidateLastName(candidateRequest.getCandidateLastName());
        candidate.setCandidateExpectedCtc(candidateRequest.getCandidateExpectedCtc());
        candidate.setCandidateCurrentCtc(candidateRequest.getCandidateCurrentCtc());
        candidate.setCandidateNoticePeriod(candidateRequest.getCandidateNoticePeriod());
        candidate.setCandidateCurrentCompany(candidateRequest.getCandidateCurrentCompany());
        candidate.setCandidateContactNo(candidateRequest.getCandidateContactNo());
        candidate.setCandidateEmail(candidateRequest.getCandidateEmail());
        candidate.setCandidateExperience(candidateRequest.getCandidateExperience());
        candidate.setNegotiableNoticePeriod(candidateRequest.isNegotiableNoticePeriod());
        CandidateStatus candidateStatusId = candidateStatusRepository.findByActiveAndCandidateStatusId(true, candidateRequest.getCandidateStatus());
        if(candidateRequest.getFileId()!=0)
        {
            Optional<FileUploade> fileUploade1 = fileUploadeRepository.findByActiveAndFileId(true,candidateRequest.getFileId());
            deleteFile(candidate.getFileId().getFilePath());
            candidate.setFileId(fileUploade1.get());
        }
        Candidate update = this.candidateRepository.save(candidate);
        List<Integer> skillsId = candidateRequest.getSkillsId();
        List<SkillCandidateMapper> skillCandidateMapperList = new ArrayList<>();
        for (Integer id : skillsId){
            SkillEntity skilsave = skillEntityRepository.findByActiveAndId(true, id);
            SkillCandidateMapper skillCandidateMapper = new SkillCandidateMapper();

            skillCandidateMapper.setCandidate(update);
            skillCandidateMapper.setSkillEntity(skilsave);
            skillCandidateMapperList.add(skillCandidateMapper);
        }
        List<SkillCandidateMapper> existingSkillMapperList = skillCandidateMapperRepository.findByActiveAndCandidate(true,update);
        for (SkillCandidateMapper existingMapper : existingSkillMapperList) {
            existingMapper.setActive(false); // Soft-delete by setting 'active' to false
        }
        skillCandidateMapperRepository.saveAll(skillCandidateMapperList);
        CandidateResponse candidateResponse = candidateEntityToCandidateResponse(update);
        log.info("CandidateServiceImpl--------------updateCandidate-------{}",candidateId,candidateRequest);
        return candidateResponse;
    }

        public  void deleteFile(String filePath) {
            File fileToDelete = new File(filePath);
            if (fileToDelete.exists()) {
                boolean isDeleted = fileToDelete.delete();
                if (isDeleted) {
                    System.out.println("File deleted successfully: " + filePath);
                } else {
                    System.out.println("Failed to delete the file: " + filePath);
                }
            } else {
                System.out.println("File does not exist: " + filePath);
            }
        }
    @Override
    public List<CandidateResponse> getListCandidates() {
        log.info("CandidateServiceImpl--------------getListCandidates-------{}");
        List<Candidate> candidates = candidateRepository.findByActiveOrderByCreatedOnAsc(true);
        List<CandidateResponse> candidateResponseList = new ArrayList<>();
        for (Candidate candidate : candidates) {
            candidateResponseList.add(candidateEntityToCandidateResponse(candidate));
        }
        return candidateResponseList;
    }
    @Override
    public List<CandidateResponse> getListCandidatesNew(Integer pageNumber, Integer pageSize, String sortBy, String sortDir) {
        Sort sort = null;
        if (sortDir.equalsIgnoreCase("asc")) {
            sort = Sort.by(sortBy).ascending();
        } else {
            sort = Sort.by(sortBy).descending();
        }
        Pageable pagable = PageRequest.of(pageNumber, pageSize, sort);
        List<Candidate> candidates = this.candidateRepository.findAll(pagable).getContent();
        List<CandidateResponse> candidateResponseList = new ArrayList<>();
        for (Candidate candidate : candidates) {
            candidateResponseList.add(candidateEntityToCandidateResponse(candidate));
        }
        return candidateResponseList;
    }
    @Override
    public List<CandidateResponse> getAllCandidate(Integer pageNumber, String searchKey) {
        log.info("CandidateServiceImpl------------getAllCandidate-----------{}",pageNumber,searchKey);
        Pageable pageable = PageRequest.of(pageNumber, 7);
        if (searchKey != null || searchKey.equals("")) {
            List<Candidate> candidates = candidateRepository.findByActive(true, pageable);
            List<CandidateResponse> candidateResponseList = new ArrayList<>();
            if (candidates != null) {
                for (Candidate candidate : candidates) {
                    candidateResponseList.add(candidateEntityToCandidateResponse(candidate));
                }
                return candidateResponseList;
            }
        } else {
            List<Candidate> candidates = candidateRepository.findByActiveAndCandidateFirstNameIgnoreCaseStartingWithOrCandidateLastNameIgnoreCaseStartingWithOrCandidateEmailIgnoreCaseStartingWithOrCandidateContactNoIgnoreCaseStartingWithOrCandidateCurrentCompanyIgnoreCaseStartingWith(true, searchKey, searchKey, searchKey, searchKey, searchKey, pageable);
            List<CandidateResponse> candidateResponseList = new ArrayList<>();
            if (candidates != null) {
                for (Candidate candidate : candidates) {
                    candidateResponseList.add(candidateEntityToCandidateResponse(candidate));
                }
            }
            return candidateResponseList;
        }
        return new ArrayList<CandidateResponse>();
    }
    //Need to use list mapper
    CandidateResponse candidateEntityToCandidateResponse(Candidate candidate) {
        CandidateResponse candidateResponse = new CandidateResponse();
        candidateResponse.setCandidateId(candidate.getCandidateId());
        candidateResponse.setCandidateContactNo(candidate.getCandidateContactNo());
        candidateResponse.setCandidateCurrentCompany(candidate.getCandidateCurrentCompany());
        candidateResponse.setCandidateEmail(candidate.getCandidateEmail());
        candidateResponse.setCandidateExperience(candidate.getCandidateExperience());
        candidateResponse.setCandidateExpectedCtc(candidate.getCandidateExpectedCtc());
//        candidateResponse.setCandidateStatus(new CandidateStatusResponse(candidate.getCandidateStatus().getCandidateStatusId(), candidate.getCandidateStatus().getCandidateStatusName()));
        candidateResponse.setCandidateCurrentCtc(candidate.getCandidateCurrentCtc());
        candidateResponse.setCandidateNoticePeriod(candidate.getCandidateNoticePeriod());
        candidateResponse.setCandidateFirstName(candidate.getCandidateFirstName());
        candidateResponse.setCandidateLastName(candidate.getCandidateLastName());
        candidateResponse.setNegotiableNoticePeriod(candidate.isNegotiableNoticePeriod());
        candidateResponse.setParticipationInRecruitment(candidate.getParticipationInRecruitment());
        CandidateStatus candidateStatus=candidateStatusRepository.findByActiveAndCandidateStatusId(true,5);
//        candidateResponse.setCandidateSelected(rRCandidateMapperRepository.findByActiveAndCandidateIdAndCandidateStatus(true,candidate,candidateStatus));
        Integer selectedIn = rRCandidateMapperRepository.countByActiveAndCandidateIdAndCandidateStatus(true, candidate, candidateStatus);
        if(selectedIn==0)
            candidateResponse.setCandidateSelected(false);
        else
            candidateResponse.setCandidateSelected(true);
//        candidateResponse.setCandidateSelected(candidateSelected != null && candidateSelected);


        if (candidate.getFileId() != null) {
            candidateResponse.setFileId(new FileUploadeResponse(candidate.getFileId().getFileId(), candidate.getFileId().getFileName(),candidate.getFileId().getFileSize(),candidate.getFileId().getFileType(),candidate.getFileId().getFilePath()));
        }
        List<SkillResponse> skillResponseList = new ArrayList<>();
        List<SkillCandidateMapper> skillCandidateMappers = skillCandidateMapperRepository.findByActiveAndCandidate(true, candidate);

        for (SkillCandidateMapper skillCandidateMapper : skillCandidateMappers) {
            SkillResponse skillResponse = new SkillResponse();

            if (skillCandidateMapper.getSkillEntity() != null) {
                skillResponse.setId(skillCandidateMapper.getSkillEntity().getId());
                skillResponse.setSkillSet(skillCandidateMapper.getSkillEntity().getSkillSet());
                skillResponse.setSkillType(new SkillTypeResponse(skillCandidateMapper.getSkillEntity().getSkillType().getId(),skillCandidateMapper.getSkillEntity().getSkillType().getSkillTypeName()));
                skillResponseList.add(skillResponse);
            }
        }
        candidateResponse.setSkillsId(skillResponseList);
        return candidateResponse;
    }

    @Override
    public CandidateListResponse getListCandidatesOp(Integer pageNumber, Integer pageSize, String searchTerm) {
        log.info("CandidateServiceImpl--------------getListCandidatesOp-------{}",pageNumber,pageSize,searchTerm);
        List<Candidate> allCandidates;
        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        long totalCandidates;

        //Need to check this query
        if (!searchTerm.isEmpty()) {
            allCandidates = candidateRepository.findBySearchTerm(searchTerm, pageable);
            totalCandidates = candidateRepository.countByActiveAndSearchTerm(searchTerm) ;// Get the count from the list size
        } else {
            allCandidates = candidateRepository.findByActiveOrderByCandidateIdDesc(true, pageable).getContent();
            totalCandidates = candidateRepository.countByActive(true); // Get the total count separately
        }
        List<CandidateResponse> candidateResponseList = new ArrayList<>();
        for (Candidate candidate : allCandidates) {
            candidateResponseList.add(candidateEntityToCandidateResponse(candidate));
        }
        if(CollectionUtils.isEmpty(allCandidates)){
            return new CandidateListResponse(0l, new ArrayList<CandidateResponse>());
        }
        log.info("CandidateServiceImpl--------------getListCandidatesOp-------{}",pageNumber,pageSize,searchTerm);
        return new CandidateListResponse(totalCandidates, candidateResponseList);
    }

    @Override
    public Set<CandidateRrDTO> getListOfCandidatesBySkillType(Integer skillTypeId) {
        List<SkillCandidateMapper> candidatesWithSkill = skillCandidateMapperRepository
                .findByActiveAndSkillEntity_skillType_id(true, skillTypeId);

        if (candidatesWithSkill.isEmpty()) {
            System.out.println("No candidates found with the given skill type.");
            return Collections.emptySet();
        }

        return candidatesWithSkill.stream()
                .filter(skillCandidateMapper -> skillCandidateMapper.getCandidate().isActive())
                .map(skillCandidateMapper -> {
                    CandidateRrDTO response = new CandidateRrDTO();
                    response.setCandidateId(skillCandidateMapper.getCandidate().getCandidateId());
                    response.setCandidateFirstName(skillCandidateMapper.getCandidate().getCandidateFirstName());
                    response.setCandidateLastName(skillCandidateMapper.getCandidate().getCandidateLastName());
                    return response;
                })
                .collect(Collectors.toSet());
    }
}
