package com.hrms.demo.dto.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrms.demo.model.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.bytebuddy.asm.Advice;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RrResponse {
    private Integer rrId ;

    private Integer requiredCount ;

    private Integer experience;

    private OwnerResponse ownerId ;

    private List<SkillResponse> skillsId;
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate startDate ;
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate endDate ;
    private Company company;
    private RRStatus rrStatus;
    private FileUploade fileId ;
    private Integer rrAlertFlag;
}
