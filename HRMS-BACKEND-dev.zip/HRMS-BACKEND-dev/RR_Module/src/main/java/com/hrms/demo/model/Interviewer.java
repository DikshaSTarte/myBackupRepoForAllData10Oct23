package com.hrms.demo.model;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@Entity
@Table(name="interviewer")
@AllArgsConstructor
@NoArgsConstructor
public class Interviewer extends BaseEntity{
   /* @Id
    @GeneratedValue(strategy = GenerationType.AUTO)*/
   @Id
   @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "interviewer_generator")
   @SequenceGenerator(name = "interviewer_generator", sequenceName = "interviewer_SEQUENCE", initialValue = 4395, allocationSize = 1)
    @Column(name = "interviewerId")
    private Integer interviewerId;
    @Column(name = "interviewerFirstName")
    private String interviewerFirstName;
    @Column(name = "interviewerLastName")
    private String interviewerLastName;
    @Column(name = "interviewerExperience")
    private float interviewerExperience;
    @Column(name = "interviewerContactNo")
    private String interviewerContactNo;
   // @Column(name = "interviewerEmail",unique = true)
    @Column(name = "interviewerEmail")
    private String interviewerEmail;
    @JsonIgnore
    @JoinColumn(name = "userId")
    @ManyToOne
    private User userId;
}
