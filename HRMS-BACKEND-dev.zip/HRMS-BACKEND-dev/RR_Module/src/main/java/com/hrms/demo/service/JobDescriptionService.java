package com.hrms.demo.service;

import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

public interface JobDescriptionService {
    ResponseEntity<Object> uploadFile(MultipartFile file) throws IOException;

    ResponseEntity<Resource> downloadFile(@PathVariable Integer rrMasterId, HttpServletRequest request);
}
