package com.hrms.demo.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.persistence.*;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "user_candidate_mapper")
public class UserCandidateMapper extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer userCandidateMapperId;
    @ManyToOne
    @JoinColumn(name ="userId")
    private User userId;
    @ManyToOne
    @JoinColumn(name="candidateId")
    private Candidate candidateId;
}