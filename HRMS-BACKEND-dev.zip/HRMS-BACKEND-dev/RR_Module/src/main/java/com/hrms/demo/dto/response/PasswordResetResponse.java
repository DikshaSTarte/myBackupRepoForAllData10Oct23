package com.hrms.demo.dto.response;

public class PasswordResetResponse {
    private boolean success;
    private String message;

    public PasswordResetResponse(boolean success, String message) {
        this.success = success;
        this.message = message;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }
}
