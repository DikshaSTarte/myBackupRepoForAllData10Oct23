package com.hrms.demo.serviceImpl;

import com.hrms.demo.dto.response.CompanyResponse;
import com.hrms.demo.dto.response.DashboardCountDTO;
import com.hrms.demo.dto.response.RCResponse;
import com.hrms.demo.dto.response.RRStatusTrendsResponse;
import com.hrms.demo.model.RRMaster;
import com.hrms.demo.model.RRStatus;
import com.hrms.demo.repository.CompanyRepository;
import com.hrms.demo.repository.RRMasterRepository;
import com.hrms.demo.repository.RRStatusRepository;
import com.hrms.demo.service.RRCountService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Service
@Slf4j
public class RRDashboardServiceImpl implements RRCountService {
    @Autowired
    private RRStatusRepository rrStatusRepository;
    @Autowired
    private RRMasterRepository rrMasterRepository;
    @Autowired
    private CompanyRepository companyRepository;
    public RRStatusTrendsResponse getPreMonthTrend() {
        log.info("RRDashboardServiceImpl-----------------getPreMonthTrend-----{}");
        RRStatusTrendsResponse rrStatusTrendsResponse = new RRStatusTrendsResponse();
        RRMaster rrMaster = new RRMaster();

// Get the current month
// LocalDate currentMonth = rrStatusTrendsResponse.getMonth();
// LocalDate currentMonth = rrMasterRepository.findByEndDate(rrStatusTrendsResponse.getMonth()).getEndDate();
        LocalDate currentMonth = LocalDate.now();
// Get the previous month
        LocalDate previousMonth = currentMonth.minusMonths(1);
// Create a new RRStatusTrendsResponse object for the previous month
        RRStatusTrendsResponse preMonthTrend = new RRStatusTrendsResponse();
// Set the month to the previous month
        preMonthTrend.setMonth(previousMonth);

        RRStatus fulfilled = rrStatusRepository.findByActiveAndRrStatusName(true, "FULFILLED");
        RRStatus open = rrStatusRepository.findByActiveAndRrStatusName(true, "OPEN");
        RRStatus cancel = rrStatusRepository.findByActiveAndRrStatusName(true, "CANCEL");
        RRStatus hold = rrStatusRepository.findByActiveAndRrStatusName(true, "HOLD");
// Here, you need to retrieve the counts for each RRStatus for the previous month
// Replace the following lines with your logic to fetch the counts from your data source

        Integer preMonthFulfilled = rrMasterRepository.countByRrStatusAndStartDateBetween(fulfilled,previousMonth,currentMonth);
        Integer preMonthOpen = rrMasterRepository.countByRrStatusAndStartDateBetween(open,previousMonth,currentMonth);
        Integer preMonthCancel = rrMasterRepository.countByRrStatusAndStartDateBetween(cancel,previousMonth,currentMonth);
        Integer preMonthHold = rrMasterRepository.countByRrStatusAndStartDateBetween(hold,previousMonth,currentMonth);

        System.out.println("open_RR--->"+preMonthOpen);
        System.out.println("fulfilled_RR--->"+preMonthFulfilled);
        System.out.println("cancel_RR--->"+preMonthCancel);
        System.out.println("hold_RR--->"+preMonthHold);

// Set the counts for each RRStatus in the previous month
        preMonthTrend.setFulfilled(preMonthFulfilled);
        preMonthTrend.setOpen(preMonthOpen);
        preMonthTrend.setCancel(preMonthCancel);
        preMonthTrend.setHold(preMonthHold);
        return preMonthTrend;
    }
    @Override
    public List<RCResponse> getRCForCustomer() {
        log.info("RRDashboardServiceImpl-----------------getRCForCustomer-----{}");
        List<CompanyResponse> companies = new ArrayList<>();
        companies =  companyRepository.getCompanyIds();

        LocalDate sevenDays = LocalDate.now().minusDays(7);
        LocalDate thirtyDays = LocalDate.now().minusDays(30);
        List<DashboardCountDTO> greenCount = rrMasterRepository.findRrCountLessThanSevenDays(sevenDays);
        List<DashboardCountDTO> yellowCount = rrMasterRepository.findRrCountBetweenSevenAndThirtyDays(sevenDays,thirtyDays);
        List<DashboardCountDTO> redCount = rrMasterRepository.findRrCountGreaterThanThirtyDays(thirtyDays);

        Map<Integer, DashboardCountDTO> greenCountMap = new HashMap<>();
        Map<Integer, DashboardCountDTO> yellowCountMap = new HashMap<>();
        Map<Integer,DashboardCountDTO> redCountMap = new HashMap<>();

        List<RCResponse>  rcList = new ArrayList<>();
        redCount.forEach( red->{
            redCountMap.putIfAbsent(red.getCompanyId(), red);
        });

        greenCount.forEach(count ->{
            greenCountMap.putIfAbsent(count.getCompanyId(), count);
        });

        yellowCount.forEach(yellow ->{
            yellowCountMap.putIfAbsent(yellow.getCompanyId(), yellow);
        });

        companies.forEach(company ->{
            RCResponse response = new RCResponse();
            response.setCustomerId(company.getCompanyId());
            response.setCustomerName(company.getCompanyName());
            if(greenCountMap.get(company.getCompanyId()) != null && greenCountMap.get(company.getCompanyId()).getCompanyId() == company.getCompanyId().intValue()){
                response.setGreenCount(greenCountMap.get(company.getCompanyId()).getCount());
            }else{
                response.setGreenCount(0L);
            }
            if(yellowCountMap.get(company.getCompanyId()) != null && yellowCountMap.get(company.getCompanyId()).getCompanyId() == company.getCompanyId().intValue()){
                response.setYellowCount(yellowCountMap.get(company.getCompanyId()).getCount());
            }else{
                response.setYellowCount(0L);
            }
            if(redCountMap.get(company.getCompanyId()) != null && redCountMap.get(company.getCompanyId()).getCompanyId() == company.getCompanyId().intValue()){
                response.setRedCount(redCountMap.get(company.getCompanyId()).getCount());
            }else{
                response.setRedCount(0L);
            }
            rcList.add(response);
        });
        return rcList;
    }
}