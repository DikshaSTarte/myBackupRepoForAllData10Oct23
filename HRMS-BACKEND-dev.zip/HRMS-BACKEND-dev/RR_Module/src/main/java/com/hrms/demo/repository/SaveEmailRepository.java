package com.hrms.demo.repository;

import com.hrms.demo.model.SaveEmail;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SaveEmailRepository extends JpaRepository<SaveEmail, Integer> {
    List<SaveEmail> findByIsSendFalse();

}
