package com.hrms.demo.dto.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CompanyRequest {
    @NotBlank(message = "Company name must not be blank.")
    @Pattern(regexp = "^[a-zA-Z ]+$", message = "Company name can only contain letters and spaces.")
    private String companyName;
}
