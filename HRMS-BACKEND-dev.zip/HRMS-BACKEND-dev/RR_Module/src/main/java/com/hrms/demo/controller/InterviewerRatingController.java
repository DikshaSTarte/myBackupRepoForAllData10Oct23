package com.hrms.demo.controller;
import com.hrms.demo.dto.request.InterviewerRatingRequest;
import com.hrms.demo.dto.response.InterviewerRatingResponse;
import com.hrms.demo.service.InterviewerRatingService;
import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@Slf4j
@RestController
@RequestMapping("/api/v1/interviewerRating")
public class InterviewerRatingController {
    @Autowired
    private InterviewerRatingService interviewerRatingService;
    @PostMapping("/save")
    public InterviewerRatingResponse SaveIntvRatingData(@Valid @RequestBody InterviewerRatingRequest interviewerRatingRequest){
        log.info("InterviewerRatingController------SaveIntvRatingData--{}",interviewerRatingRequest);
        return interviewerRatingService.saveInterviewerRating(interviewerRatingRequest);

    }
    @DeleteMapping("/delete/{interviwerRatingId}")
    public ResponseEntity<Void> deleteInterviewerRatingData(@PathVariable Integer interviwerRatingId){
        interviewerRatingService.deleteInterviewerRatingById(interviwerRatingId);
        log.info("InterviewerRatingController------deleteInterviewerRatingData--{}",interviwerRatingId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/list")
    public List<InterviewerRatingResponse> getShowListInterviewerRating() {
        log.info("InterviewerRatingController------getShowListInterviewerRating--{}");
        return this.interviewerRatingService.getListInterviewerRating();
    }


    @GetMapping("/get/{interviwerRatingId}")
    public InterviewerRatingResponse getIntvRatingById(@PathVariable Integer interviwerRatingId){
        log.info("InterviewerRatingController------getIntvRatingById--{}",interviwerRatingId);
        return this.interviewerRatingService.getInterviewerRatingById(interviwerRatingId);
    }
    @PutMapping("/update/{interviwerRatingId}")
    public ResponseEntity<InterviewerRatingResponse> updateIntvRatingData(@Valid @PathVariable Integer interviwerRatingId ,@RequestBody InterviewerRatingRequest interviewerRatingRequest ){
        InterviewerRatingResponse interviewerRatingResponse=interviewerRatingService.updateInterviewerRating(interviwerRatingId,interviewerRatingRequest);
        if(interviewerRatingResponse!=null){
            log.info("InterviewerRatingController------updateIntvRatingData--{}",interviwerRatingId,interviewerRatingRequest);
            return ResponseEntity.ok(interviewerRatingResponse);
        }else {
            log.error("InterviewerRatingController------updateIntvRatingData--{}",interviewerRatingRequest);
            return ResponseEntity.notFound().build();
        }
    }
}
