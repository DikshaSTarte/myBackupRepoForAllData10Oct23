package com.hrms.demo.dto.response;

import com.hrms.demo.model.Company;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class CompanyListResponse {
    private long totalCompanys;
    private List<CompanyResponse> companyList;

    public CompanyListResponse(long totalCompanys, List<CompanyResponse> companyList) {
        this.totalCompanys = totalCompanys;
        this.companyList = companyList;
    }
}
