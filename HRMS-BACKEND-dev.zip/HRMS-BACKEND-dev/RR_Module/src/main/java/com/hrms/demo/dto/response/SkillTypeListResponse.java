package com.hrms.demo.dto.response;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class SkillTypeListResponse {
    private long totalSkillTypes;
    private List<SkillTypeResponse> skillTypeList;

    public SkillTypeListResponse(long totalSkillTypes, List<SkillTypeResponse> skillTypeList) {
        this.totalSkillTypes = totalSkillTypes;
        this.skillTypeList = skillTypeList;
    }


}
