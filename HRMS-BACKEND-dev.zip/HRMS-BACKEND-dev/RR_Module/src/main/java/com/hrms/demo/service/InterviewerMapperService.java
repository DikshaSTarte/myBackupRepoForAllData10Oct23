package com.hrms.demo.service;

import com.hrms.demo.dto.request.CandidateFeedbackFormRequest;
import com.hrms.demo.dto.request.InterviewerCandidateRequest;
import com.hrms.demo.dto.request.InterviewerMapperRequest;
import com.hrms.demo.dto.request.InterviewerRequest;
import com.hrms.demo.dto.response.*;
import com.hrms.demo.model.InterviewerMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.ArrayList;
import java.util.List;
public interface InterviewerMapperService {
    InterviewerMapperResponse saveInterviewerFeedbackStatus(InterviewerMapperRequest interviewerMapperRequest);
    List<InterviewerMapperResponse> getAllFeedbacks();
    List<InterviewerMapperResponse> getAllFeedbacksByRrId(Integer rrId);

    InterviewerCandidateResponse saveCandidatesForInterviewer(InterviewerCandidateRequest interviewerCandidateRequest);

    List<InterviewerMapperResponse> getCandidatesByInterviewerId(Integer interviewerId);

    List<InterviewerCandidateResponse> getAllCandidatesForInterviewer();

    InterviewerFeedbackOnCandidateResponse saveFeedbackForCandidate(CandidateFeedbackFormRequest feedbackFormRequest);

    void deleteCandidateByInterviewerCandidateMapperId(Integer interviewerCandidateMapperId);
    InterviewerListResponse getListInterviewerMappersPg(Integer pageNumber, Integer pageSize, String searchTerm);

   // InterviewerMapperListResponse getCandidatesByInterviewerIds(Integer interviewerId, Integer pageNumber, Integer pageSize, String searchTerm);


   InterviewerMapperFeedbacksResponse getAllFeedbacksOp(Integer pageNumber, Integer pageSize, String searchTerm);



  InterviewerMapperFeedbacksListByRrIdResponse getAllFeedbacksListByRrOp(Integer rrId, Integer pageNumber, Integer pageSize, String searchTerm);

}
