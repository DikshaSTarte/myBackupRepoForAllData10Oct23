package com.hrms.demo.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class CandidateListResponse {
    private long totalCandidates;
    private List<CandidateResponse> candidateList;

    public CandidateListResponse(long totalCandidates, List<CandidateResponse> candidateList) {
        this.totalCandidates = totalCandidates;
        this.candidateList = candidateList;
    }

}