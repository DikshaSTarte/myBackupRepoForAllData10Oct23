package com.hrms.demo.dto.request;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InterviewerRatingRequest {

    @NotNull(message = "Rate score cannot be null")
    @Min(value = 1, message = "Rate score cannot be less than 1")
    @Max(value = 5, message = "Rate score cannot be greater than 5")
    private Integer rateScore;
}
