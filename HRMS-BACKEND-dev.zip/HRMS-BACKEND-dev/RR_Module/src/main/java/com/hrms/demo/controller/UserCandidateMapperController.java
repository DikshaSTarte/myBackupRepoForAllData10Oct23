package com.hrms.demo.controller;

import com.hrms.demo.dto.request.CandidateForUserRequest;
import com.hrms.demo.dto.request.RRForUserRequest;
import com.hrms.demo.dto.response.UserCandidateMapperResponse;
import com.hrms.demo.dto.response.UserRrMapperResponse;
import com.hrms.demo.model.Candidate;
import com.hrms.demo.model.UserCandidateMapper;
import com.hrms.demo.model.UserRRMapper;
import com.hrms.demo.service.UserCandidateMapperService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
@Slf4j
@RestController
@RequestMapping("/api/v1/userCandidateMapper")
public class UserCandidateMapperController {
    @Autowired
    private UserCandidateMapperService userCandidateMapperService;
    @GetMapping("/getCandidate/{userId}")
    public List<UserCandidateMapperResponse> getCandidateListByUserId(@PathVariable Integer userId){
        log.info("UserCandidateMapperController-------------getCandidateListByUserId---------{}",userId);
        return this.userCandidateMapperService.getCandidateUserId(userId);
    }
    @PostMapping("/save")
    public UserCandidateMapper SaveCandidateData(@Valid @RequestBody CandidateForUserRequest userRequest){
        log.info("UserCandidateMapperController-------------SaveCandidateData-----------{}",userRequest);
        return userCandidateMapperService.saveCandidateForUser(userRequest);
    }
}