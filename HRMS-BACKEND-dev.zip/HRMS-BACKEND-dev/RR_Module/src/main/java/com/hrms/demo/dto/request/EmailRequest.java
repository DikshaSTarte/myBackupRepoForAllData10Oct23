package com.hrms.demo.dto.request;

import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EmailRequest {

    private LocalDateTime interviewDateTime;
    private Integer interviewerId;
    private Integer studentId;
    private String roleToHireFor;
    private Integer rrId;
    private Integer companyId;
}
