package com.hrms.demo.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.File;

@Component
public class DirectoryInitializer {
    @Value("${upload.dir.jobdescription}")
    private String uploadDir;

    @Value("${upload.dir.resume}")
    private String uploadresume;


    @PostConstruct
    public void init() {
        File directory = new File(uploadDir);
        if (!directory.exists()) {
            directory.mkdirs();
        }
        File directory1 = new File(uploadresume);
        if (!directory1.exists()) {
            directory1.mkdirs();
        }
    }
}
