package com.hrms.demo.serviceImpl;

import com.hrms.demo.model.FileUploade;
import com.hrms.demo.model.RRMaster;
import com.hrms.demo.repository.FileUploadeRepository;
import com.hrms.demo.repository.RRMasterRepository;
import com.hrms.demo.service.JobDescriptionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
@Slf4j
@Service
public class JobDescriptionServiceImpl implements JobDescriptionService {

    @Autowired
    private FileUploadeRepository fileUploadeRepository;
    @Autowired
    private RRMasterRepository rrMasterRepository;

    @Value("${upload.dir.jobdescription}")
    private String uploadDir;


    @Override
    public ResponseEntity<Object> uploadFile(MultipartFile file) throws IOException {
        log.info("JobDescriptionServiceImpl--------------uploadFile------------{}",file);
        if (!file.getContentType().equalsIgnoreCase("application/pdf")) {
            // Return an error response if the file is not a PDF
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("message", "Only PDF files are allowed");
            log.error("JobDescriptionServiceImpl--------------uploadFile------------{}",file,"Only PDF files are allowed");
            return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
        }

        // Proceed with file upload if it is a PDF
        File myfile = new File(uploadDir + "/" + file.getOriginalFilename());
        myfile.createNewFile();
        FileOutputStream fos = new FileOutputStream(myfile);
        fos.write(file.getBytes());
        fos.close();

        FileUploade fileUpload = new FileUploade();
        fileUpload.setFilePath(uploadDir + "/" + file.getOriginalFilename());
        fileUpload.setFileName(file.getOriginalFilename());
        fileUpload.setFileSize(file.getSize());
        fileUpload.setFileType(file.getContentType());

        FileUploade savedFile = fileUploadeRepository.save(fileUpload);
        Integer fileId = savedFile.getFileId();

        Map<String, Object> response = new HashMap<>();
        response.put("message", "File uploaded successfully");
        response.put("fileId", fileId);

        log.info("JobDescriptionServiceImpl--------------uploadFile------------{}",file);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

@Override
    public ResponseEntity<Resource> downloadFile(@PathVariable Integer rrMasterId, HttpServletRequest request) {
        log.info("JobDescriptionServiceImpl----------downloadFile-----------{]",rrMasterId,request);
        RRMaster rrMaster1 = rrMasterRepository.findByActiveAndRrMasterId(true, rrMasterId);
        if (rrMaster1 != null && rrMaster1.getFileId() != null) {
            String fileName = rrMaster1.getFileId().getFileName();
            // Specify the directory where the files are stored
            //  String uploadDir = "jobdescription/";
            //String uploadDir = "C:\\Users\\MFSPC004\\Downloads\\UploadFileHrmsFolder\\";
            String filePath = uploadDir + "/" + fileName;

            // Load the file as a resource
            Resource resource = new FileSystemResource(filePath);

            if (resource.exists()) {
                // Determine the file's content type
                String contentType = null;
                try {
                    contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
                } catch (IOException e) {
                    // Handle the exception
                    log.error("JobDescriptionServiceImpl----------downloadFile-----------{}",e);
                }

                // Set appropriate headers for the file download
                HttpHeaders headers = new HttpHeaders();
                headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName);
                headers.add(HttpHeaders.CONTENT_TYPE, contentType != null ? contentType : MediaType.APPLICATION_OCTET_STREAM_VALUE);

                return ResponseEntity.ok()
                        .headers(headers)
                        .body(resource);
            }
        }
    log.info("JobDescriptionServiceImpl----------downloadFile-----------{]",rrMasterId,request);
        return ResponseEntity.notFound().build();

    }

}
