package com.hrms.demo.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalTime;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "template_data")
public class TemplateCandidateData extends BaseEntity{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer templateId;
    private String templateName;
    private String templateDetails;
    //html template for candidate and interviewer
    private String template;
    private String candidateName ;
    private String interviewDate ;
    private String interviewTime;
    private String candidateEmail;
    private String hrName;
    private String hrEmail;
}
