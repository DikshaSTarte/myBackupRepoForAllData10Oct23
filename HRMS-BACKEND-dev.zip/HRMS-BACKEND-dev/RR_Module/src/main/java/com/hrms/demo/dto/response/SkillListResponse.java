package com.hrms.demo.dto.response;

import java.util.List;

public class SkillListResponse {
    private long totalSkills;
    private List<SkillResponse> skillList;

    public SkillListResponse(long totalSkills, List<SkillResponse> skillList) {
        this.totalSkills = totalSkills;
        this.skillList = skillList;
    }
}
