package com.hrms.demo.repository;

import com.hrms.demo.dto.response.CandidateResponse;
import com.hrms.demo.dto.response.DropDownDTO;
import com.hrms.demo.model.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.geo.GeoResult;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;

import java.time.LocalDate;
import java.util.List;
public interface InterviewerCandidateRepository extends JpaRepository<InterviewerCandidateMapper,Integer> {
    public InterviewerCandidateMapper findByActiveAndInterviewerId(boolean active,Integer interviewerId);
    public List<InterviewerCandidateMapper> findByActiveAndInterviewerId_InterviewerId(boolean b,Integer interviewerId);
    public List<InterviewerCandidateMapper> findByActive(boolean b);
    Candidate findBycandidateId(Candidate candidateId);
    List<InterviewerCandidateMapper> findByRrIdAndCandidateId(RRMaster rrMaster,Candidate candidate);
   // Integer countByCandidateId_CandidateStatusAndDateBetween(CandidateStatus onHold, LocalDate startDate, LocalDate endDate);
    List<InterviewerCandidateMapper> findByActiveAndRrIdAndCandidateId(boolean b, RRMaster rrId, Candidate candidateId);

    List<InterviewerCandidateMapper> findByActiveAndRrId(boolean b, RRMaster rrId);



List<InterviewerCandidateMapper>findByActiveAndRrIdAndCandidateIdCandidateFirstNameStartingWithOrCandidateIdCandidateLastNameStartingWithOrInterviewerIdInterviewerFirstNameStartingWithOrInterviewerIdInterviewerLastNameStartingWith(
        boolean b, RRMaster rrId,
        String candidateFirstName,
        String candidateLastName,
        String interviewerFirstName,
        String interviewerLastName
        );

    List<InterviewerCandidateMapper>findByActiveAndRrId_RrMasterIdAndActiveAndCandidateId_CandidateFirstNameStartingWithAndActiveAndCandidateId_CandidateLastNameStartingWithAndActiveAndInterviewerId_InterviewerFirstNameStartingWithAndActiveAndInterviewerId_InterviewerLastNameStartingWith(
            boolean b, Integer rrId,
            boolean b1,
            String candidateFirstName,
            boolean b2,
            String candidateLastName,
            boolean b3,
            String interviewerFirstName,
            boolean b4,
            String interviewerLastName
    );

   


    @Query("SELECT icm FROM InterviewerCandidateMapper icm " +
            "WHERE " +
            "icm.active = :active " +
            "AND icm.rrId = :rrMaster " +
            "AND (" +
            "icm.candidateId.candidateFirstName LIKE CONCAT(:searchTerm, '%') " +
            "OR icm.candidateId.candidateLastName LIKE CONCAT(:searchTerm, '%') " +
            "OR CONCAT(LOWER(icm.candidateId.candidateFirstName), ' ', LOWER(icm.candidateId.candidateLastName)) " +
            "LIKE LOWER(CONCAT(:searchTerm, '%')) " +
            "OR icm.interviewerId.interviewerFirstName LIKE CONCAT(:searchTerm, '%') " +
            "OR icm.interviewerId.interviewerLastName LIKE CONCAT(:searchTerm, '%') " +
            "OR CONCAT(LOWER(icm.interviewerId.interviewerFirstName), ' ', LOWER(icm.interviewerId.interviewerLastName)) " +
            "LIKE LOWER(CONCAT(:searchTerm, '%'))" +
            ")")
    List<InterviewerCandidateMapper> findBySearchTerm(
            @Param("active") boolean active,
            @Param("rrMaster") RRMaster rrMaster,
            @Param("searchTerm") String searchTerm
    );



    // List<InterviewerCandidateMapper> findByActiveAndRrIdAndCandidateId(boolean b, RRMaster rrId, Candidate candidateId);


    //List<InterviewerCandidateMapper> findByActiveAndRrIdAndCandidateIdOrderByInterviewerCandidateMapperDesc(boolean b, RRMaster rrId, Candidate candidateId);
    List<InterviewerCandidateMapper> findByActiveAndRrIdAndCandidateIdOrderByInterviewerCandidateMapperIdDesc(boolean active, RRMaster rrId, Candidate candidateId);



    List<InterviewerCandidateMapper> findByActiveAndRrIdAndCandidateIdAndInterviewerId_InterviewerFirstNameIsNotNull(
            boolean active, RRMaster rrId, Candidate candidateId
    );



    Page<InterviewerCandidateMapper> findByActiveAndInterviewerId_InterviewerIdOrderByInterviewerCandidateMapperIdDesc(boolean active,Integer interviewerId,Pageable pageable);

    @Query("SELECT icm FROM InterviewerCandidateMapper icm WHERE icm.active=true AND " +
            "(icm.interviewerId.interviewerId = :interviewerId) AND " +
            "((LOWER(icm.candidateId.candidateFirstName) LIKE LOWER(CONCAT(:searchTerm,'%'))) OR " +
            "(LOWER(icm.candidateId.candidateLastName) LIKE LOWER(CONCAT(:searchTerm,'%'))) OR " +
            "(LOWER(icm.candidateId.candidateEmail) LIKE LOWER(CONCAT(:searchTerm,'%'))))")
    Page<InterviewerCandidateMapper> findByInterviewerIdAndSearchTerm(@Param("interviewerId") Integer interviewerId, @Param("searchTerm") String searchTerm, Pageable pageable);

    Page<InterviewerCandidateMapper> findByInterviewerIdOrCandidateId_CandidateFirstNameStartsWithIgnoreCaseOrCandidateId_CandidateLastNameStartsWithIgnoreCaseOrCandidateId_CandidateEmailStartsWithIgnoreCase(Interviewer byInterviewerId, String searchTerm, String searchTerm1, String searchTerm2, Pageable pageable);
    Page<InterviewerCandidateMapper> findByInterviewerIdAndCandidateId_CandidateFirstNameStartsWithIgnoreCaseOrCandidateId_CandidateLastNameStartsWithIgnoreCaseOrCandidateId_CandidateEmailStartsWithIgnoreCase(Interviewer byInterviewerId, String searchTerm, String searchTerm1, String searchTerm2, Pageable pageable);

    @Query("SELECT new com.hrms.demo.dto.response.DropDownDTO(COUNT(im.interviewerMapperId), cs.candidateStatusName) FROM InterviewerMapper im " +
            "LEFT JOIN im.interviewerCandidateMapper icm " +
            "INNER JOIN im.candidateStatus cs " +
            "WHERE im.active=true " +
            "AND cs.candidateStatusName IN (:statuses) " +
            "AND (icm.date BETWEEN :startDate and :endDate) " +
            "GROUP BY cs.candidateStatusId " +
            "")
    List<DropDownDTO<Long, String>> getCandidateStatusAndDate(List<String> statuses, LocalDate startDate, LocalDate endDate);

    Page<InterviewerCandidateMapper> findByActiveAndRrIdOrderByInterviewerCandidateMapperIdDesc(boolean b, RRMaster rrId, Pageable pageable);

    Page<InterviewerCandidateMapper> findByActiveAndRrId_RrMasterIdOrderByInterviewerCandidateMapperIdDesc(boolean b, Integer rrId, Pageable pageable);
}
