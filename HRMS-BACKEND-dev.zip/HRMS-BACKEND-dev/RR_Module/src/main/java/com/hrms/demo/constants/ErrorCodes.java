package com.hrms.demo.constants;

public class ErrorCodes {
    public static final String USER_NAME_NOT_FOUND = "Username does not exist";
    public static final String ERROR = "error";
    public static final String LOGIN_FAILED = "Login failed";
    public static final String CANDIDATE_ALREADY_EXISTS = "Candidate Email already exists.";
    public static final String RR_ALREADY_EXIST = "RR is already present.";
}
