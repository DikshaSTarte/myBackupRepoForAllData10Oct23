package com.hrms.demo.globleexception;

public class SkillAlreadyExistForSKillTypeException extends RuntimeException {
    public SkillAlreadyExistForSKillTypeException(String message){
        super(message);
    }
}
