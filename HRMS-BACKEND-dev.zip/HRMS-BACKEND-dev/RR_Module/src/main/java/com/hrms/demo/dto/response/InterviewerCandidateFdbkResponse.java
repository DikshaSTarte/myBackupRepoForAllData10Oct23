package com.hrms.demo.dto.response;

import com.hrms.demo.model.Candidate;
import com.hrms.demo.model.Interviewer;
import com.hrms.demo.model.RRMaster;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InterviewerCandidateFdbkResponse {
    private RRMaster rrId;

    private InterviewerResponse interviewerId;

    private List<CandidateResponse> candidateId;

    private Date timeForInterview ;

}
