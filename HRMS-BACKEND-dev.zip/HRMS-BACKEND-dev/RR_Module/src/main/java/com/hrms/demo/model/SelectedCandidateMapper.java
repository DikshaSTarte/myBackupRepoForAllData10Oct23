package com.hrms.demo.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.persistence.*;
@Getter
@Setter
@Entity
@Table(name="selectedCandidateMapper")
@AllArgsConstructor
@NoArgsConstructor
public class SelectedCandidateMapper extends BaseEntity{
   /* @Id
    @GeneratedValue(strategy = GenerationType.AUTO)*/
   @Id
   @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "selectedCandidateMapper_generator")
   @SequenceGenerator(name = "selectedCandidateMapper_generator", sequenceName = "selectedCandidateMapper_SEQUENCE", initialValue = 4058, allocationSize = 1)
    private Integer selectedCandidateId;
    @ManyToOne
    @JoinColumn(name = "rrId")
    private RRMaster rrId;
    @ManyToOne
    @JoinColumn(name = "candidateId")
    private Candidate candidateId;
}