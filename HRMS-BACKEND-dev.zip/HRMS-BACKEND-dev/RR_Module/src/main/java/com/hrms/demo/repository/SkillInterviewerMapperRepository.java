package com.hrms.demo.repository;

import com.hrms.demo.model.Interviewer;
import com.hrms.demo.model.SkillInterviewerMapper;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;
@Repository
public interface SkillInterviewerMapperRepository extends JpaRepository<SkillInterviewerMapper,Integer> {
   public List<SkillInterviewerMapper> findByActiveAndInterviewer(boolean b,Interviewer interviewer);



   void deleteByInterviewer(Interviewer interviewer);

   List<SkillInterviewerMapper> findByInterviewer(Interviewer interviewer);
}
