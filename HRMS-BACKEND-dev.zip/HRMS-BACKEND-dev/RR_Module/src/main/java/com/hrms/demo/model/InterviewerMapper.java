package com.hrms.demo.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name="interviewerMapper")
public class InterviewerMapper extends BaseEntity{
   /* @Id
    @GeneratedValue(strategy = GenerationType.AUTO)*/
   @Id
   @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "interviewerMapper_generator")
   @SequenceGenerator(name = "interviewerMapper_generator", sequenceName = "interviewerMapper_SEQUENCE", initialValue = 7499, allocationSize = 1)
    @Column(name = "interviewerMapperId")
    private Integer interviewerMapperId;
    @ManyToOne
    @JoinColumn(name = "rrMasterId")
    private RRMaster rrId;
    @ManyToOne
    @JoinColumn(name = "candidateId")
    private Candidate candidateId;
    @ManyToOne
    @JoinColumn(name = "interviewerId")
    private Interviewer interviewerId;
    private String feedBackDescription;
    private boolean isFeedbackGiven ;
    private Integer technicalRating;
    private Integer behaviourRating;
    private Integer softSkillRating;
    private Integer overallRating;
    @ManyToOne
    @JoinColumn(name = "candidateStatusId")
    private CandidateStatus candidateStatus;

    @ManyToOne
    @JoinColumn(name = "interviewer_candidate_mapper_interviewer_candidate_mapper_id")
    private  InterviewerCandidateMapper interviewerCandidateMapper;

}