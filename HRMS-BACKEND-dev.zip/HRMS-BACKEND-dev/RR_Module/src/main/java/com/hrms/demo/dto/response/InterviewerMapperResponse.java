package com.hrms.demo.dto.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrms.demo.model.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InterviewerMapperResponse {
    private Integer interviewerMapperId;
    private RRMaster rrId;
    private Candidate candidateId;
    private Interviewer interviewerId;
    private String feedBackDescription;
    private Integer technicalRating;
    private Integer behaviourRating;
    private Integer softskillRating;
    private Integer overallRating;
    private CandidateStatus candidateStatus;
    private  boolean isFeedbackGiven ;
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate interviewDate;
    private LocalTime interviewTime;

}
