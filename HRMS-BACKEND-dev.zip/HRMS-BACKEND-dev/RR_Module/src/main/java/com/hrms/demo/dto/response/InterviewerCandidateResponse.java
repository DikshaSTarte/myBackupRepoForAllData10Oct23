package com.hrms.demo.dto.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrms.demo.model.Candidate;
import com.hrms.demo.model.Interviewer;
import com.hrms.demo.model.RRMaster;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class InterviewerCandidateResponse {

    private Integer  interviewerCandidateMapperId;
    private RRMaster rrId;
    private Interviewer interviewerId;
    private Candidate candidateId;
    private LocalTime interviewTime ;
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate interviewDate;
    private boolean feedbackGiven;
}
