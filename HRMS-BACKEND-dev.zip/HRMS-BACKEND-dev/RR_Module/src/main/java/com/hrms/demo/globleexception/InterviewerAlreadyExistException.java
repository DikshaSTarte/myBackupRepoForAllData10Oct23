package com.hrms.demo.globleexception;

public class InterviewerAlreadyExistException extends RuntimeException {
    public InterviewerAlreadyExistException(String s) {
        super(s);

    }
}
