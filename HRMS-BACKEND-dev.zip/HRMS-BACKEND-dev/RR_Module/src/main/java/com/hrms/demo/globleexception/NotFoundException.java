package com.hrms.demo.globleexception;

public class NotFoundException extends RuntimeException {
    public NotFoundException(String s) {
    }
}
