package com.hrms.demo.dto.response;

import com.hrms.demo.model.UserType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OwnerResponse {
    private Integer userId ;

    private UserType userType;

    private String userFirstName;

    private String userLastName;

    private String userContact ;
    private String userEmailId ;
}
