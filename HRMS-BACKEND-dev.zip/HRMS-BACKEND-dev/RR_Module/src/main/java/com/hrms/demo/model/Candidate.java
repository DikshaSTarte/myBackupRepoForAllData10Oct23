package com.hrms.demo.model;

import javax.persistence.*;

import lombok.*;

@Getter
@Setter
@Entity
@Table(name = "candidate")
@AllArgsConstructor
@NoArgsConstructor
public class Candidate extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "candidate_generator")
    @SequenceGenerator(name = "candidate_generator", sequenceName = "candidate_SEQUENCE", initialValue = 4404, allocationSize = 1)
    @Column(name = "candidateId")
    private Integer candidateId;

    @Column(name = "candidateFirstName")
    private String candidateFirstName;

    @Column(name = "candidateLastName")
    private String candidateLastName;

    @Column(name = "candidateContactNo")
    private String candidateContactNo;

    @Column(name = "candidateEmail")
    private String candidateEmail;

    @Column(name = "candidateExperience")
    private float candidateExperience;

    @Column(name = "candidateCurrentCompany")
    private String candidateCurrentCompany;

    @Column(name = "candidateCurrentCtc")
    private float candidateCurrentCtc;

    @Column(name = "candidateExpectedCtc")
    private float candidateExpectedCtc;

    @Column(name = "candidateNoticePeriod")
    private float candidateNoticePeriod;

//    @ManyToOne
//    @JoinColumn(name = "candidateStatusId")
//    private CandidateStatus candidateStatus;

    @ManyToOne
    @JoinColumn(name = "fileId")
    private FileUploade fileId;

    @Column(name = "negotiableNoticePeriod", nullable = false)
    private boolean negotiableNoticePeriod;


    @Column(name = "participationInRecruitment",nullable = false, columnDefinition = "int default 0" )
    private int participationInRecruitment=0;

}
