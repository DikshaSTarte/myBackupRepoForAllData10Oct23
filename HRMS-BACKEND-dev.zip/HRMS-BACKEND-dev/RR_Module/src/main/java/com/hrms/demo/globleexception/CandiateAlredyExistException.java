package com.hrms.demo.globleexception;

public class CandiateAlredyExistException extends RuntimeException {
    public CandiateAlredyExistException(String s) {
        super(s);
    }
}
