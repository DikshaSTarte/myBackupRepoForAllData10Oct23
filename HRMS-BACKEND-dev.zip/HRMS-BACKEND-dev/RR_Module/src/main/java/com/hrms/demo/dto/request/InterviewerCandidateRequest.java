package com.hrms.demo.dto.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class InterviewerCandidateRequest {
    private Integer interviewerId;

    private Integer rrId;

    private Integer candidateId;

    private LocalTime interviewTime;

    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate interviewDate;
    private boolean feedbackGiven;
}
