package com.hrms.demo.globleexception;

public class CompanyAlreadyExistsException extends Throwable {
    public CompanyAlreadyExistsException(String s) {
        super(s);
    }
}
