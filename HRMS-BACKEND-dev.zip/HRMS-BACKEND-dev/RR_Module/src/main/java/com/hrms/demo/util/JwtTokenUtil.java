package com.hrms.demo.util;

import com.hrms.demo.model.Interviewer;
import com.hrms.demo.model.User;
import com.hrms.demo.repository.InterviewerRepository;
import com.hrms.demo.repository.UserRepository;
import io.jsonwebtoken.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import java.security.SignatureException;
import java.util.Date;
@Component
@Slf4j
public class JwtTokenUtil {
    @Autowired
    private InterviewerRepository interviewerRepository;
    @Autowired
    private UserRepository userRepository;
    private static final long EXPIRE_DURATION = 24 * 60 * 60 * 1000; // 24 hour
    @Value("${app.jwt.secret}")
    private String SECRET_KEY = "482B4D6251655468576D5A7134743777397A24432646294A404E635266556A58";

    public String generateAccessToken(User user) {

        Interviewer interviewer = interviewerRepository.findByActiveAndUserId(true, user);

        User id =  userRepository.findByActiveAndUserId(user.isActive(), user.getUserId());
        Integer interviewerID = null;
        if(interviewer!=null){
            interviewerID =interviewer.getInterviewerId();
        }

        return Jwts.builder()
                .setSubject(user.getUsername())
                .claim("USER_TYPE", user.getUserType().getUserTypeName())
                .claim("USER_NAME",user.getUserFirstName()+" "+user.getUserLastName())
//                .claim("ID", user.getUserId())
                .claim("ID", id)
                .claim("INTERVIEWER_ID",interviewerID)
                .claim("USER_ID",user.getUserId())
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRE_DURATION))
                .signWith(SignatureAlgorithm.HS256, getSignInKey()).compact();
    }


    public String generateRefreshToken(String user) {

        return Jwts.builder()
                .setSubject(user)
                .setIssuedAt(new Date())
                .signWith(SignatureAlgorithm.HS256, getSignInKey())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRE_DURATION + 1000))
                .compact();


    }

    public boolean validateAccessToken(String token) {
        try {
            Jwts.parser().setSigningKey(getSignInKey()).parseClaimsJws(token);
            return true;
        } catch (ExpiredJwtException ex) {
            log.error("JWT expired", ex.getMessage());
        } catch (IllegalArgumentException ex) {
            log.error("Token is null, empty or only whitespace", ex.getMessage());
        } catch (MalformedJwtException ex) {
            log.error("JWT is invalid", ex);
        } catch (UnsupportedJwtException ex) {
            log.error("JWT is not supported", ex);
        }

        return false;
    }

    public String getSubject(String token) {
        return parseClaims(token).getSubject();
    }

// private Key getSignInKey() {
// byte[] keyBytes = Decoders.BASE64.decode(SECRET_KEY);
// return Keys.hmacShaKeyFor(keyBytes);
// }

    private String getSignInKey() {
// byte[] keyBytes = Decoders.BASE64.decode(SECRET_KEY);
// return Keys.hmacShaKeyFor(keyBytes);
        return SECRET_KEY;
    }

    public Claims parseClaims(String token) {
        return Jwts.parser()
                .setSigningKey(SECRET_KEY)
                .parseClaimsJws(token)
                .getBody();
    }
}