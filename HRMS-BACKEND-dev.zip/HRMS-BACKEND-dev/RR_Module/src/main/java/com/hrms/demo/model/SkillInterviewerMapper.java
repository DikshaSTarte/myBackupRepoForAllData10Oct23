package com.hrms.demo.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.persistence.*;
@Getter
@Setter
@Entity
@Table(name="skillInterviewerMapper")
@AllArgsConstructor
@NoArgsConstructor
public class SkillInterviewerMapper extends BaseEntity{
  /*  @Id
    @GeneratedValue(strategy = GenerationType.AUTO)*/
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "skillInterviewerMapper_generator")
    @SequenceGenerator(name = "skillInterviewerMapper_generator", sequenceName = "skillInterviewerMapper_SEQUENCE", initialValue = 4397, allocationSize = 1)
    @Column(name = "skillInterviewerMapperId")
    private Integer skillInterviewerMapperId;

    @ManyToOne
    @JoinColumn(name = "skills_id")
    private SkillEntity skillEntity;

    @ManyToOne
    @JoinColumn(name = "interviewerId")
    private Interviewer interviewer;
}
