package com.hrms.demo.mapper;

import com.hrms.demo.dto.response.CompanyResponse;
import com.hrms.demo.model.Company;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class CompanyMapper {
    @Autowired
    private ModelMapper modelMapper;

    public CompanyResponse companyMapper(Company company){
        CompanyResponse companyResponse = new CompanyResponse();
        companyResponse = modelMapper.map(company,CompanyResponse.class);
        return companyResponse;
    }
    public List<CompanyResponse> companyListMapper(List<Company> companies){
        List<CompanyResponse> companyResponseList = companies
                .stream()
                .map(test->modelMapper.map(test , CompanyResponse.class))
                .collect(Collectors.toList());
        return  companyResponseList;
    }
}
