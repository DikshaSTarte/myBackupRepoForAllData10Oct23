package com.hrms.demo.globleexception;

public class NoDataFoundException extends RuntimeException {
    public NoDataFoundException(String s) {
        super(s);
    }
}
