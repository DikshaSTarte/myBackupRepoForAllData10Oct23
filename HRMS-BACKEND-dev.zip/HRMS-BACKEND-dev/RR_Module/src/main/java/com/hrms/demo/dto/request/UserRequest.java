package com.hrms.demo.dto.request;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import lombok.*;
import org.hibernate.validator.constraints.Range;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserRequest {

   @NotNull
   @Range(min = 1, max = 4, message = "UserType  must be between 1 and 4.")
    private Integer userType;
 //@NotBlank(message = "Username cannot be blank")
    private String username;

 //@NotBlank(message = "Password cannot be blank")
 private String password;

 @NotBlank(message = "userFirstName cannot be blank")
 private String userFirstName;
 @NotBlank(message = "userLastName cannot be blank")
 private String userLastName;

 @Pattern(regexp = "\\d{10}", message = "Contact number should be 10 digits")
 private String userContact;


 @Email(message = "user email is not valid.")
 private String userEmailId;
 private String newPassword;
 private String conformPassword;
 private String otp;
}
