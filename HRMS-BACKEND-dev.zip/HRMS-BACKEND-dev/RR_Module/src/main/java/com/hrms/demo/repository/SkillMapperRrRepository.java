package com.hrms.demo.repository;

import com.hrms.demo.dto.response.SkillTypeForRrResponse;
import com.hrms.demo.model.RRMaster;
import com.hrms.demo.model.RRStatus;
import com.hrms.demo.model.SkillMapperRR;
import com.hrms.demo.model.SkillTypeEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
public interface SkillMapperRrRepository extends JpaRepository<SkillMapperRR,Integer> {
    SkillMapperRR findByActive(boolean b);

    List<SkillMapperRR> findByRrMasterId(RRMaster rrMasterId);

    Integer countByActiveAndRrMasterId_rrStatusAndRrMasterId_ActiveAndSkillsId_SkillType(boolean b, RRStatus rrStatus, boolean rrActive, SkillTypeEntity skillTypeEntity);

    List<SkillMapperRR> findByActiveAndRrMasterId(boolean b, RRMaster rrMaster);

    @Query("SELECT  smr.rrMasterId FROM SkillMapperRR smr " +
            "WHERE smr.rrMasterId.active = true " +
            "AND (coalesce(:companyIds, null) IS NULL OR smr.rrMasterId.company.companyId IN :companyIds) " +
            "AND (coalesce(:ownerRoleIds, null) IS NULL OR smr.rrMasterId.ownerId.userType.userTypeId IN :ownerRoleIds) " +
            "AND (coalesce(:ownerNamesIds, null) IS NULL OR smr.rrMasterId.ownerId.userId IN :ownerNamesIds) " +
            "AND (coalesce(:userRolesIds, null) IS NULL OR smr.skillsId.skillType.id IN :userRolesIds)")
    Page<RRMaster> filterRRMasters(
            @Param("companyIds") List<Integer> companyIds,
            @Param("userRolesIds") List<Integer> userRolesIds,
            @Param("ownerRoleIds") List<Integer> ownerRoleIds,
            @Param("ownerNamesIds") List<Integer> ownerNamesIds, Pageable rrMasterpage);

    @Query("SELECT smr.rrMasterId " +
            "FROM SkillMapperRR smr " +
            "WHERE smr.rrMasterId.active = true " +
            "AND (coalesce(:companyIds, null) IS NULL OR smr.rrMasterId.company.companyId IN :companyIds) " +
            "AND (coalesce(:ownerRoleIds, null) IS NULL OR smr.rrMasterId.ownerId.userType.userTypeId IN :ownerRoleIds) " +
            "AND (coalesce(:ownerNamesIds, null) IS NULL OR smr.rrMasterId.ownerId.userId IN :ownerNamesIds) " +
            "AND (coalesce(:userRolesIds, null) IS NULL OR smr.skillsId.skillType.id IN :userRolesIds) " +
            "GROUP BY smr.rrMasterId " +
            "ORDER BY smr.rrMasterId.rrMasterId DESC")
    Page<RRMaster> filterDistinctRRMastersOrderByRrMasterIdDesc(
            @Param("companyIds") List<Integer> companyIds,
            @Param("userRolesIds") List<Integer> userRolesIds,
            @Param("ownerRoleIds") List<Integer> ownerRoleIds,
            @Param("ownerNamesIds") List<Integer> ownerNamesIds, Pageable rrMasterpage);




//    @Query("SELECT COUNT(smr.rrMasterId) FROM SkillMapperRR smr " +
//            "WHERE smr.rrMasterId.active = true " +
//            "AND (coalesce(:companyIds, null) IS NULL OR smr.rrMasterId.company.companyId IN :companyIds) " +
//            "AND (coalesce(:ownerRoleIds, null) IS NULL OR smr.rrMasterId.ownerId.userType.userTypeId IN :ownerRoleIds) " +
//            "AND (coalesce(:ownerNamesIds, null) IS NULL OR smr.rrMasterId.ownerId.userId IN :ownerNamesIds) " +
//            "AND (coalesce(:userRolesIds, null) IS NULL OR smr.skillsId.skillType.id IN :userRolesIds)")
//    Long countFilteredRRMasters(
//            @Param("companyIds") List<Integer> companyIds,
//            @Param("userRolesIds") List<Integer> userRolesIds,
//            @Param("ownerRoleIds") List<Integer> ownerRoleIds,
//            @Param("ownerNamesIds") List<Integer> ownerNamesIds);

    @Query("SELECT COUNT(distinct smr.rrMasterId) FROM SkillMapperRR smr " +
            "WHERE smr.rrMasterId.active = true " +
            "AND (coalesce(:companyIds, null) IS NULL OR smr.rrMasterId.company.companyId IN :companyIds) " +
            "AND (coalesce(:ownerRoleIds, null) IS NULL OR smr.rrMasterId.ownerId.userType.userTypeId IN :ownerRoleIds) " +
            "AND (coalesce(:ownerNamesIds, null) IS NULL OR smr.rrMasterId.ownerId.userId IN :ownerNamesIds) " +
            "AND (coalesce(:userRolesIds, null) IS NULL OR smr.skillsId.skillType.id IN :userRolesIds)")
    Long countDistinctFilteredRRMasters(
            @Param("companyIds") List<Integer> companyIds,
            @Param("userRolesIds") List<Integer> userRolesIds,
            @Param("ownerRoleIds") List<Integer> ownerRoleIds,
            @Param("ownerNamesIds") List<Integer> ownerNamesIds);



    @Query("SELECT smrr.rrMasterId FROM SkillMapperRR smrr WHERE smrr.active = :active " +
            "AND smrr.rrMasterId.company.companyId = :companyId " +
            "AND smrr.rrMasterId.rrStatus.rrStatusId = :rrStatusId " +
            "AND smrr.skillsId.skillType.id IN :skillTypeIds")
    List<RRMaster> findRrMastersByCriteria(boolean active, Integer companyId, Integer rrStatusId, List<Integer> skillTypeIds);

    @Query("SELECT DISTINCT smrr.rrMasterId FROM SkillMapperRR smrr WHERE smrr.active = :active " +
            "AND smrr.rrMasterId.company.companyId = :companyId " +
            "AND smrr.rrMasterId.rrStatus.rrStatusId = :rrStatusId " +
            "AND smrr.skillsId.skillType.id IN :skillTypeIds")
    List<RRMaster> findDistinctRrMastersByCriteria(boolean active, Integer companyId, Integer rrStatusId, List<Integer> skillTypeIds);


//    List<RRMaster> findDistinctRrMasterByActiveAndRrMasterId_Company_CompanyIdAndRrMasterId_RrStatus_RrStatusIdAndSkillsId_SkillType_IdIn(boolean active, Integer companyId, Integer rrStatusId, List<Integer> skillTypeIds);  //doesnt work


    boolean existsByActiveAndRrMasterId_Company_CompanyIdOrSkillsId_SkillType_IdIn(boolean b, Integer companyId, List<Integer> skillSetIds);
    boolean existsByActiveAndRrMasterId_Company_CompanyIdAndSkillsId_SkillType_IdIn(boolean b, Integer companyId, List<Integer> skillSetIds);





    @Query("SELECT DISTINCT smrr.rrMasterId FROM SkillMapperRR smrr " +
            "WHERE smrr.skillsId.skillType = :skillTypeEntity " +
            "AND smrr.rrMasterId.active = true")
    List<RRMaster> findDistinctRrMastersBySkillTypeAndActiveIsTrue(SkillTypeEntity skillTypeEntity);




}
