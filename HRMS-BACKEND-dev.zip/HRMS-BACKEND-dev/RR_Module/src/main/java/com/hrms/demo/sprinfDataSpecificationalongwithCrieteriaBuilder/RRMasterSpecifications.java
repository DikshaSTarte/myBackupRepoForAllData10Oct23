package com.hrms.demo.sprinfDataSpecificationalongwithCrieteriaBuilder;

import com.hrms.demo.model.RRMaster;
import com.hrms.demo.model.SkillMapperRR;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;

import java.util.ArrayList;
import java.util.List;




public class RRMasterSpecifications {
    public static Specification<RRMaster> withFilters(
            List<String> companyNames,
            List<String> userRoles,
            List<String> ownerRoles,
            List<String> ownerNames,
            boolean activeOnly
    ) {
        return (Root<RRMaster> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (activeOnly) {
                predicates.add(criteriaBuilder.equal(root.get("active"), true));
            }

            if (companyNames != null && !companyNames.isEmpty()) {
                predicates.add(root.get("company").get("companyName").in(companyNames));
            }

            if (userRoles != null && !userRoles.isEmpty()) {
                Subquery<Integer> subquery = query.subquery(Integer.class);
                Root<SkillMapperRR> skillMapperRoot = subquery.from(SkillMapperRR.class);
                subquery.select(skillMapperRoot.get("rrMasterId").get("rrMasterId"))
                        .where(skillMapperRoot.join("skillsId").join("skillType").get("skillTypeName").in(userRoles));
                predicates.add(root.get("rrMasterId").in(subquery));
            }



            if (ownerRoles != null && !ownerRoles.isEmpty()) {
                predicates.add(root.get("ownerId").get("userType").get("userTypeName").in(ownerRoles));
            }

            if (ownerNames != null && !ownerNames.isEmpty()) {
                List<Predicate> ownerNamePredicates = new ArrayList<>();
                for (String ownerName : ownerNames) {
                    // Split ownerName into first name and last name
                    String[] names = ownerName.split(" ");
                    if (names.length == 2) {
                        String firstName = names[0];
                        String lastName = names[1];

                        // Use the CONCAT function to concatenate first name and last name with a space in between
                        Expression<String> fullNameExpression = criteriaBuilder.function("CONCAT", String.class,
                                root.get("ownerId").get("userFirstName"),
                                criteriaBuilder.literal(" "),
                                root.get("ownerId").get("userLastName")
                        );

                        // Use the fullNameExpression in the predicate
                        ownerNamePredicates.add(criteriaBuilder.equal(fullNameExpression, ownerName));
                    }
                }
                if (!ownerNamePredicates.isEmpty()) {
                    predicates.add(criteriaBuilder.or(ownerNamePredicates.toArray(new Predicate[0])));
                }
            }


            query.orderBy(criteriaBuilder.desc(root.get("rrMasterId")));
            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };
    }
}



//
//public class RRMasterSpecifications {
//
//    public static Specification<RRMaster> withFilters(List<String> companyNames, List<String> userRoles, List<String> ownerRoles, List<String> ownerNames) {
//        return (Root<RRMaster> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) -> {
//            List<Predicate> predicates = new ArrayList<>();
//
//            if (companyNames != null && !companyNames.isEmpty()) {
//                predicates.add(root.get("company").get("companyName").in(companyNames));
//            }
//
////            if (userRoles != null && !userRoles.isEmpty()) {
////                predicates.add(root.join("skillMapperRR").join("skillsId").join("skillType").get("skillTypeName").in(userRoles));
////            }
//
//            if (userRoles != null && !userRoles.isEmpty()) {
//                Subquery<Integer> subquery = query.subquery(Integer.class);
//                Root<SkillMapperRR> skillMapperRoot = subquery.from(SkillMapperRR.class);
//                subquery.select(skillMapperRoot.get("rrMasterId").get("rrMasterId")).where(skillMapperRoot.join("skillsId").join("skillType").get("skillTypeName").in(userRoles));
//                predicates.add(root.get("rrMasterId").in(subquery));
//            }
//
//
//            if (ownerRoles != null && !ownerRoles.isEmpty()) {
//                predicates.add(root.get("ownerId").get("userType").get("userTypeName").in(ownerRoles));
//            }
//
////            if (ownerNames != null && !ownerNames.isEmpty()) {
////                predicates.add(root.get("ownerId").get("userFirstName").in(ownerNames));
////            }
//            if (ownerNames != null && !ownerNames.isEmpty()) {
//                List<Predicate> ownerNamePredicates = new ArrayList<>();
//                for (String ownerName : ownerNames) {
//                    // Split ownerName into first name and last name
//                    String[] names = ownerName.split(" ");
//                    if (names.length == 2) {
//                        // Concatenate first name and last name and check if it is in ownerId's full name
//                        Expression<String> fullNameExpression = criteriaBuilder.concat(
//                                root.get("ownerId").get("userFirstName "),
//
//                                root.get("ownerId").get("userLastName")
//                        );
//                        ownerNamePredicates.add(fullNameExpression.in(ownerName));
//                    }
//                }
//                if (!ownerNamePredicates.isEmpty()) {
//                    predicates.add(criteriaBuilder.or(ownerNamePredicates.toArray(new Predicate[0])));
//                }
//            }
//
//            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
//
//        };
//    }
//}
//
