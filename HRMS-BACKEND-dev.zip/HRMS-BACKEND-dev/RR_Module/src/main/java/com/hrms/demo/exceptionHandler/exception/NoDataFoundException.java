package com.hrms.demo.exceptionHandler.exception;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class NoDataFoundException extends RuntimeException{
    private String message ;
}
