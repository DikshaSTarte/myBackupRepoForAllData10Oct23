package com.hrms.demo.dto.request;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CandidateStatusRequest {

    @NotBlank(message = "CandidateStatus must not be blank.")
    @Pattern(regexp = "^[a-zA-Z ,]+$", message = "CandidateStatus can only contain letters, commas, and spaces.")
    private String candidateStatusName;
}
