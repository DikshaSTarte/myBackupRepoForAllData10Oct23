package com.hrms.demo.serviceImpl;

import com.hrms.demo.model.Candidate;
import com.hrms.demo.model.FileUploade;
import com.hrms.demo.repository.CandidateRepository;
import com.hrms.demo.repository.FileUploadeRepository;
import com.hrms.demo.service.CvUploadDownloadService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
@Slf4j

@Service
public class CvUploadDownloadServiceImpl implements CvUploadDownloadService {
    @Autowired
    private FileUploadeRepository fileUploadeRepository;
    @Autowired
    private CandidateRepository candidateRepository;
    @Value("${upload.dir.resume}")
    private String uploadresume;

    @Override
    public ResponseEntity<Object> uploadFile(MultipartFile file) throws IOException {

        log.info("CvUploadDownloadServiceImpl--------------uploadFile-------{}");
        if (!file.getContentType().equalsIgnoreCase("application/pdf")) {
            // Return an error response if the file is not a PDF
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("message", "Only PDF files are allowed");
            log.error("CvUploadDownloadServiceImpl-----------uploadFile------{}","only pdf file allowed");
            return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
        }

        // Proceed with file upload if it is a PDF
        File myfile = new File(uploadresume + "/" + file.getOriginalFilename());
        myfile.createNewFile();
        FileOutputStream fos = new FileOutputStream(myfile);
        fos.write(file.getBytes());
        fos.close();

        FileUploade fileUpload = new FileUploade();
        fileUpload.setFilePath(uploadresume + "/" + file.getOriginalFilename());
        fileUpload.setFileName(file.getOriginalFilename());
        fileUpload.setFileSize(file.getSize());
        fileUpload.setFileType(file.getContentType());

        FileUploade savedFile = fileUploadeRepository.save(fileUpload);
        Integer fileId = savedFile.getFileId();

        Map<String, Object> response = new HashMap<>();
        response.put("message", "File uploaded successfully");
        response.put("fileId", fileId);
        log.info("CvUploadDownloadServiceImpl--------------uploadFile-------{}");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Resource> downloadFile(Integer candidateId, HttpServletRequest request) {
        log.info("CvUploadDownloadServiceImpl----------downloadFile--------{}");
        Candidate candidate = candidateRepository.findByActiveAndCandidateId(true, candidateId);

        if (candidate != null && candidate.getFileId() != null) {
            String fileName = candidate.getFileId().getFileName();

            // Specify the directory where the files are stored
            String filePath = uploadresume + "/" + fileName;

            // Load the file as a resource
            Resource resource = new FileSystemResource(filePath);

            if (resource.exists()) {
                // Determine the file's content type
                String contentType = null;
                try {
                    contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
                } catch (IOException e) {
                    log.error("CvUploadDownloadServiceImpl---------------downloadFile---------{}",e);
                    // Handle the exception or log the error
                }

                // Set appropriate headers for the file download
                HttpHeaders headers = new HttpHeaders();
                headers.add(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=" + fileName);
                headers.add(HttpHeaders.CONTENT_TYPE, contentType != null ? contentType : MediaType.APPLICATION_OCTET_STREAM_VALUE);

                return ResponseEntity.ok()
                        .headers(headers)
                        .body(resource);
            }
        }
log.info("CvUploadDownloadServiceImpl----------downloadFile--------{}");
        return ResponseEntity.notFound().build();
    }
}
