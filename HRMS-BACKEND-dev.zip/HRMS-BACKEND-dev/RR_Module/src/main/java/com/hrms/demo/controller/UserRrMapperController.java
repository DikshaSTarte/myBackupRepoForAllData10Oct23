package com.hrms.demo.controller;

import com.hrms.demo.dto.request.CandidateRequest;
import com.hrms.demo.dto.request.RRForUserRequest;
import com.hrms.demo.dto.response.CandidateResponse;
import com.hrms.demo.dto.response.UserResponse;
import com.hrms.demo.dto.response.UserRrMapperResponse;
import com.hrms.demo.model.UserRRMapper;
import com.hrms.demo.service.UserRrMapperService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
@Slf4j
@RestController
@RequestMapping("api/v1/userRrMapper")
public class UserRrMapperController {
    @Autowired
    private UserRrMapperService userRrMapperService ;
    @GetMapping("/getRr/{userId}")
    public List<UserRrMapperResponse> getRrByUserId(@PathVariable Integer userId){
        log.info("UserRrMapperController------getRrByUserId--{}",userId);
        return this.userRrMapperService.getRrByUserId(userId);
    }
    @PostMapping("/save")
    public List<UserRRMapper> SaveCondData(@Valid @RequestBody RRForUserRequest userRequest) {
        log.info("UserRrMapperController------SaveCondData--{}",userRequest);
        return userRrMapperService.saveRrForUser(userRequest);
    }
}