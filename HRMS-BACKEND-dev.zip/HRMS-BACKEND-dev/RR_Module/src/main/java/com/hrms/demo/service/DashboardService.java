package com.hrms.demo.service;

import com.hrms.demo.dto.request.DashboardRequest;
import com.hrms.demo.dto.response.DashboardResponse;
import com.hrms.demo.dto.response.PieChartMasterResponse;
import com.hrms.demo.dto.response.PiechartResponse;
import com.hrms.demo.dto.response.RRMasterResponse;
import com.hrms.demo.model.RRMaster;

import com.hrms.demo.dto.response.RRListByCompanyResponse;
import com.hrms.demo.dto.response.SkillTypeForRrResponse;

import java.time.LocalDate;
import java.util.List;
public interface DashboardService {
//    List<DashboardResponse> getMonthlyTrends();
    List<DashboardResponse> saveDateData(DashboardRequest dashboardRequest);
//    List<DashboardResponse> getMonthlyCounts(LocalDate startDate);
    List<RRMasterResponse> getRRListByStatus(Integer statusId);
    PiechartResponse getRRListCountByStatus();
    List<RRListByCompanyResponse> getRrCountByCustomer();
    List<SkillTypeForRrResponse> getSkillTypeCountForOpenRr();


}