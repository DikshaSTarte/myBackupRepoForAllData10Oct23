package com.hrms.demo.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CandidateFeedbackFormRequest {
    private Integer candidateId;
    private String description;
    private String candidateEmail;
    private String candidateFirstName;
    private String candidateLastName;
    private String candidateStatus;
}
