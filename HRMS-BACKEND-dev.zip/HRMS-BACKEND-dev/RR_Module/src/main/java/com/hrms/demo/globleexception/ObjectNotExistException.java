package com.hrms.demo.globleexception;

public class ObjectNotExistException extends RuntimeException {
    public ObjectNotExistException(String objectDoesNotExist) {
        super(objectDoesNotExist);
    }
}