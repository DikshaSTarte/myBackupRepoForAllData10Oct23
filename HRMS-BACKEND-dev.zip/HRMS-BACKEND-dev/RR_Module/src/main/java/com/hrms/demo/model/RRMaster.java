package com.hrms.demo.model;

import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "rr_master")
public class RRMaster extends BaseEntity {
//    @Id
//    @GeneratedValue(strategy = GenerationType.AUTO)
@Id
@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "rr_master_generator")
@SequenceGenerator(name = "rr_master_generator", sequenceName = "rr_master_SEQUENCE", initialValue = 4311, allocationSize = 1)
    private Integer rrMasterId;

    @ManyToOne
    private User ownerId;

    @Column(name = "experience")
    private Integer experience;

    @Column(name = "requiredCount")
    private Integer requiredCount;

    @ManyToOne
    private RRStatus rrStatus;

    @ManyToOne
    private Company company ;

    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate startDate ;

    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate endDate ;

    @ManyToOne
    @JoinColumn(name = "fileId")
    private FileUploade fileId;
}

