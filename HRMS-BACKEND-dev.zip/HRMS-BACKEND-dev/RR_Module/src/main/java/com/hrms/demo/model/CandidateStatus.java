package com.hrms.demo.model;

import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="candidateStatus")
@AllArgsConstructor
@NoArgsConstructor
public class CandidateStatus extends BaseEntity{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "candidateStatusId", nullable = false, columnDefinition = "int default 4")
    private Integer candidateStatusId;
    @Column(name = "candidateStatusName")
    private String candidateStatusName;
}
