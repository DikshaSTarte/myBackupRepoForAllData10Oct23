package com.hrms.demo.dto.response;

import lombok.*;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SkillMapperRrResponse {

    private Integer skillMapperId;

    private Integer rrId;

    private Integer skillsId;
}
