package com.hrms.demo.serviceImpl;

import com.hrms.demo.dto.request.RRMasterRequest;
import com.hrms.demo.dto.request.SkillMapperRrRequest;
import com.hrms.demo.dto.response.RRMasterResponse;
import com.hrms.demo.dto.response.SkillMapperRrResponse;
import com.hrms.demo.exceptionHandler.exception.ResourceNotFoundException;
import com.hrms.demo.model.RRMaster;
import com.hrms.demo.model.SkillMapperRR;
import com.hrms.demo.repository.SkillMapperRrRepository;
import com.hrms.demo.service.SkillMapperRrService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
@Slf4j
@Service
public class SkillMapperRrServiceImpl implements SkillMapperRrService {
    @Autowired
    SkillMapperRrRepository skillMapperRrRepository ;
    @Override
    public SkillMapperRrResponse createSkillMapperRr(SkillMapperRrRequest skillMapperRrRequest)
    {
        log.info("SkillMapperRrServiceImpl-----------createSkillMapperRr-----------{}",skillMapperRrRequest);
        SkillMapperRR skillMapperRR = new SkillMapperRR();
        skillMapperRR.setSkillMapperId(skillMapperRrRequest.getSkillMapperId());

        
        SkillMapperRR saveData = this.skillMapperRrRepository.save(skillMapperRR);
        SkillMapperRrResponse skillMapperRrResponse = mapSkillMapperToSkillMapperRrResponse(saveData);
                
        return skillMapperRrResponse ;
    }
    @Override
    public SkillMapperRrResponse getSkillMapperById(Integer id) {
        log.info("SkillMapperRrServiceImpl-----------getSkillMapperById-----------{}",id);
        SkillMapperRR skillMapperRR = skillMapperRrRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("SkillMapperRR"));
        return mapSkillMapperToSkillMapperRrResponse(skillMapperRR);
    }

    private SkillMapperRrResponse mapSkillMapperToSkillMapperRrResponse(SkillMapperRR skillMapperRR) {

        SkillMapperRrResponse skillMapperRrResponse = new SkillMapperRrResponse();
        skillMapperRrResponse.setSkillMapperId(skillMapperRR.getSkillMapperId());

        return skillMapperRrResponse;
    }
}


