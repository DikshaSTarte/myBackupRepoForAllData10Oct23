package com.hrms.demo.service;
import com.hrms.demo.dto.request.CompanyRequest;
import com.hrms.demo.dto.response.CandidateResponse;
import com.hrms.demo.dto.response.CompanyListResponse;
import com.hrms.demo.dto.response.CompanyResponse;
import com.hrms.demo.dto.response.GenericResponseDTO;
import com.hrms.demo.globleexception.CompanyAlreadyExistsException;
import com.hrms.demo.model.Company;
import com.hrms.demo.model.SkillTypeEntity;

import org.springframework.data.domain.Page;

import java.util.List;

public interface CompanyService {
    GenericResponseDTO saveCompany(CompanyRequest companyRequest) throws CompanyAlreadyExistsException;
    public String deleteCompanyById(Integer companyId);
    CompanyResponse getCompanyById(Integer companyId);
    CompanyResponse updateCompany(Integer companyId,CompanyRequest companyRequest);
    List<CompanyResponse> getListCompany();
    public List<CompanyResponse> getAllCompany(Integer pageNumber, String searchKey);

    Page<Company> searchCompany(String searchKeyword, int pageNo, int pageSize);

    CompanyListResponse getListCompanyOp(Integer pageNumber, Integer pageSize, String searchTerm);
    //TotalElement searchCompany(String searchKeyword, int pageNo, int pageSize);
}
