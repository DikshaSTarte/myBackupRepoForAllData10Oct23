package com.hrms.demo.repository;

import com.hrms.demo.model.User;
import com.hrms.demo.model.UserType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserTypeRepository extends JpaRepository<UserType,Integer> {
   /* List<UserType> findByActive(boolean b);*/
   List<UserType> findByActive(boolean b);
    UserType findByActiveAndUserTypeId (boolean active, Integer userId);
}