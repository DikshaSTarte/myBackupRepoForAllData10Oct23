package com.hrms.demo.controller;

import com.hrms.demo.dto.request.DashboardRequest;
import com.hrms.demo.dto.response.DashboardResponse;

import com.hrms.demo.dto.response.PieChartMasterResponse;
import com.hrms.demo.dto.response.PiechartResponse;
import com.hrms.demo.dto.response.RRMasterResponse;
import com.hrms.demo.model.RRMaster;

import com.hrms.demo.dto.response.RRListByCompanyResponse;
import com.hrms.demo.dto.response.SkillTypeForRrResponse;

import com.hrms.demo.service.DashboardService;
import com.hrms.demo.serviceImpl.DashboardServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import java.time.LocalDate;
import java.util.List;
@Slf4j
@RestController
@RequestMapping("/api/v1/dashboard")
public class DashboardController {
    @Autowired
    private DashboardService dashboard ;

    @Autowired
    private DashboardServiceImpl dashboardService;

    @PostMapping("/dateSave")
    public List<DashboardResponse> SaveDate(@Valid @RequestBody DashboardRequest dashboardRequest){
        log.info("DashboardController------SaveDate--{}",dashboardRequest);
        return dashboard.saveDateData(dashboardRequest);
    }

//    @GetMapping("/monthlyTrends")
//    public List<DashboardResponse> getMonthlyTrendsOfCandidates() {
//        log.info("DashboardController------getMonthlyTrendsOfCandidates--{}");
//        return this.dashboard.getMonthlyTrends();
//    }

//    @GetMapping("/monthlyCounts/{startDate}")
//    public ResponseEntity<List<DashboardResponse>> getMonthlyCounts(@PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate startDate) {
//        List<DashboardResponse> monthlyCounts = dashboard.getMonthlyCounts(startDate);
//        log.info("DashboardController------getMonthlyCounts--{}",startDate);
//        return ResponseEntity.ok(monthlyCounts);
//    }


    @GetMapping("/PiechartForRR")
    public ResponseEntity<List<RRMasterResponse>> getRRListByStatus(@RequestParam(value = "statusId",defaultValue = "1",required = false) Integer statusId) {
        List<RRMasterResponse> rrMasterList = dashboard.getRRListByStatus(statusId);
        log.info("DashboardController------getMonthlyCounts--{}",statusId);
        return ResponseEntity.ok(rrMasterList);
    }

    @GetMapping("/CountForPiechart")
    public ResponseEntity<PiechartResponse> getRRListCountByStatus(@RequestParam(value = "statusId",defaultValue = "1",required = false) Integer statusId) {
        PiechartResponse piechartResponse = dashboard.getRRListCountByStatus();
        log.info("DashboardController------getMonthlyCounts--{}", statusId);
        return ResponseEntity.ok(piechartResponse);
    }
        @GetMapping("/rrCount/byAllCompany")
        public List<RRListByCompanyResponse> getRRByCompany() {
            log.info("DashboardController------getRRByCompany--{}");
            return dashboard.getRrCountByCustomer();
        }
        @GetMapping("/role/RR")
        public List<SkillTypeForRrResponse> getSkillTypeForOpenRr () {
            log.info("DashboardController------getSkillTypeForOpenRr--{}");
        return dashboard.getSkillTypeCountForOpenRr();
        }
    }