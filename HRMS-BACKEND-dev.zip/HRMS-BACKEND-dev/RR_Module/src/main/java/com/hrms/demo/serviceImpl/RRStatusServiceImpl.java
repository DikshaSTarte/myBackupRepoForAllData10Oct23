package com.hrms.demo.serviceImpl;

import com.hrms.demo.dto.response.RRStatusResponse;
import com.hrms.demo.model.RRStatus;
import com.hrms.demo.repository.RRStatusRepository;
import com.hrms.demo.service.RRStatusService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
@Slf4j
@Service
public class RRStatusServiceImpl implements RRStatusService {

    @Autowired
    private RRStatusRepository rrStatusRepository;
    @Override
    public List<RRStatusResponse> getListOfRr() {
        log.info("RRStatusServiceImpl-------------getListOfRr------------{}");
        List<RRStatus> all = rrStatusRepository.findByActive(true);
         List<RRStatusResponse> rrResponseList= new ArrayList<>();
         for (RRStatus rrStatus1:all) {
             rrResponseList.add(rrStatusEntityTorrStatusResponse(rrStatus1));
         }
         return rrResponseList;
    }
    RRStatusResponse rrStatusEntityTorrStatusResponse(RRStatus rrStatus){
        RRStatusResponse rrStatusResponse= new RRStatusResponse();

        rrStatusResponse.setRrStatusId(rrStatus.getRrStatusId());
        rrStatusResponse.setRrStatusName(rrStatus.getRrStatusName());

        return rrStatusResponse;
    }

       private RRStatusResponse mapRRStatusToRRStatusResponse(RRStatus rrStatus)
       {
            if (rrStatus == null) {
                return null;
            }
            RRStatusResponse rrStatusResponse = new RRStatusResponse();
            rrStatusResponse.setRrStatusId(rrStatus.getRrStatusId());
            rrStatusResponse.setRrStatusName(rrStatus.getRrStatusName());
            return rrStatusResponse;
        }
}

