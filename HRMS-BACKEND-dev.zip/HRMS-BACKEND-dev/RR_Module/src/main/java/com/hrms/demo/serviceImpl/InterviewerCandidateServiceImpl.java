package com.hrms.demo.serviceImpl;

import com.hrms.demo.dto.request.CandidateFeedbackFormRequest;
import com.hrms.demo.dto.request.InterviewerCandidateRequest;
import com.hrms.demo.dto.response.*;
import com.hrms.demo.model.*;
import com.hrms.demo.repository.*;
import com.hrms.demo.service.InterviewerCandidateService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Slf4j
@Service
public class InterviewerCandidateServiceImpl implements InterviewerCandidateService {
    @Autowired
    private InterviewerCandidateRepository interviewerCandidateRepository;
    @Autowired
    private CandidateRepository candidateRepository;
    @Autowired
    private InterviewerRepository interviewerRepository;
    @Autowired
    private RRMasterRepository rrMasterRepository;
    @Autowired
    private  InterviewerMapperRepository interviewerMapperRepository;
    @Override
    public InterviewerCandidateResponse saveCandidatesForInterviewer(InterviewerCandidateRequest interviewerCandidateRequest) {
        log.info("InterviewerCandidateServiceImpl----------------saveCandidatesForInterviewer--------------{}",interviewerCandidateRequest);
        InterviewerCandidateMapper interviewerCandidateMapper = new InterviewerCandidateMapper();
        interviewerCandidateMapper.setRrId(rrMasterRepository.findByActiveAndRrMasterId(true, interviewerCandidateRequest.getRrId()));
        interviewerCandidateMapper.setInterviewerId(interviewerRepository.findByActiveAndInterviewerId(true, interviewerCandidateRequest.getInterviewerId()));
        interviewerCandidateMapper.setCandidateId(candidateRepository.findByActiveAndCandidateId(true, interviewerCandidateRequest.getCandidateId()));
        interviewerCandidateMapper.setDate(interviewerCandidateRequest.getInterviewDate());
        interviewerCandidateMapper.setTime(interviewerCandidateRequest.getInterviewTime());
        interviewerCandidateMapper.setFeedbackGiven(interviewerCandidateRequest.isFeedbackGiven());
        InterviewerCandidateMapper save = this.interviewerCandidateRepository.save(interviewerCandidateMapper);
        InterviewerCandidateResponse interviewerCandidateResponse = interviewerCandidateToInterviewerCandidateResponse(save);
        log.info("InterviewerCandidateServiceImpl----------------saveCandidatesForInterviewer--------------{}",interviewerCandidateRequest);
        return interviewerCandidateResponse;
    }

    private InterviewerCandidateResponse interviewerCandidateToInterviewerCandidateResponse(InterviewerCandidateMapper interviewerCandidateMapper) {
        InterviewerCandidateResponse interviewerCandidateResponse = new InterviewerCandidateResponse();
        interviewerCandidateResponse.setInterviewerId(interviewerCandidateMapper.getInterviewerId());
        interviewerCandidateResponse.setCandidateId(interviewerCandidateMapper.getCandidateId());
        interviewerCandidateResponse.setInterviewTime(interviewerCandidateMapper.getTime());
        interviewerCandidateResponse.setInterviewDate(interviewerCandidateMapper.getDate());
        interviewerCandidateResponse.setRrId(interviewerCandidateMapper.getRrId());
        interviewerCandidateResponse.setFeedbackGiven(interviewerCandidateMapper.isFeedbackGiven());
        return interviewerCandidateResponse;
    }
    @Override
    public List<InterviewerCandidateResponse> getCandidatesByInterviewerId(Integer interviewerId) {
        log.info("InterviewerCandidateServiceImpl----------------getCandidatesByInterviewerId--------------{}",interviewerId);
        List<InterviewerCandidateResponse> candidates = new ArrayList<>();
        List<InterviewerCandidateMapper> interviewerCandidateList1 = interviewerCandidateRepository.findByActiveAndInterviewerId_InterviewerId(true,interviewerId);
        List<InterviewerResponse> interviewers = new ArrayList<>();
        for (InterviewerCandidateMapper interviewerCandidateMapper : interviewerCandidateList1) {
            InterviewerCandidateResponse interviewerCandidateResponse1 = new InterviewerCandidateResponse();
            interviewerCandidateResponse1.setInterviewerCandidateMapperId(interviewerCandidateMapper.getInterviewerCandidateMapperId());
            interviewerCandidateResponse1.setCandidateId(interviewerCandidateMapper.getCandidateId());
            interviewerCandidateResponse1.setRrId(interviewerCandidateMapper.getRrId());
            interviewerCandidateResponse1.setInterviewerId(interviewerCandidateMapper.getInterviewerId());
            interviewerCandidateResponse1.setInterviewTime(interviewerCandidateMapper.getTime());
            interviewerCandidateResponse1.setInterviewDate(interviewerCandidateMapper.getDate());
//            interviewerCandidateResponse1.setFeedbackGiven(false);
                List<InterviewerMapper> byInterviewerCandidateMapper = interviewerMapperRepository.findByInterviewerCandidateMapper(interviewerCandidateMapper);
//            if(byInterviewerCandidateMapper!=null&&byInterviewerCandidateMapper.size()!=0) {
//                interviewerCandidateResponse1.setFeedbackGiven(byInterviewerCandidateMapper.get(0).isFeedbackGiven());
//            }

            interviewerCandidateResponse1.setFeedbackGiven(byInterviewerCandidateMapper.size()>0);
//            interviewerCandidateResponse1.setFeedbackGiven(interviewerCandidateMapper.isFeedbackGiven());
            candidates.add(interviewerCandidateResponse1);
        }
        return candidates;
    }
    @Override
    public InterviewerMapperListResponse getCandidatesByInterviewerId1(Integer interviewerId, Integer pageNumber, Integer pageSize, String searchTerm) {
        log.info("InterviewerCandidateServiceImpl----------------getCandidatesByInterviewerId1--------------{}",interviewerId,pageNumber,pageSize,searchTerm);
        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        Page<InterviewerCandidateMapper> page;

        if (searchTerm != null && !searchTerm.isEmpty()) {
            page = interviewerCandidateRepository.findByInterviewerIdAndSearchTerm(interviewerId,searchTerm,pageable);
        } else {
            page = interviewerCandidateRepository.findByActiveAndInterviewerId_InterviewerIdOrderByInterviewerCandidateMapperIdDesc(true,interviewerId, pageable);
        }
        List<InterviewerCandidateMapper> all=page.getContent();
        List<InterviewerCandidateResponse> candidates = new ArrayList<>();
        for (InterviewerCandidateMapper interviewerCandidateMapper : all) {
            InterviewerCandidateResponse interviewerCandidateResponse1 = new InterviewerCandidateResponse();
            interviewerCandidateResponse1.setInterviewerCandidateMapperId(interviewerCandidateMapper.getInterviewerCandidateMapperId());
            interviewerCandidateResponse1.setCandidateId(interviewerCandidateMapper.getCandidateId());
            interviewerCandidateResponse1.setRrId(interviewerCandidateMapper.getRrId());
            interviewerCandidateResponse1.setInterviewerId(interviewerCandidateMapper.getInterviewerId());
            interviewerCandidateResponse1.setInterviewTime(interviewerCandidateMapper.getTime());
            interviewerCandidateResponse1.setInterviewDate(interviewerCandidateMapper.getDate());
            interviewerCandidateResponse1.setFeedbackGiven(interviewerCandidateMapper.isFeedbackGiven());
            List<InterviewerMapper> byInterviewerCandidateMapper = interviewerMapperRepository.findByInterviewerCandidateMapper(interviewerCandidateMapper);
            interviewerCandidateResponse1.setFeedbackGiven(byInterviewerCandidateMapper.size()>0);
            candidates.add(interviewerCandidateResponse1);
        }
     System.out.println("here is the size................."+ page.getTotalElements());
        return new InterviewerMapperListResponse(page.getTotalElements(), candidates);
    }

    CandidateResponse changeCandidateToCandidateResponse(Candidate candidate)
    {
        CandidateResponse candidateResponse=new CandidateResponse();
        candidateResponse.setCandidateId(candidate.getCandidateId());
        candidateResponse.setCandidateEmail(candidate.getCandidateEmail());
//        candidateResponse.setCandidateStatus(new CandidateStatusResponse(candidate.getCandidateStatus().getCandidateStatusId(),candidate.getCandidateStatus().getCandidateStatusName()));
        candidateResponse.setCandidateContactNo(candidate.getCandidateContactNo());
        candidateResponse.setCandidateExperience(candidate.getCandidateExperience());
        candidateResponse.setCandidateCurrentCompany(candidate.getCandidateCurrentCompany());
        candidateResponse.setCandidateFirstName(candidate.getCandidateFirstName());
        candidateResponse.setCandidateLastName(candidate.getCandidateLastName());
        candidateResponse.setCandidateNoticePeriod(candidate.getCandidateNoticePeriod());
        return candidateResponse;

    }
    RRMasterResponse changeRRMasterToRrResponse(RRMaster rm)
    {
        RRMasterResponse rmR=new RRMasterResponse();
        rmR.setRrMasterId(rm.getRrMasterId());
        rmR.setStartDate(rm.getStartDate());
        rmR.setEndDate(rm.getEndDate());
        rmR.setRrStatus(rm.getRrStatus());
        rmR.setRequiredCount(rm.getRequiredCount());
        rmR.setOwnerId(new OwnerResponse(rm.getOwnerId().getUserId(),rm.getOwnerId().getUserType(), rm.getOwnerId().getUserFirstName(),rm.getOwnerId().getUserLastName(),rm.getOwnerId().getUserContact(),rm.getOwnerId().getUserEmailId()));
        rmR.setExperience(rm.getExperience());
        rmR.setCompany(rm.getCompany());
        return rmR;
    }
    InterviewerResponse changeInterviewerToInterviewerResponse(Interviewer interviewer)
    {
        InterviewerResponse interviewerResponse=new InterviewerResponse();
        interviewerResponse.setInterviewerId(interviewer.getInterviewerId());
        interviewerResponse.setInterviewerEmail(interviewer.getInterviewerEmail());
        interviewerResponse.setInterviewerContactNo(interviewer.getInterviewerContactNo());
        interviewerResponse.setInterviewerExperience(interviewer.getInterviewerExperience());
        interviewerResponse.setInterviewerLastName(interviewer.getInterviewerLastName());
        interviewerResponse.setInterviewerFirstName(interviewer.getInterviewerFirstName());
        return  interviewerResponse;
    }

    @Override
    public List<InterviewerCandidateResponse> getAllCandidatesForInterviewer() {
        log.info("InterviewerCandidateServiceImpl----------------getAllCandidatesForInterviewer--------{}");
        List<InterviewerCandidateMapper> all = interviewerCandidateRepository.findByActive(true);
        List<InterviewerCandidateResponse> interviewerCandidateResponseList1 = new ArrayList<>();
        for (InterviewerCandidateMapper interviewerCandidateMapper : all) {
            interviewerCandidateResponseList1.add(interviewerCandidateMapToInterviewerCandidateResponse(interviewerCandidateMapper));
        }
        return interviewerCandidateResponseList1;
    }
    private InterviewerCandidateResponse interviewerCandidateMapToInterviewerCandidateResponse(InterviewerCandidateMapper interviewerCandidateMapper) {
        InterviewerCandidateResponse interviewerCandidateResponse = new InterviewerCandidateResponse();
        interviewerCandidateResponse.setInterviewerId(interviewerCandidateMapper.getInterviewerId());
        interviewerCandidateResponse.setCandidateId(interviewerCandidateMapper.getCandidateId());
        interviewerCandidateResponse.setRrId(interviewerCandidateMapper.getRrId());
        interviewerCandidateResponse.setInterviewTime(interviewerCandidateMapper.getTime());
        interviewerCandidateResponse.setInterviewDate(interviewerCandidateMapper.getDate());
        return interviewerCandidateResponse;
    }
    @Override
    public InterviewerFeedbackOnCandidateResponse saveFeedbackForCandidate(CandidateFeedbackFormRequest feedbackFormRequest) {
        log.info("InterviewerCandidateServiceImpl-----------saveFeedbackForCandidate------------{}",feedbackFormRequest);
        InterviewerCandidateMapper interviewerCandidateMapper = new InterviewerCandidateMapper();
        interviewerCandidateMapper.setCandidateId(candidateRepository.findByActiveAndCandidateId(true, feedbackFormRequest.getCandidateId()));

        InterviewerCandidateMapper save = this.interviewerCandidateRepository.save(interviewerCandidateMapper);
        InterviewerFeedbackOnCandidateResponse interviewerFeedbackOnCandidateResponse = interviewerFeedbackToCandidateResponse(save);
        return interviewerFeedbackOnCandidateResponse;
    }

    private InterviewerFeedbackOnCandidateResponse interviewerFeedbackToCandidateResponse(InterviewerCandidateMapper interviewerCandidateMapper) {
        log.info("InterviewerCandidateServiceImpl---------interviewerFeedbackToCandidateResponse--------{}",interviewerCandidateMapper);
        InterviewerFeedbackOnCandidateResponse interviewerFeedbackOnCandidateResponse = new InterviewerFeedbackOnCandidateResponse();

        interviewerFeedbackOnCandidateResponse.setCandidateId(interviewerCandidateRepository.findBycandidateId(interviewerCandidateMapper.getCandidateId()));
//        interviewerFeedbackOnCandidateResponse.setDescription(interviewerCandidateMapper.getDescription());
        return interviewerFeedbackOnCandidateResponse;
    }
    @Override
    public void deleteCandidateByinterviewerCandidateMapperId(Integer interviewerCandidateMapperId) {
        log.info("InterviewerCandidateServiceImpl---------------deleteCandidateByinterviewerCandidateMapperId-------------{}",interviewerCandidateMapperId);
        Optional<InterviewerCandidateMapper> interviewerCandidateMapper = interviewerCandidateRepository.findById(interviewerCandidateMapperId);
        interviewerCandidateMapper.get().setActive(false);
        interviewerCandidateRepository.save(interviewerCandidateMapper.get());
        log.info("InterviewerCandidateServiceImpl---------deleteCandidateByinterviewerCandidateMapperId---------{}",interviewerCandidateMapperId,"Candidate Successfully Deleted");
        System.out.println("Candidate Successfully Deleted");
    }


}



