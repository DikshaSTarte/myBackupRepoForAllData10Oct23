package com.hrms.demo.service;

import com.hrms.demo.dto.request.RRForUserRequest;
import com.hrms.demo.dto.response.UserRrMapperResponse;
import com.hrms.demo.model.UserRRMapper;

import java.util.List;

public interface UserRrMapperService {
    List<UserRrMapperResponse> getRrByUserId(Integer userId);
    List<UserRRMapper> saveRrForUser(RRForUserRequest userRequest);
}
