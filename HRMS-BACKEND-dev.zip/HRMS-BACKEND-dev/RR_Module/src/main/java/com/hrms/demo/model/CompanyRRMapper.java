package com.hrms.demo.model;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.persistence.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name="companyRRMapper")
public class CompanyRRMapper extends BaseEntity{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name ="companyRRMapperId")
    private Integer companyRRMapperId;
    @Column(name ="rrId")
    private Integer rrId;
    @Column(name ="companyId")
    private Integer companyId;
}