package com.hrms.demo.dto.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrms.demo.model.Candidate;
import com.hrms.demo.model.Interviewer;
import com.hrms.demo.model.RRMaster;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CandidateForRrResponse {
    private Candidate candidateId ;
    private RRMaster rrId ;
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate interviewDate;
    private LocalTime interviewTime;
    private boolean feedbackGiven;
    private Interviewer interviewer;
    private List<SkillResponse> skillsId;
}
