package com.hrms.demo.controller;

import com.hrms.demo.constants.ConstantsForApis;
import com.hrms.demo.dto.request.CreateSkillRequest;
import com.hrms.demo.dto.request.RRMasterRequest;
import com.hrms.demo.dto.request.SkillRequest;
import com.hrms.demo.dto.response.*;
import com.hrms.demo.exceptionHandler.exception.ResourceNotFoundException;
import com.hrms.demo.globleexception.SkillAlreadyExistForSKillTypeException;
import com.hrms.demo.globleexception.SkillSetAlreadyExistException;
import com.hrms.demo.service.SkillService;
import com.hrms.demo.service.SkillTypeService;
import javax.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@Slf4j
@RestController
@RequestMapping("/api/v1/skills")
public class SkillController {
    @Autowired
    private SkillService skillService;

    @GetMapping("/list")
    public List<SkillResponse> getAllSkills() {
        log.info("SkillController------getAllSkills--{}");
        return this.skillService.getAllSkills();
    }

    @GetMapping("/get/{id}")
    public SkillResponse getSkillById(@PathVariable Integer id) throws ResourceNotFoundException {
        log.info("SkillController------getSkillById--{}",id);
        return this.skillService.getSkillById(id);
    }

    @GetMapping("/getSkillsBySkillTypeId")
    public List<SkillTypeDTO> getBySkillType(@RequestParam("skillTypeId") Integer skillTypeId ){
        log.info("SkillController------getBySkillType--{}",skillTypeId);
        return this.skillService.getSkillsBySkillTypeId(skillTypeId);
    }
    @PostMapping("/save")
    public SkillDTO saveSkillData(@Valid @RequestBody CreateSkillRequest skillRequest) throws ResourceNotFoundException, SkillSetAlreadyExistException, SkillAlreadyExistForSKillTypeException {

        System.out.println("skill Added Successfully...");
        log.info("SkillController------saveSkillData--{}",skillRequest);
        return skillService.createSkill(skillRequest);
    }
    @PutMapping("/update/{id}")
    public SkillResponse updateSkillData(@PathVariable Integer id,  @RequestBody SkillRequest skillRequest) throws ResourceNotFoundException {
        log.info("SkillController------updateSkillData--{}",id,skillRequest);
        return skillService.updateSkill(id, skillRequest);
    }
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteSkill(@PathVariable Integer id) throws ResourceNotFoundException {
        skillService.deleteSkill(id);
        System.out.println("Skill Deleted Successfully...");
        log.info("SkillController------deleteSkill--{}",id);
        return ResponseEntity.noContent().build();
    }

   /* @GetMapping("/list/check")
    public ResponseEntity<SkillListResponse> getShowListSkills(@RequestParam(value = "pageNumber",defaultValue = "0",required = false) Integer pageNumber,
                                                                   @RequestParam(value = "pageSize",defaultValue = "10",required = false) Integer pageSize,
                                                                   @RequestParam(value = "searchTerm",defaultValue = "",required = false)String searchTerm ){
        log.info("SkillController------getShowListSkills--{}");

        SkillListResponse skillListResponse=skillService.getListSkillOp(pageNumber, pageSize, searchTerm);
        return ResponseEntity.ok(skillListResponse);
    }*/
  @GetMapping("/list/skills")
  public ResponseEntity<SkillEntityListResponse> getListOfCandidates(@RequestParam(value = "pageNumber",defaultValue = "0",required = false) Integer pageNumber,
                                                                       @RequestParam(value = "pageSize",defaultValue = "10",required = false) Integer pageSize,
                                                                       @RequestParam(value = "searchTerm",defaultValue = "",required = false)String searchTerm ){
  log.info("CandidateController------getListOfCandidates--{}");

      SkillEntityListResponse skillEntityListResponse =skillService.getListSkillsPg(pageNumber, pageSize, searchTerm);
      return ResponseEntity.ok(skillEntityListResponse);
  }
}

