package com.hrms.demo.dto.response;

import lombok.*;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SkillTypeResponse {
    private Integer id;
    private String skillTypename;
}
