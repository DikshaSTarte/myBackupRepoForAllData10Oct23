package com.hrms.demo.repository;

import com.hrms.demo.model.RRCandidateMapper;
import com.hrms.demo.model.User;
import com.hrms.demo.model.UserRRMapper;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface UserRrMapperRepository extends JpaRepository<UserRRMapper,Integer> {
    List<UserRRMapper> findByActiveAndUserId(boolean b , User userId);

}