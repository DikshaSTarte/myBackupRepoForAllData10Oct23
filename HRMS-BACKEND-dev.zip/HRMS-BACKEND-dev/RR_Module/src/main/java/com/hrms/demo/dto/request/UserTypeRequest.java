package com.hrms.demo.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserTypeRequest {
   // private Integer userTypeId ;
   @NotBlank(message = "userTypeName must not be blank.")
   @Pattern(regexp = "^[a-zA-Z ]+$", message = "userTypeName can only contain letters and spaces.")
    private String userTypeName ;
}
