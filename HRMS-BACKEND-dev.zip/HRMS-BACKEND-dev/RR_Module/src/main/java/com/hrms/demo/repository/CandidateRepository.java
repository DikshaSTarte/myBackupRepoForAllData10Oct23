package com.hrms.demo.repository;

import com.hrms.demo.model.Candidate;
import com.hrms.demo.model.CandidateStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CandidateRepository extends JpaRepository<Candidate, Integer> {
    Candidate findByActiveAndCandidateId(boolean active, Integer CandidateId);

    List<Candidate> findByActive(boolean b);

    List<Candidate> findByActiveOrderByCreatedOnAsc(boolean b);

    List<Candidate> findByActive(boolean active, Pageable pageable);


    //public List<Candidate> findByActiveAndCandidateFirstNameContainingIgnoreCaseOrCandidateLastNameContainingIgnoreCaseOrCandidateEmailContainingIgnoreCaseOrCandidateContactNoContainingIgnoreCase(boolean active,String key1,String key2,String key3,String key4,Pageable pageable);

    //  public List<Candidate> findByActiveAndCandidateFirstNameIgnoreCaseStartingWithOrCandidateLastNameIgnoreCaseStartingWithOrCandidateEmailIgnoreCaseStartingWithOrCandidateContactNoIgnoreCaseStartingWithOrCandidateExperienceGreaterThanOrCandidateCurrentCompanyIgnoreCaseStartingWithOrCandidateNoticePeriodLessThan(boolean active,String key1,String key2,String key3,String key4,float key5,String key6,float key7,Pageable pageable);
    boolean existsByActiveAndCandidateEmail(boolean active, String candidateEmail);

    Candidate findByCandidateId(Integer candidateId);

    List<Candidate> findByActiveAndCandidateFirstNameIgnoreCaseStartingWithOrCandidateLastNameIgnoreCaseStartingWithOrCandidateEmailIgnoreCaseStartingWithOrCandidateContactNoIgnoreCaseStartingWithOrCandidateCurrentCompanyIgnoreCaseStartingWith(boolean b, String searchKey, String searchKey1, String searchKey2, String searchKey3, String searchKey4, Pageable pageable);

    boolean existsByActiveAndCandidateContactNo(boolean b, String candidateContactNo);


    Page<Candidate> findByActiveOrderByCandidateIdDesc(boolean active, Pageable pageable);


    /*  @Query("SELECT c FROM Candidate c WHERE " +

              "LOWER(c.candidateId) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +

              "LOWER(c.candidateCurrentCompany) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +

              "LOWER(c.candidateStatus.candidateStatusId) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +

              "LOWER(c.candidateNoticePeriod) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +

              "LOWER(c.candidateExpectedCtc) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +

              "LOWER(c.candidateFirstName) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +

              "LOWER(c.candidateLastName) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +

              "LOWER(c.candidateContactNo) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +

              "LOWER(c.candidateExperience) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +

              "LOWER(c.candidateCurrentCtc) LIKE LOWER(CONCAT('%', :searchTerm, '%'))")
  */
 /* @Query("SELECT c FROM Candidate c WHERE " +

          "LOWER(c.candidateId) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +

          "LOWER(c.candidateCurrentCompany) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +

          "LOWER(c.candidateStatus.candidateStatusId) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +

          "LOWER(c.candidateNoticePeriod) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +

          "LOWER(c.candidateExpectedCtc) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +

          "LOWER(c.candidateFirstName) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +

          "LOWER(c.candidateLastName) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +

          "LOWER(c.candidateContactNo) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +

          "LOWER(c.candidateExperience) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +

          "LOWER(c.candidateCurrentCtc) LIKE LOWER(CONCAT(:searchTerm, '%'))"+
            "ORDER BY c.id DESC")
    List<Candidate> findBySearchTerm(String searchTerm, Pageable pageable);*/



@Query("SELECT c FROM Candidate c WHERE " +
        "c.active = true AND (" +
        "LOWER(c.candidateCurrentCompany) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
        "LOWER(c.candidateFirstName) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
        "LOWER(c.candidateLastName) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
        "LOWER(c.candidateEmail) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
        "LOWER(c.candidateContactNo) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
        "LOWER(c.candidateExperience) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
        "CONCAT(LOWER(c.candidateFirstName), ' ', LOWER(c.candidateLastName)) LIKE LOWER(CONCAT(:searchTerm, '%'))) " +
        "ORDER BY c.id DESC")
List<Candidate> findBySearchTerm(@Param("searchTerm") String searchTerm, Pageable pageable);


//    @Query("SELECT COUNT(c) FROM Candidate c WHERE " +
//            "c.active = true AND (" +
//            "LOWER(c.candidateId) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
//            "LOWER(c.candidateCurrentCompany) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
//          //  "LOWER(c.candidateStatus.candidateStatusId) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
//            "LOWER(c.candidateNoticePeriod) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
//            "LOWER(c.candidateExpectedCtc) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
//            "LOWER(c.candidateFirstName) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
//            "LOWER(c.candidateLastName) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
//            "LOWER(c.candidateContactNo) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
//            "LOWER(c.candidateExperience) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
//            "LOWER(c.candidateCurrentCtc) LIKE LOWER(CONCAT(:searchTerm, '%'))) " +
//            "OR CONCAT(LOWER(c.candidateFirstName), ' ', LOWER(c.candidateLastName)) LIKE LOWER(CONCAT(:searchTerm, '%'))")

    @Query("SELECT COUNT(c) FROM Candidate c WHERE " +
            "c.active = true AND (" +
            "LOWER(c.candidateCurrentCompany) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "LOWER(c.candidateFirstName) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "LOWER(c.candidateLastName) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "LOWER(c.candidateEmail) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "LOWER(c.candidateContactNo) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "LOWER(c.candidateExperience) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "CONCAT(LOWER(c.candidateFirstName), ' ', LOWER(c.candidateLastName)) LIKE LOWER(CONCAT(:searchTerm, '%'))) ")
    long countByActiveAndSearchTerm(@Param("searchTerm") String searchTerm);

    long countByActive(boolean active);
}
