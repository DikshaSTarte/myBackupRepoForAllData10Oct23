package com.hrms.demo.controller;

import com.hrms.demo.dto.response.RRStatusResponse;
import com.hrms.demo.dto.response.UserResponse;
import com.hrms.demo.model.RRStatus;
import com.hrms.demo.repository.RRStatusRepository;
import com.hrms.demo.service.RRStatusService;
import com.hrms.demo.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
@Slf4j
@RestController
@RequestMapping("/api/v1/rrs")
public class RRStatusController {
    @Autowired
    private RRStatusService rrStatusService;
    @Autowired
    private RRStatusRepository rrStatusRepository;
    @GetMapping("/list")
    public List<RRStatusResponse> getListOfRrStatus() {
        log.info("RRStatusController------getListOfRrStatus--{}");
        return this.rrStatusService.getListOfRr();
    }
}
