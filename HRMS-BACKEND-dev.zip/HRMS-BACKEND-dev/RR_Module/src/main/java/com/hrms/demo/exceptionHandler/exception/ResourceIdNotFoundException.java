package com.hrms.demo.exceptionHandler.exception;

public class ResourceIdNotFoundException extends RuntimeException{
    public ResourceIdNotFoundException(Integer id) {

        super(String.valueOf(id));

    }
}
