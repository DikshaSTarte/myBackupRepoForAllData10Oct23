package com.hrms.demo.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.Size;
@Getter
@Setter
@Entity
@Table(name="email_templates")
@AllArgsConstructor
@NoArgsConstructor
public class EmailTemplates {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private Integer templateId;
    @Column(name = "template_name")
    private String templateName;
    @Column(name = "template_body" )
    @Size(min=255 ,max=1000)
    private String templateBody;

}
