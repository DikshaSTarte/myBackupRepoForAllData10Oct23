package com.hrms.demo.model;

import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "skill_mapper_rr")
public class SkillMapperRR extends BaseEntity
{
    /* @Id
    @GeneratedValue(strategy=GenerationType.AUTO)*/
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "skill_mapper_rr_generator")
    @SequenceGenerator(name = "skill_mapper_rr_generator", sequenceName = "skill_mapper_rr_SEQUENCE", initialValue = 4317, allocationSize = 1)
    private Integer skillMapperId ;
    @ManyToOne
    private RRMaster rrMasterId ;
    @ManyToOne
    private SkillEntity skillsId ;

    public SkillTypeEntity getSkillTypeEntity() {
        if (skillsId != null) {
            return skillsId.getSkillType();
        }
        return null;
    }
}
