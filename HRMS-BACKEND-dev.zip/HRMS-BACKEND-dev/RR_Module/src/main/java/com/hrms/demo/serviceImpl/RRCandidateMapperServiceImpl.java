
package com.hrms.demo.serviceImpl;

import com.hrms.demo.dto.request.RRCandidateMapperRequest;
import com.hrms.demo.dto.request.RrFinalCandidateRequest;
import com.hrms.demo.dto.response.*;
import com.hrms.demo.mapper.CandidateMapper;
import com.hrms.demo.model.*;
import com.hrms.demo.repository.*;
import com.hrms.demo.service.RRCandidateMapperService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Slf4j
@Service
public class RRCandidateMapperServiceImpl implements RRCandidateMapperService {
    @Autowired
    private CandidateStatusRepository candidateStatusRepository;
    @Autowired
   private RRCandidateMapperRepository rrCandidateMapperRepository;
@Autowired
private CandidateRepository candidateRepository;
@Autowired
private RRMasterRepository rrMasterRepository;
@Autowired
private InterviewerCandidateRepository interviewerCandidateRepository;
@Autowired
private SelectedCandidateMapperRepository selectedCandidateMapperRepository;
    @Override
    public RRCandidateMapperResponse saveCandidatesByRrId(RRCandidateMapperRequest rrCandidateMapperRequest) {
        log.info("RRCandidateMapperServiceImpl--------------saveCandidatesByRrId----------{}",rrCandidateMapperRequest);
        Integer rrMasterId= rrCandidateMapperRequest.getRrId();
        RRMaster saveRr=rrMasterRepository.findByActiveAndRrMasterId(true,rrMasterId);

        List<Integer> candidateId1 = rrCandidateMapperRequest.getCandidateId();
        List<RRCandidateMapper> rrCandidateMapperList=new ArrayList<>();
        for (Integer id:candidateId1){
            Candidate saveCand= candidateRepository.findByActiveAndCandidateId(true,id);
            RRCandidateMapper rrCandidateMapper=new RRCandidateMapper();
            rrCandidateMapper.setCandidateId(saveCand);
            rrCandidateMapper.setRrId(saveRr);
            CandidateStatus candidateStatus=candidateStatusRepository.findByActiveAndCandidateStatusId(true,1);
            rrCandidateMapper.setCandidateStatus(candidateStatus);
            rrCandidateMapperList.add(rrCandidateMapper);
        }
        List<RRCandidateMapper> rrCandidateMappers = rrCandidateMapperRepository.saveAll(rrCandidateMapperList);
        RRCandidateMapperResponse rrCandidateMapperResponse = rrCandidateMapperEntityToRRCandidateMapperResponse(rrCandidateMappers);
        List<RRCandidateMapper>rr= rrCandidateMapperRepository.saveAll(rrCandidateMapperList);
        rrCandidateMapperResponse.setRrId(rrMasterId);
        rrCandidateMapperResponse.setCandidateId(candidateId1);
        return rrCandidateMapperResponse;
    }
    private RRCandidateMapperResponse rrCandidateMapperEntityToRRCandidateMapperResponse(List<RRCandidateMapper> rrCandidateMappers) {
        RRCandidateMapperResponse rrCandidateMapperResponse=new RRCandidateMapperResponse();
        return rrCandidateMapperResponse;
    }

    @Override
    public List<SelectedCandidateResponse> getAllSelectedCandidatesByRrId(Integer rrId) {
        log.info("RRCandidateMapperServiceImpl--------------getAllSelectedCandidatesByRrId----------{}",rrId);
        List<SelectedCandidateResponse> responses = new ArrayList<>();
        RRMaster rrMaster = rrMasterRepository.findById(rrId).get();
        List<SelectedCandidateMapper> candidateMapperList = selectedCandidateMapperRepository.findByActiveAndRrId(true,rrMaster);
        for (SelectedCandidateMapper selectedCandidateMapper : candidateMapperList) {
            SelectedCandidateResponse selectedCandidateResponse = new SelectedCandidateResponse();
            selectedCandidateResponse.setRrId(selectedCandidateMapper.getRrId());
            selectedCandidateResponse.setCandidateId(selectedCandidateMapper.getCandidateId());
            responses.add(selectedCandidateResponse);
        }
        return responses;
    }


    @Override
    public List<SelectedCandidateMapper> saveSelectedCandidatesByRrId(RrFinalCandidateRequest rrFinalCandidateRequest) {
        log.info("RRCandidateMapperServiceImpl---------saveSelectedCandidatesByRrId------{}",rrFinalCandidateRequest);
        Optional<RRMaster> rrMaster = rrMasterRepository.findById(rrFinalCandidateRequest.getRrId());
        List<SelectedCandidateMapper> selectedCandidateMapperList = new ArrayList<>();
        for (Integer candidateId : rrFinalCandidateRequest.getCandidateId()) {
            Optional<Candidate> candidate1 = candidateRepository.findById(candidateId);
            Candidate candidate=candidate1.get();
            CandidateStatus candidateStatus=candidateStatusRepository.getCandidateStatusBycandidateStatusId(5);
//            candidate.setCandidateSelectedFor(candidate.getCandidateSelectedFor()+1);
            System.out.println("------------------------------------------"+candidateStatus.getCandidateStatusName());
            RRCandidateMapper rrCandidateMapper=rrCandidateMapperRepository.findByActiveAndCandidateIdAndRrId(true,candidate1.get(),rrMaster.get());
            rrCandidateMapper.setCandidateStatus(candidateStatus);
//            candidate.setCandidateStatus(candidateStatus);
            SelectedCandidateMapper selectedCandidateMapper = new SelectedCandidateMapper();
            selectedCandidateMapper.setRrId(rrMaster.get());
            selectedCandidateMapper.setCandidateId(candidate1.get());
            selectedCandidateMapperList.add(selectedCandidateMapper);
        }
        List<SelectedCandidateMapper> selectedCandidateMapperList1 = selectedCandidateMapperRepository.saveAll(selectedCandidateMapperList);
        log.info("RRCandidateMapperServiceImpl---------saveSelectedCandidatesByRrId------{}",rrFinalCandidateRequest);
        return selectedCandidateMapperList1;
    }




}

