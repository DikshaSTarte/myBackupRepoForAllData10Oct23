package com.hrms.demo.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InterviewerMapperListResponse  {
    private long totalCandidates;
    private List<InterviewerCandidateResponse> candidates;
//    private Integer  interviewerCandidateMapperId;

//    public InterviewerMapperListResponse(long totalElements, List<InterviewerCandidateResponse> candidates) {
//
//    }
}