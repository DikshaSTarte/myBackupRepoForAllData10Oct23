package com.hrms.demo.service;

import com.hrms.demo.dto.request.InterviewerFeedbackRequest;
import com.hrms.demo.dto.response.InterviewerFeedbackResponse;

import java.util.List;

public interface InterviewerFeedbackService {
    InterviewerFeedbackResponse saveInterviewerFeedback(InterviewerFeedbackRequest interviewerFeedbackRequest);
    public String deleteInterviewerFeedbackById(Integer interviewerFdbkId);
    InterviewerFeedbackResponse getInterviewerFeedbackById(Integer interviewerFdbkId);
    InterviewerFeedbackResponse updateInterviewerFeedback(Integer interviewerFdbkId, InterviewerFeedbackRequest interviewerFeedbackRequest);
    List<InterviewerFeedbackResponse> getListInterviewerFeedback();
}
