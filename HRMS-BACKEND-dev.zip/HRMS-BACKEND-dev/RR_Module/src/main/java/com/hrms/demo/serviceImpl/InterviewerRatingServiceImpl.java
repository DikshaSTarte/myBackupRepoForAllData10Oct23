package com.hrms.demo.serviceImpl;
import com.hrms.demo.repository.InterviewerRatingRepository;
import com.hrms.demo.dto.request.InterviewerRatingRequest;
import com.hrms.demo.dto.response.InterviewerRatingResponse;
import com.hrms.demo.model.InterviewerRating;
import com.hrms.demo.service.InterviewerRatingService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Slf4j
@Service
public class InterviewerRatingServiceImpl implements InterviewerRatingService {
    @Autowired
    private InterviewerRatingRepository interviewerRatingRepository;

    InterviewerRatingResponse interviewerRatingEntityToInterviewerRatingResponse(InterviewerRating interviewerRating){
        InterviewerRatingResponse interviewerRatingResponse= new InterviewerRatingResponse();
        interviewerRatingResponse.setRateScore(interviewerRating.getRateScore());
        return interviewerRatingResponse;
    }
    @Override
    public InterviewerRatingResponse saveInterviewerRating(InterviewerRatingRequest interviewerRatingRequest) {
        log.info("InterviewerRatingServiceImpl-------------saveInterviewerRating-------------{}",interviewerRatingRequest);
        InterviewerRating interviewerRating= new InterviewerRating();
        interviewerRating.setRateScore(interviewerRatingRequest.getRateScore());
        InterviewerRating save= this.interviewerRatingRepository.save(interviewerRating);
        InterviewerRatingResponse interviewerRatingResponse=interviewerRatingEntityToInterviewerRatingResponse(save);
        return interviewerRatingResponse;
    }

    @Override
    public String deleteInterviewerRatingById(Integer interviwerRatingId) {
        log.info("InterviewerRatingServiceImpl-------------deleteInterviewerRatingById-------------{}",interviwerRatingId);
        Optional<InterviewerRating> interviewerRating= interviewerRatingRepository.findById(interviwerRatingId);
        interviewerRating.get().setActive(false);
        interviewerRatingRepository.save(interviewerRating.get());
        return "InterviewerRating Successfully Deleted";
    }

    @Override
    public InterviewerRatingResponse getInterviewerRatingById(Integer interviwerRatingId) {
        log.info("InterviewerRatingServiceImpl-------------getInterviewerRatingById-------------{}",interviwerRatingId);
        InterviewerRating interviewerRating= interviewerRatingRepository.findByActiveAndInterviwerRatingId(true,interviwerRatingId);
        InterviewerRatingResponse interviewerRatingResponse=new InterviewerRatingResponse();
        interviewerRatingResponse.setRateScore(interviewerRating.getRateScore());
        return interviewerRatingResponse;
    }

    @Override
    public InterviewerRatingResponse updateInterviewerRating(Integer interviwerRatingId, InterviewerRatingRequest interviewerRatingRequest) {
        log.info("InterviewerRatingServiceImpl-------------updateInterviewerRating-------------{}",interviwerRatingId,interviewerRatingRequest);
        InterviewerRating interviewerRating=new InterviewerRating();
        interviewerRating.setRateScore(interviewerRatingRequest.getRateScore());
        InterviewerRating update= this.interviewerRatingRepository.save(interviewerRating);
        InterviewerRatingResponse interviewerRatingResponse=interviewerRatingEntityToInterviewerRatingResponse(update);
        return interviewerRatingResponse;
    }


    @Override
    public List<InterviewerRatingResponse> getListInterviewerRating() {
        log.info("InterviewerRatingServiceImpl-------------getListInterviewerRating-------------{}");
        List<InterviewerRating> all = interviewerRatingRepository.findByActive(true);
        List<InterviewerRatingResponse> interviewerRatingResposeList= new ArrayList<>();
        for (InterviewerRating interviewerRating:all) {
            interviewerRatingResposeList.add(interviewerRatingEntityToInterviewerRatingResponse(interviewerRating));

        }
        return interviewerRatingResposeList;
    }

}
