package com.hrms.demo.service;

import com.hrms.demo.model.User;
public interface ResetService {
    void updatePassword(String username, String newPassword);
    User findByUsername(String username);
}
