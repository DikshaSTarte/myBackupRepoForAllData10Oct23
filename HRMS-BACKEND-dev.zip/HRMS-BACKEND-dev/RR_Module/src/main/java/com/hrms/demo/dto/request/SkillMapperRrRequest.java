package com.hrms.demo.dto.request;

import com.hrms.demo.model.RRMaster;
import com.hrms.demo.model.SkillEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SkillMapperRrRequest {
    private Integer skillMapperId;

    private Integer rrId;

    private Integer skillsId;
}
