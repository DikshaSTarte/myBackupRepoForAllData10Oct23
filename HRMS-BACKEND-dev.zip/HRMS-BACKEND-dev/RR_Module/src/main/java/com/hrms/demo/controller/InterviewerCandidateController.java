package com.hrms.demo.controller;

import com.hrms.demo.dto.request.CandidateFeedbackFormRequest;
import com.hrms.demo.dto.request.InterviewerCandidateRequest;

import com.hrms.demo.dto.response.*;
import com.hrms.demo.model.Interviewer;
import com.hrms.demo.model.InterviewerCandidateMapper;
import com.hrms.demo.model.RRMaster;
import com.hrms.demo.repository.InterviewerCandidateRepository;
import com.hrms.demo.service.InterviewerCandidateService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import java.util.List;
@Slf4j
@RestController
@RequestMapping("/api/v1/interviewerCandidateMapper")
public class InterviewerCandidateController {
    @Autowired
    private InterviewerCandidateService interviewerCandidateService;

    @PostMapping("/save")
    public InterviewerCandidateResponse saveCandidateDataForInterviewer(@Valid @RequestBody InterviewerCandidateRequest interviewerCandidateRequest) {
        System.out.println("candidates data save successfully for interviewer... ");
        log.info("InterviewerCandidateController------saveCandidateDataForInterviewer--{}", interviewerCandidateRequest);
        return interviewerCandidateService.saveCandidatesForInterviewer(interviewerCandidateRequest);
    }

    @GetMapping("/get/{interviewerId}")
    public List<InterviewerCandidateResponse> getCandidateDataByInterviewerId(@PathVariable Integer interviewerId) {
        System.out.println("candidates data fetched successfully...");
        log.info("InterviewerCandidateController------getCandidateDataByInterviewerId--{}", interviewerId);
        return this.interviewerCandidateService.getCandidatesByInterviewerId(interviewerId);
    }
    @GetMapping("/get/candidates/{interviewerId}")
    public InterviewerMapperListResponse getCandidateDataByInterviewerId(@PathVariable Integer interviewerId, @RequestParam(value = "pageNumber", defaultValue = "0", required = false) Integer pageNumber,
                                                                         @RequestParam(value = "pageSize", defaultValue = "10", required = false) Integer pageSize,
                                                                         @RequestParam(value = "searchTerm", defaultValue = "", required = false) String searchTerm) {
        System.out.println("candidates data fetched successfully...");
        log.info("InterviewerMapperController------getCandidateDataByInterviewerId--{}", interviewerId);
        return this.interviewerCandidateService.getCandidatesByInterviewerId1(interviewerId, pageNumber, pageSize, searchTerm);
    }

    @GetMapping("/listOfCandidates")
    public List<InterviewerCandidateResponse> getListOfCandidatesForInterviewer() {
        log.info("InterviewerCandidateController------getListOfCandidatesForInterviewer--{}");
        return this.interviewerCandidateService.getAllCandidatesForInterviewer();
    }

    // @PostMapping("/feedback/save")
// public InterviewerFeedbackOnCandidateResponse saveFeedbackByInterviewer(@Valid @RequestBody CandidateFeedbackFormRequest feedbackFormRequest){
// System.out.println("Feedback posted successfully...");
// log.info("InterviewerCandidateController------saveFeedbackByInterviewer--{}",feedbackFormRequest);
// return interviewerCandidateService.saveFeedbackForCandidate(feedbackFormRequest);
// }
    @DeleteMapping("/delete/{interviewerCandidateMapperId}")
    public ResponseEntity<Void> deleteRrId(@PathVariable Integer interviewerCandidateMapperId) {
        interviewerCandidateService.deleteCandidateByinterviewerCandidateMapperId(interviewerCandidateMapperId);
        System.out.println("candidate map to interviewer deleted successfully...");
        log.info("InterviewerCandidateController------deleteRrId--{}", interviewerCandidateMapperId);
        return ResponseEntity.noContent().build();
    }



  /*  @GetMapping("/list/check")
    public ResponseEntity<InterviewerCandMapperListResponse> getShowListInterviewerCandMapper(@RequestParam(value = "pageNumber",defaultValue = "0",required = false) Integer pageNumber,
                                                                                   @RequestParam(value = "pageSize",defaultValue = "10",required = false) Integer pageSize,
                                                                                   @RequestParam(value = "searchTerm",defaultValue = "",required = false)String searchTerm ){
       // log.info("CandidateController------getShowListCandidates--{}");

        InterviewerCandMapperListResponse interviewerCandMapperListResponse=interviewerCandidateService.getListCandidatesOp(pageNumber, pageSize, searchTerm);
        return ResponseEntity.ok(interviewerCandMapperListResponse);
    }*/

}


