package com.hrms.demo.service;

import com.hrms.demo.dto.response.UserResponse;
import com.hrms.demo.dto.response.UserTypeResponse;
import com.hrms.demo.model.UserType;

import java.util.List;

public interface UserTypeService {

    List<UserTypeResponse> getListOfUsers();

}
