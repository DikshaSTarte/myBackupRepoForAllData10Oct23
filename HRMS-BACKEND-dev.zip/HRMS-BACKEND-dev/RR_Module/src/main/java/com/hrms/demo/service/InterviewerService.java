package com.hrms.demo.service;
import com.hrms.demo.dto.request.InterviewerRequest;
import com.hrms.demo.dto.response.CandidateResponse;
import com.hrms.demo.dto.response.InterviewerListResponse;
import com.hrms.demo.dto.response.InterviewerResponse;
import com.hrms.demo.model.Interviewer;

import java.util.List;

public interface InterviewerService {
    InterviewerResponse saveInterviewer(InterviewerRequest interviewerRequest);
    public String deleteInterviewerById(Integer interviewerId);
    InterviewerResponse getInterviewerById(Integer interviewerId);
    InterviewerResponse updateInterviewer(Integer interviewerId,InterviewerRequest interviewerRequest);
    List<InterviewerResponse> getListInterviewer();
    public List<InterviewerResponse> getAllInterviewer(Integer pageNumber, String searchKey);

    InterviewerListResponse getListInterviewersPg(Integer pageNumber, Integer pageSize, String searchTerm);
}
