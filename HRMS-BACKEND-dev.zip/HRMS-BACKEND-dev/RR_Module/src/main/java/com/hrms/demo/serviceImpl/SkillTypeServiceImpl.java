package com.hrms.demo.serviceImpl;

import com.hrms.demo.dto.response.SkillTypeListResponse;
import com.hrms.demo.exceptionHandler.exception.ResourceNotFoundException;
import com.hrms.demo.globleexception.RRAlreadyExistsException;
import com.hrms.demo.globleexception.SkillTypeAlreadyExistException;
import com.hrms.demo.model.*;
import com.hrms.demo.repository.SkillEntityRepository;
import com.hrms.demo.repository.SkillMapperRrRepository;
import com.hrms.demo.repository.SkillTypeEntityRepository;
import com.hrms.demo.dto.request.SkillTypeRequest;
import com.hrms.demo.dto.response.SkillTypeResponse;
import com.hrms.demo.service.SkillTypeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Slf4j
@Service
public class SkillTypeServiceImpl implements SkillTypeService {
    @Autowired
    private SkillTypeEntityRepository skillTypeRepository;
    @Autowired
    private SkillEntityRepository skillEntityRepository;

    @Autowired
    private SkillMapperRrRepository skillMapperRrRepository;
    @Override
    public List<SkillTypeResponse> getAllSkillTypes() {
        log.info("SkillTypeServiceImpl-----------getAllSkillTypes------------{}");
        List<SkillTypeEntity> skillTypes = skillTypeRepository.findByActive(true);
        List<SkillTypeResponse> responses = new ArrayList<>();
        for (SkillTypeEntity skillType : skillTypes) {
            SkillTypeResponse response = new SkillTypeResponse();
           response.setId(skillType.getId());
            response.setSkillTypename(skillType.getSkillTypeName());
            responses.add(response);
        }
        log.info("SkillTypeServiceImpl-----------getAllSkillTypes------------{}");
        return responses;
    }
 @Override
    public SkillTypeEntity createSkillType(SkillTypeRequest skillTypeRequest)  {
        log.info("SkillTypeServiceImpl---------------createSkillType-----------{}",skillTypeRequest);
    Optional<SkillTypeEntity> existSkillType= skillTypeRepository.findByActiveAndSkillTypeName(true,skillTypeRequest.getSkillTypename());
        if(existSkillType.isPresent()){
           // log.error("SkillTypeServiceImpl---------createSkillType---------{}",skillTypeRequest.getSkillTypename(),"skillTypeName already exist");
            throw new SkillTypeAlreadyExistException("skillTypeName already exist");
        }
        SkillTypeEntity skillType = new SkillTypeEntity();
        skillType.setSkillTypeName(skillTypeRequest.getSkillTypename());
        SkillTypeEntity savedSkillType = skillTypeRepository.save(skillType);

        return savedSkillType;
    }
   @Override
    public SkillTypeResponse updateSkillType(Integer id, SkillTypeRequest skillTypeRequest) {
        log.info("SkillTypeServiceImpl-------------updateSkillType-----------{}",id,skillTypeRequest);
        Optional<SkillTypeEntity> skillTypeOptional = skillTypeRepository.findByActiveAndId(true,id);
        if (skillTypeOptional.isPresent()) {
            SkillTypeEntity skillType = skillTypeOptional.get();

            skillType.setSkillTypeName(skillTypeRequest.getSkillTypename());
            SkillTypeEntity savedSkillType = skillTypeRepository.save(skillType);
            SkillTypeResponse response = new SkillTypeResponse();
            response.setId(savedSkillType.getId());
            response.setSkillTypename(savedSkillType.getSkillTypeName());
            return response;
        }
        log.error("SkillTypeServiceImpl----------updateSkillType---------{}",id,"Skill type not found with id ");
        throw new ResourceNotFoundException("Skill type not found with id " + id);
    }
    @Override
    public Page<SkillTypeEntity> searchSkillTypes(String searchKeyword, int pageNo, int pageSize) {
        log.info("SkillTypeServiceImpl----------searchSkillTypes----------{}",searchKeyword,pageNo,pageSize);
        Pageable pageable = PageRequest.of(pageNo, pageSize);
        return skillTypeRepository.findByActiveAndSkillTypeNameIgnoreCaseStartingWithOrderByIdDesc(true,searchKeyword, pageable);
    }
    @Override
    public SkillTypeListResponse getListSkillTypeOp(Integer pageNumber, Integer pageSize, String searchTerm) {
        log.info("SkillTypeServiceImpl-------------getListSkillTypeOp---------{}",pageNumber,pageSize,searchTerm);
        List<SkillTypeEntity> allSkillType;
        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        long totalSkillTypes;

        if (searchTerm != null && !searchTerm.isEmpty()) {
            allSkillType = skillTypeRepository.findBySearchTermAndActive(searchTerm, pageable);
            totalSkillTypes = allSkillType.size(); // Get the count from the list size
        } else {
            Page<SkillTypeEntity> skillTypePage = skillTypeRepository.findByActiveOrderByIdDesc(true,pageable);
            allSkillType = skillTypePage.getContent();
            totalSkillTypes = skillTypeRepository.countByActive(true);  // Get the total count separately
        }

        List<SkillTypeResponse> skillTypeListResponse = new ArrayList<>();
        for (SkillTypeEntity skillTypeEntity : allSkillType) {
            skillTypeListResponse.add(skillTypeEntityToSkillTypeResponse(skillTypeEntity));
        }

        System.out.println("Total SkillType: " + totalSkillTypes);
        log.info("SkillTypeServiceImpl------------getListSkillTypeOp---------{}");
        return new SkillTypeListResponse(totalSkillTypes, skillTypeListResponse);
    }

    private SkillTypeResponse skillTypeEntityToSkillTypeResponse(SkillTypeEntity skillTypeEntity) {
        SkillTypeResponse skillTypeResponse=new SkillTypeResponse();
        skillTypeResponse.setSkillTypename(skillTypeEntity.getSkillTypeName());
        skillTypeResponse.setId(skillTypeEntity.getId());
        return skillTypeResponse;
    }

    @Override
    public void deleteSkillType(Integer id) {
        log.info("SkillTypeServiceImpl-----------deleteSkillType----------{}",id);
        Optional<SkillTypeEntity> skillType = skillTypeRepository.findByActiveAndId(true,id);

        List<RRMaster> rrMasterList=skillMapperRrRepository.findDistinctRrMastersBySkillTypeAndActiveIsTrue(skillType.get());
        if(rrMasterList.size()>0)
        {
            if(rrMasterList.size()==1)
                throw new RRAlreadyExistsException( " RR with the  Role "+skillType.get().getSkillTypeName()+"  already exists ");
            else
                throw new RRAlreadyExistsException( rrMasterList.size()+" RRs with the  Role "+skillType.get().getSkillTypeName()+"  already exists ");
        }
        if (skillType.isPresent()) {
            SkillTypeEntity skillTypeObj = skillType.get();
            skillTypeObj.setActive(false);
            skillTypeRepository.save(skillTypeObj);

            List<SkillEntity> skills = skillTypeObj.getSkills();
            for (SkillEntity skill : skills) {
                skill.setActive(false);
            }
            skillEntityRepository.saveAll(skills);

            System.out.println("SkillType and associated skills successfully deleted.");
        } else {
            log.error("SkillTypeServiceImpl-------------deleteSkillType-----------{}",id,"SkillType not found");
            System.out.println("SkillType not found.");
        }
    }
}
