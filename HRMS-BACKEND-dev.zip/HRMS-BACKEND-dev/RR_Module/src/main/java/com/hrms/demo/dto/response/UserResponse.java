package com.hrms.demo.dto.response;

import lombok.*;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserResponse {
     private Integer userId ;
     private UserTypeResponse userType;
     private String username ;
     private String userFirstName;
     private String userLastName;
     private String userContact ;
     private String userEmailId ;
}
