package com.hrms.demo.controller;

import com.hrms.demo.dto.request.CandidateStatusRequest;
import com.hrms.demo.dto.response.CandidateStatusResponse;
import com.hrms.demo.service.CandidateStatusService;

import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/v1/candidateStatus")
public class CandidateStatusController {
    @Autowired
    private CandidateStatusService candidateStatusService;
    @PostMapping("/save")
    public CandidateStatusResponse SaveCandidateStatusData(@Valid @RequestBody CandidateStatusRequest candidateStatusRequest) {
        return candidateStatusService.saveCandidateStatus(candidateStatusRequest);
    }

    @DeleteMapping("/delete/{candidateStatusId}")
    public ResponseEntity<Void> deleteCandidateStatusData(@PathVariable Integer candidateStatusId) {
        candidateStatusService.deleteCandidateStatusById(candidateStatusId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/list")
    public List<CandidateStatusResponse> getCandidateStatuses() {
        log.info("CandidateStatusController------getCandidateStatuses--{}");
        return this.candidateStatusService.getListCandidateStatus();
    }


    @GetMapping("/get/{candidateStatusId}")
    public CandidateStatusResponse getCandidateStatusById(@PathVariable Integer candidateStatusId) {
        log.info("CandidateStatusController------getCandidateStatusById--{}", candidateStatusId);
        return this.candidateStatusService.getCandidateStatusById(candidateStatusId);
    }

    /*@PutMapping("/update/{candidateStatusId}")
    public ResponseEntity<CandidateStatusResponse> updateCandidateStatusData(@Valid @PathVariable Integer candidateStatusId, @RequestBody CandidateStatusRequest candidateStatusRequest) {
        CandidateStatusResponse candidateStatusResponse = candidateStatusService.updateCandidateStatus(candidateStatusId, candidateStatusRequest);
        if (candidateStatusResponse != null) {
            log.info("CandidateStatusController------updateCandidateStatusData--{}", candidateStatusRequest);
            return ResponseEntity.ok(candidateStatusResponse);
        } else {
            log.error("CandidateStatusController------updateCandidateStatusData--{}", candidateStatusRequest);
            return ResponseEntity.notFound().build();
        }
    }*/
}
