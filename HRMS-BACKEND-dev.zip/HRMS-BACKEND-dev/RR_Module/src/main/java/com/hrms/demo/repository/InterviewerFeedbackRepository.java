package com.hrms.demo.repository;

import com.hrms.demo.model.InterviewerFeedback;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface InterviewerFeedbackRepository  extends JpaRepository<InterviewerFeedback, Integer> {
    InterviewerFeedback findByActiveAndInterviewerFdbkId(boolean active,Integer InterviewerFdbkId);
    List<InterviewerFeedback> findByActive(boolean b);

}
