package com.hrms.demo.globleexception;

public class SkillTypeAlreadyExistException extends RuntimeException {
    public SkillTypeAlreadyExistException(String s) {
        super(s);
    }
}
