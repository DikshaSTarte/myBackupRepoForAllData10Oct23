package com.hrms.demo.dto.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrms.demo.model.Company;
import com.hrms.demo.model.RRStatus;
import com.hrms.demo.model.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;
import java.util.List;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RRMasterResponse {
    private Integer rrMasterId;

    private OwnerResponse ownerId;

    private Integer experience;

    private Integer requiredCount;

    private RRStatus rrStatus;
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate startDate ;
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate endDate;

    private Company company ;
    private List<SkillResponse> skillsId;
    private FileUploadeResponse fileId;
    private Integer rrAlertFlag;
}
