package com.hrms.demo.serviceImpl;

import com.hrms.demo.dto.request.RRForUserRequest;
import com.hrms.demo.dto.response.*;
import com.hrms.demo.model.*;
import com.hrms.demo.repository.RRMasterRepository;
import com.hrms.demo.repository.SkillMapperRrRepository;
import com.hrms.demo.repository.UserRepository;
import com.hrms.demo.repository.UserRrMapperRepository;
import com.hrms.demo.service.UserRrMapperService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Slf4j
@Service
public class UserRrMapperServiceImpl implements UserRrMapperService {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private RRMasterRepository rrMasterRepository;
    @Autowired
    private UserRrMapperRepository userRrMapperRepository;
    @Autowired
    private SkillMapperRrRepository skillMapperRrRepository ;
    @Override
    public List<UserRrMapperResponse> getRrByUserId(Integer userId) {
        log.info("UserRrMapperServiceImpl---------------getRrByUserId----------{}",userId);
        List<UserRrMapperResponse> rrList = new ArrayList<>();
        User user = userRepository.findById(userId).get();
        List<UserRRMapper> rrMapperList = userRrMapperRepository.findByActiveAndUserId(true,user);
        for (UserRRMapper userRRMapper : rrMapperList) {

            UserRrMapperResponse userRrMapperResponse = new UserRrMapperResponse();
            userRrMapperResponse.setRrId(userRRMapper.getRrId());
            userRrMapperResponse.setUserId(userRRMapper.getUserId());
            rrList.add(userRrMapperResponse);
        }
        log.info("UserRrMapperServiceImpl---------------getRrByUserId----------{}",userId);
        return rrList;
    }
    @Override
    public List<UserRRMapper> saveRrForUser(RRForUserRequest userRequest) {
        log.info("UserRrMapperServiceImpl--------------saveRrForUser------------{}",userRequest);
        Optional<User> user = userRepository.findById(userRequest.getUserId());
        List<UserRRMapper> userRRMapperList = new ArrayList<>();
        for (Integer rrId : userRequest.getRrId()){
            Optional<RRMaster> rrMaster = rrMasterRepository.findById(rrId);
            UserRRMapper userRRMapper = new UserRRMapper();
            userRRMapper.setUserId(user.get());
            userRRMapper.setRrId(rrMaster.get());
            userRRMapperList.add(userRRMapper);
        }
        List<UserRRMapper> rrMapperList = userRrMapperRepository.saveAll(userRRMapperList);
        log.info("UserRrMapperServiceImpl--------------saveRrForUser------------{}",userRequest);
        return rrMapperList;
    }
}