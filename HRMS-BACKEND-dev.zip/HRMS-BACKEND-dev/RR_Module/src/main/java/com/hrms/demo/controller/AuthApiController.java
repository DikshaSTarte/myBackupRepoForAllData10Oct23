package com.hrms.demo.controller;

import com.hrms.demo.constants.ErrorCodes;
import com.hrms.demo.dto.request.AuthRequest;
import com.hrms.demo.dto.response.JwtResponse;
import com.hrms.demo.model.User;
import com.hrms.demo.repository.UserRepository;
import com.hrms.demo.util.JwtTokenUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;
@Slf4j
@RestController
public class AuthApiController {
    @Autowired
    AuthenticationManager authManager;
    @Autowired
    JwtTokenUtil jwtUtil;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/api/v1/auth/login")
    public ResponseEntity<?> login(@RequestBody AuthRequest request) {
log.info("AuthApiController-------------login----------{}",request);
        userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new UsernameNotFoundException(ErrorCodes.USER_NAME_NOT_FOUND));

        Authentication authentication = authManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getUsername(), request.getPassword())
        );

        if (authentication == null) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put(ErrorCodes.ERROR, ErrorCodes.LOGIN_FAILED);
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorResponse);
        }

        User user = (User) authentication.getPrincipal();
        String accessToken = jwtUtil.generateAccessToken(user);
        String refreshToken = jwtUtil.generateRefreshToken(accessToken);
        JwtResponse response = new JwtResponse(accessToken, refreshToken);

        return ResponseEntity.ok().body(response);

    }


}