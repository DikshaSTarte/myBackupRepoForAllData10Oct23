package com.hrms.demo.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="rrCandidateMapper")
public class RRCandidateMapper extends BaseEntity {
    /*@Id
    @GeneratedValue(strategy = GenerationType.AUTO)*/
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "rrCandidateMapper_generator")
    @SequenceGenerator(name = "rrCandidateMapper_generator", sequenceName = "rrCandidateMapper_SEQUENCE", initialValue = 4323, allocationSize = 1)
    @Column(name ="rrCandidateMapperId")
    private Integer rrCandidateMapperId;
    @ManyToOne
    @JoinColumn(name = "rrId")
    private RRMaster rrId;
    @ManyToOne
    @JoinColumn(name = "candidateId")
    private Candidate candidateId;

    @ManyToOne
    @JoinColumn(name = "candidateStatusId")
    private CandidateStatus candidateStatus;


}
