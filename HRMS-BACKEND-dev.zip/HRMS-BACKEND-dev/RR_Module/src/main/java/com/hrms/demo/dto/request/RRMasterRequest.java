package com.hrms.demo.dto.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hrms.demo.dto.response.RRStatusResponse;
import com.hrms.demo.dto.response.SkillTypeResponse;
import com.hrms.demo.model.RRStatus;
import com.hrms.demo.model.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.validation.constraints.NotBlank;
import java.time.LocalDate;
import java.util.List;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RRMasterRequest {
    private Integer ownerId;
    private Integer experience;
    private Integer requiredCount;
    private Integer rrStatus;
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate startDate ;
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate endDate ;
    private List<Integer> skillsets;
    private Integer fileId;
    private Integer company;
}
