package com.hrms.demo.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name="save_Email")
@AllArgsConstructor
@NoArgsConstructor
public class SaveEmail {
//    @GeneratedValue(strategy = GenerationType.AUTO)
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "save_Email_generator")
    @SequenceGenerator(name = "save_Email_generator", sequenceName = "save_Email_SEQUENCE", initialValue = 1001, allocationSize = 1)
    @Column(name = "id")
    private Integer savingId;

    @Column(name = "Email_receiver")
    private String receiver;

    @Column(name = "email_body" ,length = 2000)
// @Size(min=255 ,max=1000)
    private String emailBody;

    @Column(name = "is_send", columnDefinition = "boolean default false")
    private Boolean isSend;

    @Column(name = "time_of_Sending")
    LocalDateTime timeOfSending;

    @Column(name = "Email_subject")
    String subjectForEmail;

    @Column(name = "File_pathJD")
    private String filePathJd;

    @Column(name = "Receiver_Name")
    private String ReceiverName;

    @Column(name = "File_pathRM")
    private String filePathRm;
}
