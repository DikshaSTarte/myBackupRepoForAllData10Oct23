package com.hrms.demo.model;

import javax.persistence.*;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "rr_status")

public class RRStatus extends BaseEntity {
   @Id
   @GeneratedValue(strategy = GenerationType.AUTO)
   private Integer rrStatusId;

   @Column(name = "status")
   private String rrStatusName;

}

