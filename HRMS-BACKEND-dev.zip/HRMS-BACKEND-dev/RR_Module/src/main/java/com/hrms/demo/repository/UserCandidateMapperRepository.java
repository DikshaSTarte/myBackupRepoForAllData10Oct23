package com.hrms.demo.repository;

import com.hrms.demo.model.User;
import com.hrms.demo.model.UserCandidateMapper;
import com.hrms.demo.model.UserRRMapper;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserCandidateMapperRepository extends JpaRepository<UserCandidateMapper,Integer> {
    List<UserCandidateMapper> findByActiveAndUserId(boolean b , User userId);
}
