package com.hrms.demo.model;

import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="interviewerFeedback")
@AllArgsConstructor
@NoArgsConstructor
public class InterviewerFeedback extends BaseEntity{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "interviewerFdbkId")
    private Integer interviewerFdbkId;
    @Column(name = "interviewerFdbkRatings")
    private Integer interviewerFdbkRatings;
    @Column(name = "interviewerFdbkDescp")
    private String interviewerFdbkDescp;
    @ManyToOne
    private Candidate candidateDetails;
}
