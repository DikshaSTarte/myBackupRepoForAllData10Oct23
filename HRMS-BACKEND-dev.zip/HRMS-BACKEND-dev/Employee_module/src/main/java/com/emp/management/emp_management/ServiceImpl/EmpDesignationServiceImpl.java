package com.emp.management.emp_management.ServiceImpl;

import com.emp.management.emp_management.DTO.Response.DesignationResponse;
import com.emp.management.emp_management.Repository.EmpDesignationRepository;
import com.emp.management.emp_management.Service.EmpDesignationService;
import com.emp.management.emp_management.model.EmpDesignation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class EmpDesignationServiceImpl implements EmpDesignationService {
    @Autowired
    EmpDesignationRepository empDesignationRepository;

    @Override
    public List<DesignationResponse> getDesignationsListByDeptId(Integer departmentId){
        List<DesignationResponse> designationResponseList=new ArrayList<>();
        List<EmpDesignation> empDesignationList=empDesignationRepository.findAllByActiveAndEmpDepartment_empDepartmentId(true,departmentId);
        for(EmpDesignation empDesignation:empDesignationList)
        {
            DesignationResponse designationResponse=new DesignationResponse();
            designationResponse.setEmpDesignationId(empDesignation.getEmpDesignationId());
            designationResponse.setEmpDesignationName(empDesignation.getEmpDesignationName());
            designationResponseList.add(designationResponse);
        }
        return designationResponseList;
    }

}
