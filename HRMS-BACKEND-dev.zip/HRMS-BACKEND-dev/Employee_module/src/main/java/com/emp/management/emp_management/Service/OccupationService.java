package com.emp.management.emp_management.Service;

import com.emp.management.emp_management.DTO.Response.OccupationResponse;

import java.util.List;

public interface OccupationService {
    List<OccupationResponse> listOccupation();

}
