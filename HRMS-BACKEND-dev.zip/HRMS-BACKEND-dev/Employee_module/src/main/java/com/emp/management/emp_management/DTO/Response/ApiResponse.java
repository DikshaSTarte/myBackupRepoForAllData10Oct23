package com.emp.management.emp_management.DTO.Response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ApiResponse {
    private String message;
    private Boolean success;
    private String fileName;
    private String documentype;

    public ApiResponse(String message,Boolean success){
        this.message=message;
        this.success=success;
    }
}
