package com.emp.management.emp_management.Service;

import com.emp.management.emp_management.DTO.Request.EmployeePreCompanyRequest;
import com.emp.management.emp_management.DTO.Response.EmployeePreCompanyResponse;

import java.util.List;

public interface EmployeePreCompanyService {
    EmployeePreCompanyResponse saveEmployeePreCompany(EmployeePreCompanyRequest employeePreCompanyRequest);


    List<EmployeePreCompanyResponse> listEmployeePreCompany();

    String deleteEmpPreCompanyById(Integer empPreCompanyId);

    EmployeePreCompanyResponse updateEmployeePreCompanyById(Integer empPreCompanyId, EmployeePreCompanyRequest employeePreCompanyRequest);

}
