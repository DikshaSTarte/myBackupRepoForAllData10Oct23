package com.emp.management.emp_management.DTO.Request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SkillRequest {
    private Integer employeeId;
    private List<String> skillSets ;
}
