package com.emp.management.emp_management.DTO.Response;

import com.emp.management.emp_management.model.ContactDetails;
import com.emp.management.emp_management.model.EmpDesignation;
import com.emp.management.emp_management.model.EmployeeAddress;
import com.emp.management.emp_management.model.EmployeeBasicDetails;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmpResponse {

    private Integer employeeId;
    private String empFirstName;
    private String empMiddleName;
    private String empLastName;


}
