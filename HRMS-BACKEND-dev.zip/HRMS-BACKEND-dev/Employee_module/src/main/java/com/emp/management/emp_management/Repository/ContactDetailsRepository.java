package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.ContactDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContactDetailsRepository extends JpaRepository<ContactDetails,Integer> {


    ContactDetails findByActiveAndEmployee_EmployeeId(boolean b, Integer employeeId);
}
