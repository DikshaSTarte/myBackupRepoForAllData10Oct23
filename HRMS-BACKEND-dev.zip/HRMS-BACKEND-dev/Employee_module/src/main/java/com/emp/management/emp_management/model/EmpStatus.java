package com.emp.management.emp_management.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "employee_status")
@AllArgsConstructor
@NoArgsConstructor
public class EmpStatus extends BaseEntity{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "employee_status_id")
    private Integer employeeStatusId;

    @Column(name = "emp_status_name")
    private String empStatusName;
}
