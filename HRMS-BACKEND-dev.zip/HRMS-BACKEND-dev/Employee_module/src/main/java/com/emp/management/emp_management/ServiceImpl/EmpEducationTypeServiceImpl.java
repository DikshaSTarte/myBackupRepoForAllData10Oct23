package com.emp.management.emp_management.ServiceImpl;

import com.emp.management.emp_management.DTO.Response.BloodGroupResponse;
import com.emp.management.emp_management.DTO.Response.EduTypeResponse;
import com.emp.management.emp_management.DTO.Response.EnumResponse;
import com.emp.management.emp_management.Repository.EmpEducationTypeRepository;
import com.emp.management.emp_management.Service.EmpEducationTypeService;
import com.emp.management.emp_management.mapper.ListingMapper;
import com.emp.management.emp_management.model.EmpBloodGroup;
import com.emp.management.emp_management.model.EmployeeEducationType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
@Service
public class EmpEducationTypeServiceImpl implements EmpEducationTypeService {
    @Autowired
    private ListingMapper listingMapper;
    @Autowired
    private EmpEducationTypeRepository empEducationTypeRepository;
    @Override
//    public List<EduTypeResponse> getEducationTypeList() {
//        List<EmployeeEducationType> types = empEducationTypeRepository.findByActive(true);
//        return listingMapper.eduTypeGroupListMapper(types);
//    }
    public List<EduTypeResponse> getEducationTypeList() {
        List<EmployeeEducationType> all = empEducationTypeRepository.findByActive(true);
        List<EduTypeResponse> typeResponseList = new ArrayList<>();
        for (EmployeeEducationType type : all) {
            typeResponseList.add(eduTypeEntityToEduTypeResponse(type));
        }
        return typeResponseList;
    }
    private EduTypeResponse eduTypeEntityToEduTypeResponse(EmployeeEducationType type) {
        EduTypeResponse response = new EduTypeResponse();
        response.setEduTypeId(type.getEmpEducationTypeId());
        response.setEduTypeName(type.getEmpEducationName());

        return response;
    }
}
