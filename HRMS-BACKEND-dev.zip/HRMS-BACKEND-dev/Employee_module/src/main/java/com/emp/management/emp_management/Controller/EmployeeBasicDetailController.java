package com.emp.management.emp_management.Controller;

import com.emp.management.emp_management.DTO.Request.EmployeeSaveRequest;
import com.emp.management.emp_management.DTO.Response.EmployeeBasicDetailDtoResponse;
import com.emp.management.emp_management.DTO.Response.EmployeeBasicDetailsResponse;
import com.emp.management.emp_management.Service.EmployeeBasicDetailsService;
import com.emp.management.emp_management.Service.EmployeeService;
import com.emp.management.emp_management.model.EmployeeBasicDetails;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/v1/employee/BasicDetails")
public class EmployeeBasicDetailController {

    @Autowired
    private EmployeeBasicDetailsService employeeBasicDetailsService;

    @PostMapping("/save")
    public EmployeeBasicDetailsResponse SaveEmployeeData(@Validated @RequestBody EmployeeSaveRequest employeeSaveRequest) {
        log.info("employeeController----------SaveEmployeeData----------{}",employeeSaveRequest);
        return employeeBasicDetailsService.saveEmployeeBasicDetails(employeeSaveRequest);

    }

    @GetMapping("/list/{employeeId}")
    public List<EmployeeBasicDetailDtoResponse> getEmployeeBasicDetailListByEmpId(@PathVariable Integer employeeId){
        return this.employeeBasicDetailsService.getEmployeeBasicDetailByEmpId(employeeId);
}


    @GetMapping("/list1/{employeeId}")
    public List<EmployeeBasicDetailDtoResponse> getEmployeeBasicDetailListByEmpId1(@PathVariable Integer employeeId){
        return this.employeeBasicDetailsService.getEmployeeBasicDetailByEmpId(employeeId);
    }



    @PutMapping("/update/{employeeId}")
    public EmployeeBasicDetailsResponse updateEmployeeBasicDetails(@PathVariable Integer employeeId,@Validated @RequestBody EmployeeSaveRequest employeeSaveRequest) {
        log.info("employeeController----------updateEmployeeData----------{}",employeeSaveRequest);
        return employeeBasicDetailsService.updateEmployeeBasicDetails(employeeId,employeeSaveRequest);
    }

}
