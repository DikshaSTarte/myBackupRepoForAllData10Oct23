package com.emp.management.emp_management.Service;

import com.emp.management.emp_management.DTO.Request.SkillRequest;

import com.emp.management.emp_management.DTO.Request.SkillUpdateRequest;
import com.emp.management.emp_management.DTO.Response.EmployeeSkillDTO;
import com.emp.management.emp_management.DTO.Response.SkillResponse;
import com.emp.management.emp_management.DTO.Response.SkillUpdateResponse;

import java.util.List;

public interface EmployeeSkillSetService {
    SkillResponse saveSkills(SkillRequest request);
    List<EmployeeSkillDTO> getSkillsByEmpId(Integer empId);
    SkillUpdateResponse editEmployeeSkills(Integer empId, SkillUpdateRequest request);
}
