
package com.emp.management.emp_management.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "emp_marital_status")
@AllArgsConstructor
@NoArgsConstructor
public class EmpMaritalStatus extends  BaseEntity{

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "emp_marital_status_id")
    private Integer empMaritalStatusId;

    @Column(name = "emp_marital_status_name")
    private String empMaritalStatusName;



    // Other relationships

}


