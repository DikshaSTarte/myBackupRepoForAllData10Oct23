package com.emp.management.emp_management.globalException;

public class SkillSetAlreadyExistException extends RuntimeException{
    public  SkillSetAlreadyExistException(String s){
        super(s);
    }
}
