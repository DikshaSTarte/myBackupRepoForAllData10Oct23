package com.emp.management.emp_management.DTO.Response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import springfox.documentation.service.ApiListing;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EducationDetailDTO {
    private Integer empEduDetailsId;
    private EduTypeResponse educationType;
    private String instituteName;
    private float marks;
    private CourseResponse course;
    private SpecializationResponse specialization;
    private String universityName;
    private String yearOfPassing;
    private String district;
    private MediumResponse medium;
    private LearningTypeResponse courseType;
    private GradingResponse gradingSystem;
}

