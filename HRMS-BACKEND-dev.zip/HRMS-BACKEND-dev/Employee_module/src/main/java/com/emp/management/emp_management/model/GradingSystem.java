package com.emp.management.emp_management.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "grading_system")
@AllArgsConstructor
@NoArgsConstructor
public class GradingSystem extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "gradeId")
    private Integer gradeId;
    @Column(name = "gradeName")
    private String gradeName;
}
