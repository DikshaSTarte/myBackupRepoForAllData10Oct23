package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.Courses;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface CourseRepository extends JpaRepository<Courses,Integer> {

    List<Courses> findByActive(boolean b);
    List<Courses> findByActiveAndEmployeeEducationType_empEducationTypeId(boolean b, Integer employeeEducationType);

    Courses findByActiveAndCourseId(boolean b, Integer courseId);

    Optional<Courses> findByActiveAndCourseIdAndEmployeeEducationType_empEducationTypeId(boolean b, Integer courseId, Integer empTypeId);
}
