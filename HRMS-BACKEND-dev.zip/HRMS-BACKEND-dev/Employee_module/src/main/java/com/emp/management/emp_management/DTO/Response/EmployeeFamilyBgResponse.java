package com.emp.management.emp_management.DTO.Response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeFamilyBgResponse {
    private Integer empFamilyBgId;
    private EmployeeDTO employee;
    private OccupationResponse occupation;
    private EduTypeResponse eduType;
    private String empFamilyMemberFirstName;
    private String empFamilyMemberLastName;
    private String empFmRelation;
    private String empFmContact;
    private Date empFmDob;

}
