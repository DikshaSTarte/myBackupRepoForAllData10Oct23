package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.EmployeeAddress;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmployeeAddressRepository extends JpaRepository<EmployeeAddress, Integer> {

    EmployeeAddress findByActiveAndEmployee_EmployeeIdAndEmpAddType_EmpAddTypeId(boolean b, Integer employeeId, Integer empAddressTypeId);

    List<EmployeeAddress> findByActiveAndEmployee_EmployeeId(boolean b, Integer employeeId);


}
