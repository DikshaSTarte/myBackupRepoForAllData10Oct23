package com.emp.management.emp_management.DTO.Request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EducationRequest {
    private Integer employeeId;
    private Integer educationTypeId;
    private Integer course;
    private Integer learningType;
    private Integer specialization;
    private Integer medium;
    private Integer gradesId;
    private String instituteName;
    private String universityName;
    private String district;
    private String yearOfPassing;
    private float marks ;
}
