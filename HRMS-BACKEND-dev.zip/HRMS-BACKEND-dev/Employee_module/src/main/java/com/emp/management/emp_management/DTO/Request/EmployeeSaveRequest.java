package com.emp.management.emp_management.DTO.Request;


import com.emp.management.emp_management.model.EmpBloodGroup;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeSaveRequest {
   private String empFirstName;
   private String empMiddleName;
   private String empLastName;
   private String empEmailAddress;
   private String empPhoneNumber;
   private Integer empStatus;
   private LocalDate empDoj;
   private String empOrganizationalMail;
   private String empTelephoneNumber;
   private String empFormerName;
   private Integer empBloodGroupId;
   private String empPassportNumber;
   private Integer empDesignationId;
//   private Integer empDepartmentId;
   private String empPanNumber;
   private String empUanNumber;
   private String empGender;
   private LocalDate empDob;
   private String empNationality;
   private Integer empMarritalStatusId;
   private LocalDate empDoa;
   private String empDrLicenceNumber;
   private Float empTotalExperience;
   private String empCurrentWorkingLocation;
   private List<EmpAddressRequest> empAddressRequestList;
//  private String empDetailedAddress;
//  private Integer EmpAddressTypeId;
//   private Integer empAddPincode;
//   private String empAddLandMark;

}
