package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.EducationMedium;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MediumRepository extends JpaRepository<EducationMedium,Integer> {

    List<EducationMedium> findByActive(boolean b);
}
