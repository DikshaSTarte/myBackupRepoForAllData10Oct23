package com.emp.management.emp_management.DTO.Request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeFamilyBgRequest {
    private Integer employeeId;
    private Integer occupationId;
    private Integer empEducationTypeId;
    @NotBlank(message = "empFamilyMemberFirstName must not be blank.")
    @Pattern(regexp = "^[a-zA-Z ]+$", message = "empFamilyMemberFirstName can only contain letters and spaces.")
    private String empFamilyMemberFirstName;

    @NotBlank(message = "empFamilyMemberFirstName must not be blank.")
    @Pattern(regexp = "^[a-zA-Z ]+$", message = "empFamilyMemberFirstName can only contain letters and spaces.")
    private String empFamilyMemberLastName;

    @NotBlank(message = "Family relation cannot be blank")
    private String empFmRelation;

    @NotBlank(message = "EmployeeFamilyMemberContact number is required")
    @Pattern(regexp = "\\d{10}", message = "EmployeeFamilyMemberContact number must be a 10-digit number")
    private String empFmContact;

    @Past(message = "Date of birth must be in the past")
    private Date empFmDob;


}
