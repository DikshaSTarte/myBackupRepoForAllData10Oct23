package com.emp.management.emp_management.model;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "contactDetails")
@AllArgsConstructor
@NoArgsConstructor
public class ContactDetails extends  BaseEntity{

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "contact_id")
    private Integer contactId;

    @OneToOne
    @JoinColumn(name = "employee_id")
    private Employee employee;

    @Column(name = "phone_number")
    private String phoneNumber;

    @Column(name = "telephone_number")
    private String telephoneNumber;

    @Column(name = "personal_email")
    private String personalEmail;

    @Column(name = "organizational_email")
    private String OrganizationalEmail;
}
