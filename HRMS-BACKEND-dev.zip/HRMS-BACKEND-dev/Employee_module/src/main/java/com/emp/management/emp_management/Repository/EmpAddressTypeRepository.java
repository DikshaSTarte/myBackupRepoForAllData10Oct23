package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.EmpAddressType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmpAddressTypeRepository extends JpaRepository< EmpAddressType, Integer> {
    EmpAddressType findByActiveAndEmpAddTypeId(boolean b, Integer empAddressTypeId);
}
