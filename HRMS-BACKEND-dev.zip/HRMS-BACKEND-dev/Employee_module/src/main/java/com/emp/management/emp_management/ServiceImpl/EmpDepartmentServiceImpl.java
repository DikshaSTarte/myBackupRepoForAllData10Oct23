package com.emp.management.emp_management.ServiceImpl;

import com.emp.management.emp_management.DTO.Response.DepartmentResponse;
import com.emp.management.emp_management.Repository.EmpDepartmentRepository;
import com.emp.management.emp_management.Service.EmpDepartmentService;
import com.emp.management.emp_management.model.EmpDepartment;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class EmpDepartmentServiceImpl implements EmpDepartmentService {

    @Autowired
    EmpDepartmentRepository empDepartmentRepository;

    @Override
   public List<DepartmentResponse> getListDepartments()
    {
         List<DepartmentResponse> departmentResponseList=new ArrayList<>();
        List<EmpDepartment> empDepartmentList = empDepartmentRepository.findAllByActiveOrderByEmpDepartmentIdDesc(true);
         for(EmpDepartment empDepartment:empDepartmentList)
         {
             DepartmentResponse departmentResponse=new DepartmentResponse();
             departmentResponse.setEmpDepartmentId(empDepartment.getEmpDepartmentId());
             departmentResponse.setEmpDepartmentName(empDepartment.getEmpDepartmentName());
             departmentResponseList.add(departmentResponse);
         }
         return departmentResponseList;
    }
}
