package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.EmpDesignation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmpDesignationRepository extends JpaRepository<EmpDesignation,Integer> {
    EmpDesignation findByActiveAndEmpDesignationId(boolean b, Integer empDesignationId);

    List<EmpDesignation> findAllByActiveAndEmpDepartment_empDepartmentId(boolean b, Integer departmentId);
}
