package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.EmployeeFamilyBg;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmployeeFamilyBgRepository extends JpaRepository<EmployeeFamilyBg,Integer> {
    List<EmployeeFamilyBg> findByActiveOrderByCreatedOnAsc(boolean b);

    EmployeeFamilyBg findByActiveAndEmpFamilyBgId(boolean b, Integer empFamilyBgId);

    List<EmployeeFamilyBg> findByActiveAndEmployee_EmployeeId(boolean b, Integer employeeId);

//    EmployeeFamilyBg findByActiveAndEmployeeId(boolean b,Integer employeeId);


}
