package com.emp.management.emp_management.DTO.Response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SchoolResponse {
    private EmployeeDTO employeeId;
    private EduTypeResponse educationTypeId;
    private CourseResponse course;
    private LearningTypeResponse learningType;
    private MediumResponse medium;
    //    private Integer gradesId;
    private String instituteName;
    private String universityName;
    private String district;
    private String yearOfPassing;
    private float marks ;
}
