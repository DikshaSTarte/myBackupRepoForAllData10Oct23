package com.emp.management.emp_management.ServiceImpl;

import com.emp.management.emp_management.DTO.Request.EmployeeFamilyBgRequest;
import com.emp.management.emp_management.DTO.Response.*;
import com.emp.management.emp_management.Repository.EmpEducationTypeRepository;
import com.emp.management.emp_management.Repository.EmployeeFamilyBgRepository;
import com.emp.management.emp_management.Repository.EmployeeRepository;
import com.emp.management.emp_management.Repository.OccupationRepository;
import com.emp.management.emp_management.Service.EmployeeFamilyBgService;
import com.emp.management.emp_management.model.Employee;
import com.emp.management.emp_management.model.EmployeeEducationType;
import com.emp.management.emp_management.model.EmployeeFamilyBg;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Slf4j
@Service
public class EmployeeFamilyBgServiceImpl implements EmployeeFamilyBgService {
    @Autowired
    private EmployeeRepository employeeRepository;
    @Autowired
    private EmployeeFamilyBgRepository employeeFamilyBgRepository;
    @Autowired
    private OccupationRepository occupationRepository;
    @Autowired
    private EmpEducationTypeRepository empEducationTypeRepository;

    @Override
    public EmployeeFamilyBgResponse saveEmployeeFamilyBg(EmployeeFamilyBgRequest employeeFamilyBgRequest) {
        log.info("EmployeeFamilyBgServiceImpl-----------saveEmployeeFamilyBg--------{}",employeeFamilyBgRequest);
        EmployeeFamilyBg employeeFamilyBg=new EmployeeFamilyBg();
        employeeFamilyBg.setEmployee(employeeRepository.findByActiveAndEmployeeId(true,employeeFamilyBgRequest.getEmployeeId()));
        employeeFamilyBg.setOccupation(occupationRepository.findByActiveAndOccupationId(true,employeeFamilyBgRequest.getOccupationId()));
        Optional<EmployeeEducationType> employeeEducationType =empEducationTypeRepository.findByActiveAndEmpEducationTypeId(true,employeeFamilyBgRequest.getEmpEducationTypeId());
        employeeFamilyBg.setEduType(employeeEducationType.get());
        employeeFamilyBg.setEmpFamilyMemberFirstName(employeeFamilyBgRequest.getEmpFamilyMemberFirstName());
        employeeFamilyBg.setEmpFamilyMemberLastName(employeeFamilyBgRequest.getEmpFamilyMemberLastName());
        employeeFamilyBg.setEmpFmContact(employeeFamilyBgRequest.getEmpFmContact());
        employeeFamilyBg.setEmpFmDob(employeeFamilyBgRequest.getEmpFmDob());

        employeeFamilyBg.setEmpFmRelation(employeeFamilyBgRequest.getEmpFmRelation());

        EmployeeFamilyBg saveEmployeeFamilyBg=this.employeeFamilyBgRepository.save(employeeFamilyBg);
        EmployeeFamilyBgResponse employeeFamilyBgResponse=employeeFamilyBgEntityToEmployeeFamilyBgResponse(saveEmployeeFamilyBg);
        //     employeeFamilyBgResponse.setEmployee(new EmployeeResponse(employeeFamilyBg.getEmployee().getEmployeeId(),employeeFamilyBg.getEmployee().getEmpFirstName(),employeeFamilyBg.getEmployee().getEmpLastName(),employeeFamilyBg.getEmployee().getEmpDep(),employeeFamilyBg.getEmployee().getEmpDesignation()));
        return employeeFamilyBgResponse;
    }

    @Override
    public List<EmployeeFamilyBgResponse> listEmployeeFamilyBg() {
        List<EmployeeFamilyBg> employeeFamilyBgs=employeeFamilyBgRepository.findByActiveOrderByCreatedOnAsc(true);
        List<EmployeeFamilyBgResponse> employeeFamilyBgResponseList = new ArrayList<>();
        for (EmployeeFamilyBg employeeFamilyBg : employeeFamilyBgs) {
            employeeFamilyBgResponseList.add(employeeFamilyBgEntityToEmployeeFamilyBgResponse(employeeFamilyBg));
        }
        return employeeFamilyBgResponseList;

    }

    @Override
    public String deleteEmpFamilyMemberById(Integer empFamilyBgId) {

        Optional<EmployeeFamilyBg> employeeFamilyBg = employeeFamilyBgRepository.findById(empFamilyBgId);
        employeeFamilyBg.get().setActive(false);
        employeeFamilyBgRepository.save(employeeFamilyBg.get());

        return "EmployeeFamilyMember Successfully Deleted";
    }

    @Override
    public EmployeeFamilyBgResponse updateEmployeeFamilyBg(Integer empFamilyBgId, EmployeeFamilyBgRequest employeeFamilyBgRequest) {
        EmployeeFamilyBg employeeFamilyBg=employeeFamilyBgRepository.findByActiveAndEmpFamilyBgId(true,empFamilyBgId);
        employeeFamilyBg.setEmployee(employeeRepository.findByActiveAndEmployeeId(true,employeeFamilyBgRequest.getEmployeeId()));
        employeeFamilyBg.setOccupation(occupationRepository.findByActiveAndOccupationId(true,employeeFamilyBgRequest.getOccupationId()));
        Optional<EmployeeEducationType> employeeEducationType =empEducationTypeRepository.findByActiveAndEmpEducationTypeId(true,employeeFamilyBgRequest.getEmpEducationTypeId());
        employeeFamilyBg.setEduType(employeeEducationType.get());
        employeeFamilyBg.setEmpFamilyMemberFirstName(employeeFamilyBgRequest.getEmpFamilyMemberFirstName());
        employeeFamilyBg.setEmpFamilyMemberLastName(employeeFamilyBgRequest.getEmpFamilyMemberLastName());
        employeeFamilyBg.setEmpFmContact(employeeFamilyBgRequest.getEmpFmContact());
        employeeFamilyBg.setEmpFmDob(employeeFamilyBgRequest.getEmpFmDob());

        employeeFamilyBg.setEmpFmRelation(employeeFamilyBgRequest.getEmpFmRelation());

        EmployeeFamilyBg update=this.employeeFamilyBgRepository.save(employeeFamilyBg);
        EmployeeFamilyBgResponse employeeFamilyBgResponse=employeeFamilyBgEntityToEmployeeFamilyBgResponse(update);
        return employeeFamilyBgResponse;
    }

    @Override
    public List<EmployeeFamilyBgResponse> getEmployeeFamilyBgByEmpId(Integer employeeId) {
        List<EmployeeFamilyBgResponse> employeeFamilyBgResponseList=new ArrayList<>();
        Employee employee= employeeRepository.findByActiveAndEmployeeId(true,employeeId);
        List<EmployeeFamilyBg> employeeFamilyBgList=employeeFamilyBgRepository.findByActiveAndEmployee_EmployeeId(true,employee.getEmployeeId());
        for (EmployeeFamilyBg employeeFamilyBg:employeeFamilyBgList){
         EmployeeFamilyBgResponse employeeFamilyBgResponse=new EmployeeFamilyBgResponse();
         employeeFamilyBgResponse.setEmployee(new EmployeeDTO(employeeFamilyBg.getEmployee().getEmployeeId(),employeeFamilyBg.getEmployee().getEmpFirstName(),employeeFamilyBg.getEmployee().getEmpLastName()));
         employeeFamilyBgResponse.setOccupation(new OccupationResponse(employeeFamilyBg.getOccupation().getOccupationId(),employeeFamilyBg.getOccupation().getOccupationName()));
         employeeFamilyBgResponse.setEduType(new EduTypeResponse(employeeFamilyBg.getEduType().getEmpEducationTypeId(),employeeFamilyBg.getEduType().getEmpEducationName()));
         employeeFamilyBgResponse.setEmpFamilyBgId(employeeFamilyBg.getEmpFamilyBgId());
         employeeFamilyBgResponse.setEmpFamilyMemberFirstName(employeeFamilyBg.getEmpFamilyMemberFirstName());
         employeeFamilyBgResponse.setEmpFamilyMemberLastName(employeeFamilyBg.getEmpFamilyMemberLastName());
         employeeFamilyBgResponse.setEmpFmContact(employeeFamilyBg.getEmpFmContact());
         employeeFamilyBgResponse.setEmpFmDob(employeeFamilyBg.getEmpFmDob());
         employeeFamilyBgResponse.setEmpFmRelation(employeeFamilyBg.getEmpFmRelation());

        employeeFamilyBgResponseList.add(employeeFamilyBgResponse);
      }
        return employeeFamilyBgResponseList;
    }


    EmployeeFamilyBgResponse employeeFamilyBgEntityToEmployeeFamilyBgResponse(EmployeeFamilyBg employeeFamilyBg) {
        EmployeeFamilyBgResponse employeeFamilyBgResponse=new EmployeeFamilyBgResponse();
        employeeFamilyBgResponse.setEmpFamilyBgId(employeeFamilyBg.getEmpFamilyBgId());
        employeeFamilyBgResponse.setEmpFamilyMemberFirstName(employeeFamilyBg.getEmpFamilyMemberFirstName());
        employeeFamilyBgResponse.setEmpFamilyMemberLastName(employeeFamilyBg.getEmpFamilyMemberLastName());
        employeeFamilyBgResponse.setEmpFmContact(employeeFamilyBg.getEmpFmContact());

        employeeFamilyBgResponse.setEmpFmRelation(employeeFamilyBg.getEmpFmRelation());
        employeeFamilyBgResponse.setEmpFmDob(employeeFamilyBg.getEmpFmDob());

        employeeFamilyBgResponse.setEmployee(new EmployeeDTO(employeeFamilyBg.getEmployee().getEmployeeId(),employeeFamilyBg.getEmployee().getEmpFirstName(),employeeFamilyBg.getEmployee().getEmpLastName()));
        employeeFamilyBgResponse.setOccupation(new OccupationResponse(employeeFamilyBg.getOccupation().getOccupationId(),employeeFamilyBg.getOccupation().getOccupationName()));
        employeeFamilyBgResponse.setEduType(new EduTypeResponse(employeeFamilyBg.getEduType().getEmpEducationTypeId(),employeeFamilyBg.getEduType().getEmpEducationName()));
        return employeeFamilyBgResponse;
    }
}
