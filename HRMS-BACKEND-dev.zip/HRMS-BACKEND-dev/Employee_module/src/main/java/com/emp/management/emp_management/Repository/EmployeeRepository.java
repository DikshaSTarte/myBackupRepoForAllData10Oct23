package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.Employee;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.net.ContentHandler;
import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee,Integer> {
    Employee findByActiveAndEmployeeId(boolean b, Integer employeeId);


    @Query("SELECT e FROM Employee e WHERE " +
            "e.active = true AND (" +
            "LOWER(e.empFirstName) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "LOWER(e.empMiddleName) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "LOWER(e.empLastName) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "LOWER(e.empDesignation.empDesignationName) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "LOWER(e.empDesignation.empDepartment.empDepartmentName) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "CONCAT(LOWER(e.empFirstName), ' ', LOWER(e.empLastName)) LIKE LOWER(CONCAT(:searchTerm, '%'))) " +
            "ORDER BY e.employeeId DESC")
    List<Employee> findBySearchTerm(String searchTerm, Pageable pageable);

    @Query("SELECT COUNT(e) FROM Employee e WHERE " +
            "e.active = true AND (" +
            "LOWER(e.empFirstName) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "LOWER(e.empMiddleName) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "LOWER(e.empLastName) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "LOWER(e.empDesignation.empDesignationName) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "LOWER(e.empDesignation.empDepartment.empDepartmentName) LIKE LOWER(CONCAT(:searchTerm, '%')) OR " +
            "CONCAT(LOWER(e.empFirstName), ' ', LOWER(e.empLastName)) LIKE LOWER(CONCAT(:searchTerm, '%'))) " )

    long countByActiveAndSearchTerm(String searchTerm);

    Page<Employee> findByActiveOrderByEmployeeIdDesc(boolean b, Pageable pageable);

    long countByActive(boolean b);

}
