package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.Employee;
import com.emp.management.emp_management.model.EmployeeBasicDetails;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmployeeBasicDetailsRepository extends JpaRepository<EmployeeBasicDetails, Integer> {

    EmployeeBasicDetails findByActiveAndEmployee_EmployeeId(boolean b, Integer employeeId);


    List<EmployeeBasicDetails> findAllByActiveAndEmployee_EmployeeId(boolean active, Integer employeeId);

}
