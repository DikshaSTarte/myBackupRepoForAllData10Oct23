package com.emp.management.emp_management.DTO.Request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmpAddressRequest {
    private String empDetailedAddress;
  private Integer EmpAddressTypeId;
   private Integer empAddPincode;
   private String empAddLandMark;


}
