package com.emp.management.emp_management.Controller;


import com.emp.management.emp_management.DTO.Response.DesignationResponse;
import com.emp.management.emp_management.Service.EmpDesignationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/v1/employee/designation")
public class EmpDesignationController {
    @Autowired
    EmpDesignationService empDesignationService;
    @GetMapping("/get/{departmentId}")
    public List<DesignationResponse> getCandidateById(@PathVariable Integer departmentId) {
        log.info("EmployeeController----------getDesignationBydeptId---------{}",departmentId);
        return this.empDesignationService.getDesignationsListByDeptId(departmentId);
    }
}
