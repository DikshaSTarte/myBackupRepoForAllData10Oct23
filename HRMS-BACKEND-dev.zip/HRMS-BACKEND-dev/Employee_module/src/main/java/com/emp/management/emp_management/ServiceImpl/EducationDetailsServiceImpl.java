package com.emp.management.emp_management.ServiceImpl;

import com.emp.management.emp_management.DTO.Request.EducationRequest;
import com.emp.management.emp_management.DTO.Request.SchoolRequest;
import com.emp.management.emp_management.DTO.Response.*;
import com.emp.management.emp_management.Repository.*;
import com.emp.management.emp_management.Service.EducationDetailsService;
import com.emp.management.emp_management.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class EducationDetailsServiceImpl implements EducationDetailsService {
    @Autowired
    private EmployeeRepository employeeRepository;
    @Autowired
    private MediumRepository mediumRepository;
    @Autowired
    private SpecializationsRepository specializationsRepository;
    @Autowired
    private EmpEducationDetailsRepository educationDetailsRepository;
    @Autowired
    private LearningTypeRepository learningTypeRepository;
    @Autowired
    private EmpEducationTypeRepository educationTypeRepository;
    @Autowired
    private CourseRepository courseRepository;
    @Autowired
    private GradingRepository gradingRepository;

    @Override
//    public CollegeResponse saveEmployeeCollegeDetails(EducationRequest request) {
//        Employee empId = employeeRepository.findByActiveAndEmployeeId(true,request.getEmployeeId());
//        EmployeeEducationDetails educationDetails = new EmployeeEducationDetails();
//
//        educationDetails.setEmployee(empId);
//        educationDetails.setEmployeeEducationType(educationTypeRepository.findById(request.getEducationTypeId()).get());
//        educationDetails.setDistrict(request.getDistrict());
//        educationDetails.setEmpInstituteName(request.getInstituteName());
//        educationDetails.setEmpUniversityName(request.getUniversityName());
//        educationDetails.setEmpPercentage(request.getMarks());
//        educationDetails.setGradingSystem(gradingRepository.findByGradeId(request.getGradesId()));
//        educationDetails.setMedium(mediumRepository.findById(request.getMedium()).get());
//        educationDetails.setEmpYearOfPassing(request.getYearOfPassing());
//        educationDetails.setSpecializations(specializationsRepository.findByActiveAndSpecializationId(true,request.getSpecialization()));
//
//        educationDetails.setType(learningTypeRepository.findById(request.getLearningType()).get());
//
//        EmployeeEducationDetails saveDetails = this.educationDetailsRepository.save(educationDetails);
//
//        return null;
//    }
    public CollegeResponse saveEmployeeCollegeDetails(EducationRequest request) {
        Employee empId = employeeRepository.findByActiveAndEmployeeId(true, request.getEmployeeId());

        EmployeeEducationDetails existingEducationDetails = educationDetailsRepository.findByActiveAndEmployee_employeeIdAndEmployeeEducationType_empEducationTypeId(true,empId.getEmployeeId(), request.getEducationTypeId());

        if (existingEducationDetails!=null) {
            //            return new CollegeResponse(existingEducationDetails.getEmployeeEducationType().getEmpEducationName()+" details already exists for employee: "+existingEducationDetails.getEmployee().getEmpFirstName()+" "+existingEducationDetails.getEmployee().getEmpLastName());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, existingEducationDetails.getEmployeeEducationType().getEmpEducationName() + " details already exist for employee: " + existingEducationDetails.getEmployee().getEmpFirstName() + " " + existingEducationDetails.getEmployee().getEmpLastName());
        } else {
            EmployeeEducationDetails educationDetails = new EmployeeEducationDetails();

            educationDetails.setEmployee(empId);
            educationDetails.setEmployeeEducationType(educationTypeRepository.findById(request.getEducationTypeId()).get());
            educationDetails.setDistrict(request.getDistrict());
            educationDetails.setEmpInstituteName(request.getInstituteName());
            educationDetails.setEmpUniversityName(request.getUniversityName());
            educationDetails.setEmpPercentage(request.getMarks());
            educationDetails.setGradingSystem(gradingRepository.findByGradeId(request.getGradesId()));
            educationDetails.setMedium(mediumRepository.findById(request.getMedium()).get());
            educationDetails.setEmpYearOfPassing(request.getYearOfPassing());
            educationDetails.setSpecializations(specializationsRepository.findByActiveAndSpecializationId(true, request.getSpecialization()));
            educationDetails.setType(learningTypeRepository.findById(request.getLearningType()).get());

            EmployeeEducationDetails saveDetails = this.educationDetailsRepository.save(educationDetails);

            return new CollegeResponse("Education details saved successfully.");
        }
    }
    @Override
    public List<EducationDetailDTO> getEducationInfoByEmpId(Integer empId){
        List<EducationDetailDTO> educationDetailsList = new ArrayList<>();

        EmployeeEducationDetails sscDetails = educationDetailsRepository.findByActiveAndEmployee_employeeIdAndEmployeeEducationType_empEducationTypeId(true, empId, 1);
        EmployeeEducationDetails hscDetails = educationDetailsRepository.findByActiveAndEmployee_employeeIdAndEmployeeEducationType_empEducationTypeId(true, empId,2);
        EmployeeEducationDetails ugDetails = educationDetailsRepository.findByActiveAndEmployee_employeeIdAndEmployeeEducationType_empEducationTypeId(true, empId, 4);
        EmployeeEducationDetails pgDetails = educationDetailsRepository.findByActiveAndEmployee_employeeIdAndEmployeeEducationType_empEducationTypeId(true, empId, 5);

        EducationDetailDTO sscDTO = new EducationDetailDTO();
        if(sscDetails!=null) {
            sscDTO.setEmpEduDetailsId(sscDetails.getEmpEducationDetailsId());
            sscDTO.setEducationType(new EduTypeResponse(sscDetails.getEmployeeEducationType().getEmpEducationTypeId(),
                    sscDetails.getEmployeeEducationType().getEmpEducationName()));
            sscDTO.setInstituteName(sscDetails.getEmpInstituteName());
            sscDTO.setMarks(sscDetails.getEmpPercentage());
            sscDTO.setYearOfPassing(sscDetails.getEmpYearOfPassing());
            sscDTO.setDistrict(sscDetails.getDistrict());
            sscDTO.setCourse(new CourseResponse(sscDetails.getSpecializations().getCourses().getCourseId(),
                    sscDetails.getSpecializations().getCourses().getCourseName()));
            sscDTO.setMedium(new MediumResponse(sscDetails.getMedium().getMediumId(), sscDetails.getMedium().getMediumName()));
            sscDTO.setCourseType(new LearningTypeResponse(sscDetails.getType().getLearningTypeId(),
                    sscDetails.getType().getLearningTypeName()));
            sscDTO.setSpecialization(new SpecializationResponse(sscDetails.getSpecializations().getSpecializationId(),
                    sscDetails.getSpecializations().getSpecializationName()));
            sscDTO.setUniversityName("NA");
            sscDTO.setGradingSystem(new GradingResponse(sscDetails.getGradingSystem().getGradeId(),
                    sscDetails.getGradingSystem().getGradeName()));
            educationDetailsList.add(sscDTO);
        }
        EducationDetailDTO hscDTO = new EducationDetailDTO();
        if(hscDetails!= null) {
            hscDTO.setEmpEduDetailsId(hscDetails.getEmpEducationDetailsId());
            hscDTO.setEducationType(new EduTypeResponse(hscDetails.getEmployeeEducationType().getEmpEducationTypeId(),
                    hscDetails.getEmployeeEducationType().getEmpEducationName()));
            hscDTO.setInstituteName(hscDetails.getEmpInstituteName());
            hscDTO.setMarks(hscDetails.getEmpPercentage());
            hscDTO.setYearOfPassing(hscDetails.getEmpYearOfPassing());
            hscDTO.setMedium(new MediumResponse(hscDetails.getMedium().getMediumId(),
                    hscDetails.getMedium().getMediumName()));
            hscDTO.setCourse(new CourseResponse(hscDetails.getSpecializations().getCourses().getCourseId(),
                    hscDetails.getSpecializations().getCourses().getCourseName()));
            hscDTO.setSpecialization(new SpecializationResponse(hscDetails.getSpecializations().getSpecializationId(),
                    hscDetails.getSpecializations().getSpecializationName()));
            hscDTO.setDistrict(hscDetails.getDistrict());
            hscDTO.setUniversityName("NA");
            hscDTO.setCourseType(new LearningTypeResponse(hscDetails.getType().getLearningTypeId(),
                    hscDetails.getType().getLearningTypeName()));
            hscDTO.setGradingSystem(new GradingResponse(hscDetails.getGradingSystem().getGradeId(),
                    hscDetails.getGradingSystem().getGradeName()));
            educationDetailsList.add(hscDTO);
        }
        EducationDetailDTO ugDTO = new EducationDetailDTO();
        if (ugDetails!=null) {
            ugDTO.setEmpEduDetailsId(ugDetails.getEmpEducationDetailsId());
            ugDTO.setEducationType(new EduTypeResponse(ugDetails.getEmployeeEducationType().getEmpEducationTypeId(),
                    ugDetails.getEmployeeEducationType().getEmpEducationName()));
            ugDTO.setCourse(new CourseResponse(ugDetails.getSpecializations().getCourses().getCourseId(), ugDetails.getSpecializations().getCourses().getCourseName()));
            ugDTO.setSpecialization(new SpecializationResponse(ugDetails.getSpecializations().getSpecializationId(),
                    ugDetails.getSpecializations().getSpecializationName()));
            ugDTO.setMarks(ugDetails.getEmpPercentage());
            ugDTO.setInstituteName(ugDetails.getEmpInstituteName());
            ugDTO.setUniversityName(ugDetails.getEmpUniversityName());
            ugDTO.setYearOfPassing(ugDetails.getEmpYearOfPassing());
            ugDTO.setMedium(new MediumResponse(ugDetails.getMedium().getMediumId(),
                    ugDetails.getMedium().getMediumName()));
            ugDTO.setDistrict(ugDetails.getDistrict());
            ugDTO.setCourseType(new LearningTypeResponse(ugDetails.getType().getLearningTypeId(), ugDetails.getType().getLearningTypeName()));
            ugDTO.setGradingSystem(new GradingResponse(ugDetails.getGradingSystem().getGradeId(),
                    ugDetails.getGradingSystem().getGradeName()));
            educationDetailsList.add(ugDTO);
        }
        EducationDetailDTO pgDTO = new EducationDetailDTO();
        if (pgDetails!=null) {

            pgDTO.setEmpEduDetailsId(pgDetails.getEmpEducationDetailsId());
            pgDTO.setEducationType(new EduTypeResponse(pgDetails.getEmployeeEducationType().getEmpEducationTypeId(),
                    pgDetails.getEmployeeEducationType().getEmpEducationName()));
            pgDTO.setCourse(new CourseResponse(pgDetails.getSpecializations().getCourses().getCourseId(),
                    pgDetails.getSpecializations().getCourses().getCourseName()));
            pgDTO.setInstituteName(pgDetails.getEmpInstituteName());
            pgDTO.setYearOfPassing(pgDetails.getEmpYearOfPassing());
            pgDTO.setMarks(pgDetails.getEmpPercentage());
            pgDTO.setSpecialization(new SpecializationResponse(pgDetails.getSpecializations().getSpecializationId(),
                    pgDetails.getSpecializations().getSpecializationName()));
            pgDTO.setUniversityName(pgDetails.getEmpUniversityName());
            pgDTO.setCourseType(new LearningTypeResponse(pgDetails.getType().getLearningTypeId(),
                    pgDetails.getType().getLearningTypeName()));
            pgDTO.setMedium(new MediumResponse(pgDetails.getMedium().getMediumId(),
                    pgDetails.getMedium().getMediumName()));
            pgDTO.setDistrict(pgDetails.getDistrict());
            pgDTO.setGradingSystem(new GradingResponse(pgDetails.getGradingSystem().getGradeId(),
                    pgDetails.getGradingSystem().getGradeName()));
            educationDetailsList.add(pgDTO);
        }
//      EducationDetailDTO phdDetails = new EducationDetailDTO();

        else return educationDetailsList;
        return educationDetailsList;
    }
    @Override
    public UpgradedEducationDTO updateEducationDetails(EducationRequest request, Integer empId) {
        EmployeeEducationDetails educationDetails = educationDetailsRepository.findByActiveAndEmployee_employeeIdAndEmployeeEducationType_empEducationTypeId(true,empId, request.getEducationTypeId());
        educationDetails.setDistrict(request.getDistrict());
        educationDetails.setEmpInstituteName(request.getInstituteName());
        educationDetails.setEmpUniversityName(request.getUniversityName());
        educationDetails.setMedium(mediumRepository.findById(request.getMedium()).get());
        educationDetails.setDistrict(request.getDistrict());
        educationDetails.setEmployeeEducationType(educationTypeRepository.findById(request.getEducationTypeId()).get());
        educationDetails.setType(learningTypeRepository.findById(request.getLearningType()).get());
        educationDetails.setEmpPercentage(request.getMarks());
        educationDetails.setEmpYearOfPassing(request.getYearOfPassing());
        educationDetails.setSpecializations(specializationsRepository.findById(request.getSpecialization()).get());
        educationDetailsRepository.save(educationDetails);
        return mapEmpEducationDetailsToUpdatedResponse(educationDetails);
    }
    private UpgradedEducationDTO mapEmpEducationDetailsToUpdatedResponse(EmployeeEducationDetails educationDetails) {
        UpgradedEducationDTO updatedResponse = new UpgradedEducationDTO();
        updatedResponse.setEducationDetailsId(educationDetails.getEmpEducationDetailsId());
        updatedResponse.setUpdatedEducationType(new EduTypeResponse(educationDetails.getEmployeeEducationType().getEmpEducationTypeId(),
                educationDetails.getEmployeeEducationType().getEmpEducationName()));
        updatedResponse.setUpdatedDistrict(educationDetails.getDistrict());
        updatedResponse.setUpdatedMarks(educationDetails.getEmpPercentage());
        updatedResponse.setUpdatedMedium(new MediumResponse(educationDetails.getMedium().getMediumId(),
                educationDetails.getMedium().getMediumName()));
        updatedResponse.setUpdatedInstituteName(educationDetails.getEmpInstituteName());
        updatedResponse.setUpdatedUniversityName(educationDetails.getEmpUniversityName());
        updatedResponse.setUpdatedCourseType(new LearningTypeResponse(educationDetails.getType().getLearningTypeId(),
                educationDetails.getType().getLearningTypeName()));
        updatedResponse.setUpdatedCourseResponse(new CourseResponse(educationDetails.getSpecializations().getCourses().getCourseId(),
                educationDetails.getSpecializations().getCourses().getCourseName()));
        updatedResponse.setUpdatedSpecialization(new SpecializationResponse(educationDetails.getSpecializations().getSpecializationId(),
                educationDetails.getSpecializations().getSpecializationName()));
        return updatedResponse;
    }
    @Override
    public ResponseEntity<String> deleteEducationDetailsById(@PathVariable Integer empEduDetailsId) {
        EmployeeEducationDetails educationDetails = educationDetailsRepository.findByActiveAndEmpEducationDetailsId(true, empEduDetailsId);
        if (educationDetails != null) {
            educationDetails.setActive(false);
            educationDetailsRepository.save(educationDetails);
            return ResponseEntity.status(HttpStatus.OK).body("Education details with ID " + empEduDetailsId + " deleted successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Education details with ID " + empEduDetailsId + " not found.");
        }
    }
}

