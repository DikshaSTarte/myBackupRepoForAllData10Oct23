package com.emp.management.emp_management.Controller;

import com.emp.management.emp_management.DTO.Request.EducationRequest;
import com.emp.management.emp_management.DTO.Request.SchoolRequest;
import com.emp.management.emp_management.DTO.Response.*;
import com.emp.management.emp_management.Service.EducationDetailsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/v1/employee/educationInfo")
public class EducationDetailsController {
    @Autowired
    private EducationDetailsService service;
//    @PostMapping("/school/save")
//    public SchoolResponse SaveEmployeeSchoolData(@Valid @RequestBody SchoolRequest request) {
//        log.info("EducationDetailsController----------SavePreEducationDetails----------{}",request);
//        return service.saveEmployeeSchoolDetails(request);
//    }
    @PostMapping("/save")
    public CollegeResponse SaveEmployeeCollegeData(@Valid @RequestBody EducationRequest request) {
        log.info("EducationDetailsController----------SavePostEducationDetails----------{}",request);
        return service.saveEmployeeCollegeDetails(request);
    }
    @GetMapping("/get/{empId}")
    public List<EducationDetailDTO> fetchEduDetailsOfEmployee(@PathVariable Integer empId){
        log.info("EducationDetailsController----------getEduDetailsByEmpId------{}");
        return this.service.getEducationInfoByEmpId(empId);
    }
    @PutMapping("/update/{empId}")
    public UpgradedEducationDTO editEducationDetails(@RequestBody EducationRequest request , @PathVariable Integer empId){
        log.info("EducationDetailsController----------updateEducationDetails--------{}",request,empId);
        return this.service.updateEducationDetails(request,empId);
    }
    @DeleteMapping("/delete/{empEduDetailsId}")
    public ResponseEntity<String> deleteEducationDetails(@PathVariable Integer empEduDetailsId){
         log.info("EducationDetailsController----------updateEducationDetails--------{}",empEduDetailsId);
         this.service.deleteEducationDetailsById(empEduDetailsId);
         return ResponseEntity.noContent().build();
    }
}
