package com.emp.management.emp_management.constants;

public class ErrorCodes {
//    public static final String LOGIN_FAILED = "Login failed";
    public static final String SKILLSET_ALREADY_EXISTS = "Employee skilled already exists.";
//    public static final String RR_ALREADY_EXIST = "RR is already present.";
}

