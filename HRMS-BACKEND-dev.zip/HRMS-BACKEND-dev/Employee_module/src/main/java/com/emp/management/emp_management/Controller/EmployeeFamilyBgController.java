package com.emp.management.emp_management.Controller;

import com.emp.management.emp_management.DTO.Request.EmployeeFamilyBgRequest;
import com.emp.management.emp_management.DTO.Response.EmployeeFamilyBgResponse;
import com.emp.management.emp_management.Service.EmployeeFamilyBgService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
@Slf4j
@RestController
@RequestMapping("api/v1/employee/familyBg")

public class EmployeeFamilyBgController {

    @Autowired
    private EmployeeFamilyBgService employeeFamilyBgService;

    @PostMapping("/save")

    public EmployeeFamilyBgResponse saveEmpFamilyBackgroundData(@Valid @RequestBody EmployeeFamilyBgRequest employeeFamilyBgRequest){
        log.info("EmployeeFamilyBgController------------saveEmpFamilyBackgroundData-------{}",employeeFamilyBgRequest);
        return employeeFamilyBgService.saveEmployeeFamilyBg(employeeFamilyBgRequest);
    }

    @GetMapping("/list")
    public List<EmployeeFamilyBgResponse> getListEmployeeFamilyBg() {
        log.info("EmployeeFamilyBgController------------getListEmployeeFamilyBg-------{}");
        return this.employeeFamilyBgService.listEmployeeFamilyBg();
    }

    @DeleteMapping("/delete/{empFamilyBgId}")
    public ResponseEntity<Void> deleteEmpFamilyMemberById(@PathVariable Integer empFamilyBgId) {
        employeeFamilyBgService.deleteEmpFamilyMemberById(empFamilyBgId);
        log.info("EmployeeFamilyBgController------------deleteEmpFamilyMemberById-------{}",empFamilyBgId);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/update/{empFamilyBgId}")

    public ResponseEntity<EmployeeFamilyBgResponse> updateEmployeeFamilyBgData(@Valid @PathVariable Integer empFamilyBgId, @RequestBody EmployeeFamilyBgRequest employeeFamilyBgRequest) {

        EmployeeFamilyBgResponse employeeFamilyBgResponse = employeeFamilyBgService.updateEmployeeFamilyBg(empFamilyBgId, employeeFamilyBgRequest);
        if (employeeFamilyBgResponse != null) {
            log.info("EmployeeFamilyBgController------------updateEmployeeFamilyBgData-------{}",empFamilyBgId,employeeFamilyBgRequest);
            return ResponseEntity.ok(employeeFamilyBgResponse);
        } else {
            log.info("EmployeeFamilyBgController------------updateEmployeeFamilyBgData-------{}",empFamilyBgId,employeeFamilyBgRequest);
            return ResponseEntity.notFound().build();
        }
    }
    @GetMapping("/get/{employeeId}")
    public List<EmployeeFamilyBgResponse> getEmployeeFamilyBgByemployeeId(@PathVariable Integer employeeId) {
        log.info("EmployeeFamilyBgController------------getEmployeeFamilyBgByemployeeId-------{}",employeeId);
        return this.employeeFamilyBgService.getEmployeeFamilyBgByEmpId(employeeId);
    }
}
