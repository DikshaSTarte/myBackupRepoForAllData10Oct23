package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.EmpDepartment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmpDepartmentRepository extends JpaRepository<EmpDepartment,Integer> {
    EmpDepartment findByActiveAndEmpDepartmentId(boolean b, Integer empDepartmentId);

    List<EmpDepartment> findAllByActiveOrderByEmpDepartmentIdDesc(boolean b);
}
