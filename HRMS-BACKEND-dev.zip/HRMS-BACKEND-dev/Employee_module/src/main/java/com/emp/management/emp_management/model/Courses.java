package com.emp.management.emp_management.model;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "Courses")
@AllArgsConstructor
@NoArgsConstructor
public class Courses extends BaseEntity{
    @Id
    @GeneratedValue (strategy = GenerationType.AUTO)
    @Column(name = "course_id")
    private Integer courseId;

    @Column(name = "course_name")
    private String courseName;

    @ManyToOne
    @JoinColumn(name="educationType")
    private EmployeeEducationType employeeEducationType;
}
