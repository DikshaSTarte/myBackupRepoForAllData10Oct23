package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.Specializations;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SpecializationsRepository extends JpaRepository<Specializations,Integer>{
    Specializations findByActiveAndCourses_courseId(boolean b, Integer course);

    Specializations findByActiveAndCourses_EmployeeEducationType_empEducationTypeId(boolean b, Integer educationTypeId);

    Specializations findByActiveAndSpecializationId(boolean b, Integer specialization);

    List<Specializations> findByActive(boolean b);
}
