package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.Occupation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OccupationRepository extends JpaRepository<Occupation,Integer> {
    List<Occupation> findByActive(boolean b);

    Occupation findByActiveAndOccupationId(boolean b, Integer occupationId);

}
