package com.emp.management.emp_management.Service;

import com.emp.management.emp_management.DTO.Response.CourseResponse;

import java.util.List;

public interface CourseService {
    List<CourseResponse> getCourseList();

    List<CourseResponse> getCourseListByEducationType(Integer educationTypeId);
}
