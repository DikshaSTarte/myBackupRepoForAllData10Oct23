package com.emp.management.emp_management.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "occupation")
@AllArgsConstructor
@NoArgsConstructor
public class Occupation extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "occupation_id")
    private Integer occupationId;
    @Column(name = "occupation_name")
    private String occupationName;
}