package com.emp.management.emp_management.ServiceImpl;

import com.emp.management.emp_management.DTO.Response.EmployeeListResponse;
import com.emp.management.emp_management.DTO.Response.EmployeeResponse;
import com.emp.management.emp_management.Repository.ContactDetailsRepository;
import com.emp.management.emp_management.Repository.EmployeeRepository;
import com.emp.management.emp_management.Service.EmployeeService;
import com.emp.management.emp_management.model.ContactDetails;
import com.emp.management.emp_management.model.Employee;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    EmployeeRepository employeeRepository;

    @Autowired
    ContactDetailsRepository contactDetailsRepository;
    @Override
    public EmployeeListResponse getListOfAllEmployees(Integer pageNumber, Integer pageSize, String searchTerm){
        log.info("EmployeeServiceImpl---------------------{}",pageNumber,pageSize,searchTerm);
        List<Employee> employeeList;
        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        long totalEmployees=0;

        //Need to check this query
        if (!searchTerm.isEmpty()) {
            employeeList = employeeRepository.findBySearchTerm(searchTerm, pageable);
            totalEmployees = employeeRepository.countByActiveAndSearchTerm(searchTerm) ;// Get the count from the list size
        } else {
            employeeList = employeeRepository.findByActiveOrderByEmployeeIdDesc(true, pageable).getContent();
            totalEmployees = employeeRepository.countByActive(true); // Get the total count separately
        }
        List<EmployeeResponse> employeeResponseList = new ArrayList<>();
        for (Employee employee : employeeList) {
            EmployeeResponse employeeResponse=new EmployeeResponse();
            employeeResponse.setEmployeeId(employee.getEmployeeId());
            employeeResponse.setEmpFirstName(employee.getEmpFirstName());
            employeeResponse.setEmpLastName(employee.getEmpLastName());
            employeeResponse.setEmpMiddleName(employee.getEmpMiddleName());
            employeeResponse.setEmployeeId(employee.getEmployeeId());
            employeeResponse.setEmpDesignation(employee.getEmpDesignation());
         ContactDetails contactDetails =contactDetailsRepository.findByActiveAndEmployee_EmployeeId(true,employee.getEmployeeId());
            employeeResponse.setEmpPhoneNumber(contactDetails.getPhoneNumber());
            employeeResponse.setEmpOrganizationalMail(contactDetails.getOrganizationalEmail());
          employeeResponseList.add(employeeResponse);
        }
        log.info("CandidateServiceImpl--------------getListCandidatesOp-------{}",pageNumber,pageSize,searchTerm);
        return new EmployeeListResponse(totalEmployees,employeeResponseList);
    }
}
