package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.EmployeeHistory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeHistoryRepository extends JpaRepository<EmployeeHistory,Integer> {


    EmployeeHistory findByActiveAndEmpHistoryId(boolean b, Integer empHistoryId);

    EmployeeHistory findByActiveAndEmployee_EmployeeId(boolean b, Integer employeeId);
}
