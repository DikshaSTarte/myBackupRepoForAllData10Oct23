package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.EmployeeEducationType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EmpEducationTypeRepository extends JpaRepository<EmployeeEducationType,Integer> {

    List<EmployeeEducationType> findByActive(boolean b);

    Optional<EmployeeEducationType> findByActiveAndEmpEducationTypeId(boolean b, Integer educationTypeId);

}
