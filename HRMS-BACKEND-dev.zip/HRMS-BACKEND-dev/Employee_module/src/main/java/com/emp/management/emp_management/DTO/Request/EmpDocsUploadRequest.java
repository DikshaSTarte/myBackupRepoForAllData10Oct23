package com.emp.management.emp_management.DTO.Request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmpDocsUploadRequest {
    private  Integer employeeId;
    private MultipartFile empAadharFile;
    private MultipartFile empPanFile;
    private MultipartFile empPassportFile;
    private MultipartFile empUanFile;
    private MultipartFile empLicenceFile;
    private MultipartFile empBankPassbook;
    private MultipartFile empSscMarksheet;
    private MultipartFile empHscMarksheet;
    private MultipartFile empGraduationMarksheet;
    private MultipartFile empPostGraduationMarksheet;
    private MultipartFile empPassportSizePhoto;
    private MultipartFile empPreOrgRelCertificate;
    private MultipartFile empPreOrgExpCertificate;

}
