package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.GradingSystem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GradingRepository extends JpaRepository<GradingSystem,Integer> {
    GradingSystem findByGradeId(Integer gradesId);
}
