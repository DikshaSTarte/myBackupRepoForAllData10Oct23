package com.emp.management.emp_management.ServiceImpl;

import com.emp.management.emp_management.DTO.Response.EmpDoctypeResponse;
import com.emp.management.emp_management.Repository.EmployeeDocTypeRepository;
import com.emp.management.emp_management.Repository.EmployeeDocUploadRepository;
import com.emp.management.emp_management.Repository.EmployeeRepository;
import com.emp.management.emp_management.Service.EmpDocTypeService;
import com.emp.management.emp_management.model.Employee;
import com.emp.management.emp_management.model.EmployeeDocType;
import com.emp.management.emp_management.model.EmployeeDocUpload;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Slf4j
@Service
public class EmpDocTypeServiceImpl implements EmpDocTypeService {

    @Autowired
    EmployeeDocTypeRepository employeeDocTypeRepository;

    @Autowired
    EmployeeDocUploadRepository employeeDocUploadRepository;

    @Autowired
    EmployeeRepository employeeRepository;
    @Override
    public List<EmpDoctypeResponse> getListDocumetsTypes(Integer employeeId){
        List<EmpDoctypeResponse> empDoctypeResponseList=new ArrayList<>();
        List<EmployeeDocType> employeeDocTypeList=employeeDocTypeRepository.findAllByActiveOrderByEmpDocTypeId(true);
        if(employeeId==0)
        {
            for(EmployeeDocType employeeDocType:employeeDocTypeList)
            {
                EmpDoctypeResponse empDoctypeResponse=new EmpDoctypeResponse();
                empDoctypeResponse.setEmpDocTypeId(employeeDocType.getEmpDocTypeId());
                empDoctypeResponse.setEmpDocTypeName(employeeDocType.getEmpDocTypeName());
                empDoctypeResponseList.add(empDoctypeResponse);
            }
        }
        else{

            Employee employee=employeeRepository.findByActiveAndEmployeeId(true,employeeId);
            for(EmployeeDocType employeeDocType:employeeDocTypeList)
            {
                boolean entryExists = employeeDocUploadRepository.existsByActiveAndEmpDocTypeAndEmployee(true, employeeDocType, employee);
                if (entryExists) {
                    continue;
                }
                EmpDoctypeResponse empDoctypeResponse=new EmpDoctypeResponse();
                empDoctypeResponse.setEmpDocTypeId(employeeDocType.getEmpDocTypeId());
                empDoctypeResponse.setEmpDocTypeName(employeeDocType.getEmpDocTypeName());
                empDoctypeResponseList.add(empDoctypeResponse);
            }
        }
        return empDoctypeResponseList;
    }
}