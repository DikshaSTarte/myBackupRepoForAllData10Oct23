package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.EmployeeSkillSet;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface EmployeeSkillSetRepository extends JpaRepository<EmployeeSkillSet,Integer> {

    List<EmployeeSkillSet> findByActiveAndEmployee_EmployeeId(boolean b, Integer empId);

    EmployeeSkillSet findByActiveAndEmpSkillSetName(boolean b ,String skillName);

    boolean existsByActiveAndEmpSkillSetName(boolean active, String skillName);

    EmployeeSkillSet findByActiveAndEmpSkillSetId(boolean b, Integer id);

//    EmployeeSkillSet findByActiveAndEmpSkillSetId(boolean b, List<String> skillSets);
}
