package com.emp.management.emp_management.Controller;


import com.emp.management.emp_management.DTO.Response.EmployeeListResponse;
import com.emp.management.emp_management.Service.EmployeeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/api/v1/employee")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/list")
    public ResponseEntity<EmployeeListResponse> getShowListEmployees(@RequestParam(value = "pageNumber", defaultValue = "0", required = false) Integer pageNumber,
                                                                       @RequestParam(value = "pageSize", defaultValue = "10", required = false) Integer pageSize,
                                                                       @RequestParam(value = "searchTerm", defaultValue = "", required = false) String searchTerm) {

        EmployeeListResponse employeeListResponse = employeeService.getListOfAllEmployees(pageNumber, pageSize, searchTerm);
        log.info("EmployeeController----------getShowListEmployees-----------{}",pageNumber,pageSize,searchTerm);
        return ResponseEntity.ok(employeeListResponse);
    }


}
