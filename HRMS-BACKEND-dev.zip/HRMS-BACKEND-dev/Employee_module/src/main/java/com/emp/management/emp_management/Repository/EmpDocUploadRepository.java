package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.Employee;
import com.emp.management.emp_management.model.EmployeeDocType;
import com.emp.management.emp_management.model.EmployeeDocUpload;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EmpDocUploadRepository extends JpaRepository<EmployeeDocUpload,Integer> {

    @Query("SELECT e.empDocType FROM EmployeeDocUpload e WHERE e.active = true AND e.employee.employeeId = :employeeId")
    List<EmployeeDocType> findEmployeeDocTypesByEmployeeId(@Param("employeeId") Integer employeeId);


    EmployeeDocUpload findByActiveAndEmployee_employeeIdAndEmpDocType_empDocTypeId(boolean b, Integer employeeId, Integer docTypeId);
}
