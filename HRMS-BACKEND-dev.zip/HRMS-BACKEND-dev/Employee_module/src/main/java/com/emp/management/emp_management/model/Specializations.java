package com.emp.management.emp_management.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.persistence.*;
@Getter
@Setter
@Entity
@Table(name = "emp_specialization")
@AllArgsConstructor
@NoArgsConstructor
public class Specializations extends BaseEntity{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "specialization_id")
    private Integer specializationId;

    @Column(name = "specialization_name")
    private String specializationName ;

    @ManyToOne
    @JoinColumn(name="course_id")
    private Courses courses ;
}
