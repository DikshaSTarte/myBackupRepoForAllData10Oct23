package com.emp.management.emp_management.Controller;

import com.emp.management.emp_management.DTO.Response.DepartmentResponse;
import com.emp.management.emp_management.DTO.Response.EmpDoctypeResponse;
import com.emp.management.emp_management.Service.EmpDepartmentService;
import com.emp.management.emp_management.Service.EmpDocTypeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/v1/employee/docType")
public class EmployeeDocTypeController {

    @Autowired
    EmpDocTypeService empDocTypeService;
    @GetMapping("/list/{employeeId}")
    public List<EmpDoctypeResponse> getAllDocumentsTypes(@PathVariable Integer employeeId) {
        log.info("EmployeeController----------getEmployeess------------{}");
        return this.empDocTypeService.getListDocumetsTypes(employeeId);
    }
}
