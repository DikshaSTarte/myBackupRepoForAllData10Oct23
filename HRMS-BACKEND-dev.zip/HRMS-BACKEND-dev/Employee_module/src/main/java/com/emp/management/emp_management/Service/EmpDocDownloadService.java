package com.emp.management.emp_management.Service;

import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import java.io.IOException;
public interface EmpDocDownloadService {
    ResponseEntity<Resource> downloadFile(Integer employeeId, Integer documentId)throws IOException;
}
