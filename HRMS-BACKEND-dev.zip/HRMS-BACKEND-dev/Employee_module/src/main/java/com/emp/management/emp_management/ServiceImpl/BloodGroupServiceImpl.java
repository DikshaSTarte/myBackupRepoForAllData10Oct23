package com.emp.management.emp_management.ServiceImpl;

import com.emp.management.emp_management.DTO.Response.BloodGroupResponse;
import com.emp.management.emp_management.Repository.EmpBloodGroupRepository;
import com.emp.management.emp_management.Service.BloodGroupService;

import com.emp.management.emp_management.mapper.ListingMapper;
import com.emp.management.emp_management.model.EmpBloodGroup;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class BloodGroupServiceImpl implements BloodGroupService {
    @Autowired
    private EmpBloodGroupRepository empBloodGroupRepository;
    @Autowired
    private ListingMapper bloodGroupMapper;
    @Override
    public List<BloodGroupResponse> getBloodGroupList() {
        List<EmpBloodGroup> candidateStatuses = empBloodGroupRepository.findByActive(true);
        return bloodGroupMapper.bloodGroupListMapper(candidateStatuses);
    }
}
