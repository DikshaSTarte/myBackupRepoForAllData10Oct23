package com.emp.management.emp_management.DTO.Response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CollegeResponse {
//    private EmployeeDTO employeeId;
//    private EduTypeResponse educationTypeId;
//    private CourseResponse course;
//    private MediumResponse medium;
//    private LearningTypeResponse learningType;
//    private SpecializationResponse specialization;
//    //    private Integer gradesId;
//    private String instituteName;
//    private String universityName;
//    private String district;
//    private String yearOfPassing;
//    private float marks ;
    private String message;
}
