package com.emp.management.emp_management.ServiceImpl;

import com.emp.management.emp_management.DTO.Request.SkillRequest;

import com.emp.management.emp_management.DTO.Request.SkillUpdateRequest;
import com.emp.management.emp_management.DTO.Response.*;

import com.emp.management.emp_management.Repository.EmployeeRepository;
import com.emp.management.emp_management.Repository.EmployeeSkillSetRepository;
import com.emp.management.emp_management.Service.EmployeeSkillSetService;

import com.emp.management.emp_management.constants.ErrorCodes;
import com.emp.management.emp_management.globalException.SkillSetAlreadyExistException;

import com.emp.management.emp_management.model.Employee;
import com.emp.management.emp_management.model.EmployeeSkillSet;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;


@Service
@Slf4j
public class EmployeeSkillSetServiceImpl implements EmployeeSkillSetService {
    @Autowired
    private EmployeeRepository employeeRepository;
    @Autowired
    private EmployeeSkillSetRepository employeeSkillSetRepository ;

    @Override
    public SkillResponse saveSkills(SkillRequest request) {
        Employee empId = employeeRepository.findByActiveAndEmployeeId(true, request.getEmployeeId());

        if (empId != null) {
            for (String skillName : request.getSkillSets()) {
                if(employeeSkillSetRepository.existsByActiveAndEmpSkillSetName(true,skillName))
                {throw new SkillSetAlreadyExistException(ErrorCodes.SKILLSET_ALREADY_EXISTS);
                }
                EmployeeSkillSet skill = new EmployeeSkillSet();
                skill.setEmployee(empId);
                skill.setEmpSkillSetName(skillName);

                EmployeeSkillSet savedSkill = employeeSkillSetRepository.save(skill);
                skill.setEmpSkillSetId(savedSkill.getEmpSkillSetId());
            }
            SkillResponse response = new SkillResponse();
            response.setMessage("Skills saved successfully");
//            response.setEmployee(new EmployeeResponse(empId.getEmployeeId(),empId.getEmpFirstName(),empId.getEmpLastName()));
            return response;
        } else {
            // Handle the case where the employee is not found
            SkillResponse response = new SkillResponse();
            response.setMessage("Employee not found");
            return response;
        }
    }
    @Override
    public List<EmployeeSkillDTO> getSkillsByEmpId(Integer empId) {
        List<EmployeeSkillSet> employeeSkillSets = employeeSkillSetRepository.findByActiveAndEmployee_EmployeeId(true,empId);

        List<EmployeeSkillDTO> employeeSkillDTOList = new ArrayList<>();
        for (EmployeeSkillSet skillSet :employeeSkillSets) {
            EmployeeSkillDTO employeeSkillDTO = new EmployeeSkillDTO();
            employeeSkillDTO.setSkillSetId(skillSet.getEmpSkillSetId());
            employeeSkillDTO.setSkillSetName(skillSet.getEmpSkillSetName());
            employeeSkillDTOList.add(employeeSkillDTO);
        }
            return employeeSkillDTOList;
    }
    @Override
    public SkillUpdateResponse editEmployeeSkills(Integer empId, SkillUpdateRequest request) {
        Employee employee = employeeRepository.findByActiveAndEmployeeId(true,empId);
//        employee.setEmployeeId(request.getEmpId());

        Employee update = this.employeeRepository.save(employee);
        List<Integer> skillsId = request.getSkillSet();
        List<EmployeeSkillSet> skillSetList = new ArrayList<>();
        for (Integer id : skillsId){
            EmployeeSkillSet skillSave = employeeSkillSetRepository.findByActiveAndEmpSkillSetId(true, id);

            EmployeeSkillSet employeeSkillSet = new EmployeeSkillSet();
            employeeSkillSet.setEmpSkillSetId(skillSave.getEmpSkillSetId());
            employeeSkillSet.setActive(false);
            skillSetList.add(employeeSkillSet);
        }
        employeeSkillSetRepository.saveAll(skillSetList);
        SkillUpdateResponse response =new SkillUpdateResponse();
        response.setMessage("Skill deleted successfully..");
        return response;
    }

}
