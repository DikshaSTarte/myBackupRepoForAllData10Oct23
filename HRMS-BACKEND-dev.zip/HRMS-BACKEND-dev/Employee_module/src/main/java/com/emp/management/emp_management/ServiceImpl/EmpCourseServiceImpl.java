package com.emp.management.emp_management.ServiceImpl;

import com.emp.management.emp_management.DTO.Response.CourseResponse;
import com.emp.management.emp_management.Repository.CourseRepository;
import com.emp.management.emp_management.Repository.EmpEducationTypeRepository;
import com.emp.management.emp_management.Service.CourseService;
import com.emp.management.emp_management.mapper.ListingMapper;
import com.emp.management.emp_management.model.Courses;
import com.emp.management.emp_management.model.EmployeeEducationType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@Slf4j
public class EmpCourseServiceImpl implements CourseService {
    @Autowired
    private ListingMapper listingMapper ;
    @Autowired
    private CourseRepository courseRepository ;
    @Autowired
    private EmpEducationTypeRepository empEducationTypeRepository;
    @Override
    public List<CourseResponse> getCourseList() {
        List<Courses> courses = courseRepository.findByActive(true);
        return listingMapper.courseListMapper(courses);
    }

    @Override
    public List<CourseResponse> getCourseListByEducationType(Integer educationTypeId) {
        log.info("EmpCourseServiceImpl---------------getCoursesByEducationTypeId------------{}", educationTypeId);
        Optional<EmployeeEducationType> employeeEducationTypeOptional = empEducationTypeRepository.findByActiveAndEmpEducationTypeId(true, educationTypeId);
        List<Courses> courses = courseRepository.findByActiveAndEmployeeEducationType_empEducationTypeId(true, employeeEducationTypeOptional.get().getEmpEducationTypeId());
        List<CourseResponse> responses = new ArrayList<>();

        for (Courses courses1 : courses) {
            CourseResponse response = new CourseResponse();
            response.setCourseId(courses1.getCourseId());
            response.setCourseName(courses1.getCourseName());

            responses.add(response);
        }
        return responses;
    }

}
