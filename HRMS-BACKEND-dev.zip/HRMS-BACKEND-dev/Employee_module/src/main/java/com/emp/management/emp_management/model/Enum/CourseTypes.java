
package com.emp.management.emp_management.model.Enum;

public enum CourseTypes {
    FULLTIME("traditional approach to education"),
    PARTTIME("taking fewer courses per semester"),
    DISTANCE("online learning or e-learning");
    private final String description;

    CourseTypes(String description) {
        this.description = description;
    }
    public String getDescription() {
        return description;
    }

}

