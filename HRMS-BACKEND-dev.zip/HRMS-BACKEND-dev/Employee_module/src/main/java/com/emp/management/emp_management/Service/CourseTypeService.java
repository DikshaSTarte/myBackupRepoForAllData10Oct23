package com.emp.management.emp_management.Service;

import com.emp.management.emp_management.DTO.Response.BloodGroupResponse;

import com.emp.management.emp_management.DTO.Response.SpecializationResponse;

import java.util.List;

public interface CourseTypeService {
    List<SpecializationResponse> getSpecializationList();
}
