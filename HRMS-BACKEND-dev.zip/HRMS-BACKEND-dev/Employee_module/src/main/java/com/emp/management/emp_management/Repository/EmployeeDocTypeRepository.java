package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.EmployeeDocType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmployeeDocTypeRepository extends JpaRepository<EmployeeDocType,Integer> {
     EmployeeDocType findByActiveAndEmpDocTypeId(boolean b,Integer id);

    List<EmployeeDocType> findAllByActiveOrderByEmpDocTypeIdDesc(boolean b);

    List<EmployeeDocType> findAllByActiveOrderByEmpDocTypeId(boolean b);
}
