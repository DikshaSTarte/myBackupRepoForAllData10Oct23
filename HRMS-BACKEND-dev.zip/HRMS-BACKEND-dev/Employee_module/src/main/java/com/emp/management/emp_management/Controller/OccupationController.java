package com.emp.management.emp_management.Controller;

import com.emp.management.emp_management.DTO.Response.OccupationResponse;
import com.emp.management.emp_management.Service.OccupationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("api/v1/employee/occupation")
public class OccupationController {
    @Autowired
    private OccupationService occupationService;
    @GetMapping("list")
    public List<OccupationResponse> getListOccupations(){
        return this.occupationService.listOccupation();
    }

}