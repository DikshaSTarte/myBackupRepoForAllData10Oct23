package com.emp.management.emp_management.DTO.Response;

import com.emp.management.emp_management.model.EmpBloodGroup;
import com.emp.management.emp_management.model.EmpMaritalStatus;
import com.emp.management.emp_management.model.EmpStatus;
import com.emp.management.emp_management.model.Employee;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeBasicDetailDtoResponse {


    private Integer empBasicDetailsId;
    private EmpResponse employee;
    private String empGender;
    private LocalDate empDoj;
    private EmpStatusResponse empStatus;
    private String empNationality;
    private LocalDate empDob;
    private EmpMaritalStatusResponse empMaritalStatus;
    private BloodGroupResponse empBloodGroup;
    private LocalDate empDoa;
    private ContactDetailsResponse contactDetails;
private List<EmployeeAddressDTO> employeeAddressDTO;
  private DesignationResponse designation;


    private String empFormerName;
    private String empPassportNumber;
    private String empPanNumber;
    private String empUanNumber;
    private String empDrLicenceNumber;
    private String empCurrentWorkingLocation;
    private float empHistoryExperience;
}
