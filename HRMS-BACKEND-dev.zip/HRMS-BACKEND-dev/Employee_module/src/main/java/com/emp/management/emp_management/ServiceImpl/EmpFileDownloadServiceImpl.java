package com.emp.management.emp_management.ServiceImpl;



import com.emp.management.emp_management.Repository.EmployeeDocUploadRepository;
import com.emp.management.emp_management.Repository.EmployeeRepository;
import com.emp.management.emp_management.Service.EmpDocDownloadService;
import com.emp.management.emp_management.model.Employee;
import com.emp.management.emp_management.model.EmployeeDocUpload;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import  org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;


@Slf4j
@Service
public class EmpFileDownloadServiceImpl implements EmpDocDownloadService {

    @Autowired
    EmployeeDocUploadRepository employeeDocUploadRepository;
    @Autowired
    EmployeeRepository employeeRepository;
    public final String UPLOAD_DIR = "C:\\Users\\MFS087\\Documents\\HRMS_git\\HRMS-BACKEND\\Employee_module\\EmpDocumentsSaved";
    @Override
    public ResponseEntity<Resource> downloadFile(Integer employeeId, Integer documentId) throws IOException {

        Employee employee=employeeRepository.findByActiveAndEmployeeId(true,employeeId);
        EmployeeDocUpload employeeDocUpload=employeeDocUploadRepository.findOneByActiveAndEmployee_EmployeeIdAndEmpDocType_EmpDocTypeId(true,employeeId,documentId);
        if(employeeDocUpload==null)
            return ResponseEntity.notFound().build();
        String employeeFullName=employee.getEmpFirstName()+employee.getEmpLastName();
        // Construct the file path
        String filePath =UPLOAD_DIR + File.separator + employeeId.toString()+employeeFullName+ File.separator + employeeDocUpload.getDocOriginalName() ;
        Path destination=Paths.get(filePath);
        Resource resource = new FileSystemResource(destination);

        if (resource.exists() && resource.isReadable()) {


            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + employeeDocUpload.getDocOriginalName());
            if(documentId==10)
               headers.add(HttpHeaders.CONTENT_TYPE,MediaType.IMAGE_PNG_VALUE);
            else
               headers.add(HttpHeaders.CONTENT_TYPE,MediaType.APPLICATION_PDF_VALUE);

            return ResponseEntity.ok()
                    .headers(headers)
                    .body(resource);
        } else {
            // Handle the case when the file does not exist
            return ResponseEntity.notFound().build();
        }
    }
}