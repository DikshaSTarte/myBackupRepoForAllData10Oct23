package com.emp.management.emp_management.mapper;

import com.emp.management.emp_management.DTO.Response.*;
import com.emp.management.emp_management.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.modelmapper.ModelMapper;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class ListingMapper {
    @Autowired
    private ModelMapper modelMapper;
    public List<BloodGroupResponse> bloodGroupListMapper(List<EmpBloodGroup> list){
        return list
                .stream()
                .map(bloodGroup -> modelMapper.map(bloodGroup, BloodGroupResponse.class))
                .collect(Collectors.toList());
    }
    public List<SpecializationResponse> courseTypeListMapper(List<Specializations> specializations){
        return specializations
                .stream()
                .map(specialization -> modelMapper.map(specialization, SpecializationResponse.class))
                .collect(Collectors.toList());
    }
    public List<CourseResponse> courseListMapper(List<Courses> courses){
        return courses
                .stream()
                .map(course -> modelMapper.map(course, CourseResponse.class))
                .collect(Collectors.toList());
    }

    public List<EduTypeResponse> eduTypeGroupListMapper(List<EmployeeEducationType> types) {
        return types
                .stream()
                .map(type -> modelMapper.map(type, EduTypeResponse.class))
                .collect(Collectors.toList());
    }

    public List<MediumResponse> mediumListMapper(List<EducationMedium> educationMediumList) {
        return educationMediumList
                .stream()
                .map(medium->modelMapper.map(medium,MediumResponse.class))
                .collect(Collectors.toList());
    }

    public List<OccupationResponse> occupationListMapper(List<Occupation> occupations){
        return occupations
                .stream()
                .map(occupation -> modelMapper.map(occupation,OccupationResponse.class))
                .collect(Collectors.toList());
    }

}
