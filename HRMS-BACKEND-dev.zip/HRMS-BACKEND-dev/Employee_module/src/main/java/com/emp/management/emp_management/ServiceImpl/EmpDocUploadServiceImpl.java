package com.emp.management.emp_management.ServiceImpl;




import com.emp.management.emp_management.DTO.Request.DocumentRequest;
import com.emp.management.emp_management.DTO.Response.ApiResponse;
import com.emp.management.emp_management.DTO.Response.EmpDoctypeResponse;
import com.emp.management.emp_management.Repository.EmpDocUploadRepository;
import com.emp.management.emp_management.Repository.EmployeeDocTypeRepository;
import com.emp.management.emp_management.Repository.EmployeeDocUploadRepository;
import com.emp.management.emp_management.Repository.EmployeeRepository;
import com.emp.management.emp_management.Service.EmpDocUploadService;
import com.emp.management.emp_management.model.Employee;
import com.emp.management.emp_management.model.EmployeeDocType;
import com.emp.management.emp_management.model.EmployeeDocUpload;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;


@Slf4j
@Service
public class EmpDocUploadServiceImpl implements EmpDocUploadService {


    public final String UPLOAD_DIR = "C:\\Users\\MFS087\\Documents\\HRMS_git\\HRMS-BACKEND\\Employee_module\\EmpDocumentsSaved";


    @Autowired
    EmployeeDocUploadRepository employeeDocUploadRepository;

    @Autowired
    EmployeeRepository employeeRepository;

    @Autowired
    EmployeeDocTypeRepository employeeDocTypeRepository;

    @Autowired
    EmpDocUploadRepository empDocUploadRepository;



    @Override
    public ApiResponse deleteFileById(Integer employeeId, Integer docTypeId){
        System.out.println("***********************************************************************************************************************************");
        EmployeeDocUpload employeeDocUpload=empDocUploadRepository.findByActiveAndEmployee_employeeIdAndEmpDocType_empDocTypeId(true,employeeId,docTypeId);
        if(employeeDocUpload !=null)
        {
            String filePath = employeeDocUpload.getEmpDocPath();
            File fileToDelete = new File(filePath);
            if (fileToDelete.exists()) {
                fileToDelete.delete();
            }
            employeeDocUpload.setActive(false);
            empDocUploadRepository.save(employeeDocUpload);
            return new ApiResponse("file Deleted Successfully", true);

        }
        else{
            return new ApiResponse("Error while Deleteing file :File Does not exist", false);
        }

    }

    @Override
    public List<EmpDoctypeResponse> getListDocumetsUploaded(Integer employeeId){
        List<EmpDoctypeResponse> empDoctypeResponseList=new ArrayList<>();

        List<EmployeeDocUpload> employeeDocUploadList=employeeDocUploadRepository.findByActiveAndEmployee_EmployeeId(true,employeeId);

        for(EmployeeDocUpload employeeDocUpload:employeeDocUploadList)
        {
            EmpDoctypeResponse empDoctypeResponse=new EmpDoctypeResponse();
            empDoctypeResponse.setEmpDocTypeId(employeeDocUpload.getEmpDocType().getEmpDocTypeId());
            empDoctypeResponse.setEmpDocTypeName(employeeDocUpload.getEmpDocType().getEmpDocTypeName());
            empDoctypeResponse.setEmpDocOriginalName(employeeDocUpload.getDocOriginalName());
            empDoctypeResponseList.add(empDoctypeResponse);
        }
//
//       List<EmployeeDocType> employeeDocTypeList=empDocUploadRepository.findEmployeeDocTypesByEmployeeId(employeeId);
//
//       for(EmployeeDocType employeeDocType:employeeDocTypeList)
//       {
//           EmpDoctypeResponse empDoctypeResponse=new EmpDoctypeResponse();
//           empDoctypeResponse.setEmpDocTypeId(employeeDocType.getEmpDocTypeId());
//           empDoctypeResponse.setEmpDocTypeName(employeeDocType.getEmpDocTypeName());
//           empDoctypeResponseList.add(empDoctypeResponse);
//       }
        return empDoctypeResponseList;
    }

   @Override
    public ApiResponse saveEmployeeDocuments3(MultipartFile file, Integer employeeId, Integer documentId, boolean update) throws IOException {
        if (update && file==null) {
            EmployeeDocUpload employeeDocUpload = employeeDocUploadRepository.findOneByActiveAndEmployee_EmployeeIdAndEmpDocType_EmpDocTypeId(true, employeeId, documentId);
            if(employeeDocUpload==null)
                return new ApiResponse("Cant Update without file as You have not uploaded this document",false);

            return new ApiResponse("Old file is kept", false, employeeDocUpload.getDocOriginalName(), employeeDocUpload.getEmpDocType().getEmpDocTypeName());
        }

        EmployeeDocType employeeDocType = employeeDocTypeRepository.findByActiveAndEmpDocTypeId(true, documentId);

        if (file.isEmpty()) {
            return new ApiResponse("File is Empty", false, file.getOriginalFilename(), employeeDocType.getEmpDocTypeName());
        }

//       apiResponse.getSuccess() ? HttpStatus.OK : HttpStatus.BAD_REQUES
       String format;
       format=documentId==10?"PNG":"PDF";

        // Check if the document is PNG (for document ID 10) or PDF (for others)
        if ((documentId == 10 && !file.getContentType().equals("image/png")) || (documentId != 10 && !file.getContentType().equals("application/pdf"))) {
            return new ApiResponse("Please upload your  " + employeeDocType.getEmpDocTypeName() + " in the "+format+" format.", false, file.getOriginalFilename(), employeeDocType.getEmpDocTypeName());
        }

        Employee employee = employeeRepository.findByActiveAndEmployeeId(true, employeeId);

        List<EmployeeDocUpload> employeeDocUploadList = employeeDocUploadRepository.findByActiveAndEmployee_EmployeeIdAndEmpDocType_EmpDocTypeId(true, employeeId, documentId);

        if (!employeeDocUploadList.isEmpty()) {
            employeeDocUploadRepository.deleteAll(employeeDocUploadList);

            // Delete previous entries and their associated files
            for (EmployeeDocUpload oldDoc : employeeDocUploadList) {
                String filePath = oldDoc.getEmpDocPath();
                File fileToDelete = new File(filePath);
                if (fileToDelete.exists()) {
                    fileToDelete.delete();
                }
            }
        }

        String employeeFullName = employee.getEmpFirstName() + employee.getEmpLastName();
        String employeeFolderPath = UPLOAD_DIR + File.separator + employeeId.toString() + employeeFullName;
        File employeeFolder = new File(employeeFolderPath);

        if (!employeeFolder.exists()) {
            employeeFolder.mkdirs();
        }

        String originalFilename = file.getOriginalFilename();
        Path destination = Paths.get(employeeFolderPath + File.separator + originalFilename);

        try {
            Files.copy(file.getInputStream(), destination, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("File uploaded: " + destination);
        } catch (Exception e) {
            e.printStackTrace();
        }

        EmployeeDocUpload employeeDocUpload = new EmployeeDocUpload();
        employeeDocUpload.setEmployee(employee);
        employeeDocUpload.setEmpDocPath(employeeFolderPath + File.separator + originalFilename);
        employeeDocUpload.setEmpDocType(employeeDocType);
        employeeDocUpload.setEmpDocFileType(file.getContentType());
        employeeDocUpload.setEmpDocFileSize(file.getSize());
        employeeDocUpload.setDocOriginalName(file.getOriginalFilename());
        empDocUploadRepository.save(employeeDocUpload);

        return new ApiResponse("Employee " + employeeDocType.getEmpDocTypeName() + " uploaded successfully", true, file.getOriginalFilename(), employeeDocType.getEmpDocTypeName());
    }

    @Override
    public Boolean saveEmployeeDecuments2(List<DocumentRequest> documentRequestList, Integer employeeId) throws IOException{

        Employee employee=employeeRepository.findByActiveAndEmployeeId(true,employeeId);
        String employeeFullName=employee.getEmpFirstName()+employee.getEmpLastName();
        String employeeFolderPath = UPLOAD_DIR + File.separator + employeeId.toString()+employeeFullName;
        File employeeFolder = new File(employeeFolderPath);

        if (!employeeFolder.exists()) {
            employeeFolder.mkdirs();
        }

        for(DocumentRequest documentRequest:documentRequestList)
        {

            EmployeeDocType employeeDocType= employeeDocTypeRepository.findByActiveAndEmpDocTypeId(true,documentRequest.getDocumentId());
            MultipartFile file = documentRequest.getDocumentFile();
            if(file.isEmpty())
            {
//                new FileEmptyException(employeeDocType.getEmpDocTypeName());
            }
            String originalFilename = file.getOriginalFilename();
            Path destination = Paths.get(employeeFolderPath + File.separator + originalFilename);

            try {
                Files.copy(file.getInputStream(), destination, StandardCopyOption.REPLACE_EXISTING);
                System.out.println("File uploaded: " + destination);
            } catch (Exception e) {
                e.printStackTrace();
            }

            EmployeeDocUpload employeeDocUpload=new EmployeeDocUpload();
            employeeDocUpload.setEmployee(employee);
            employeeDocUpload.setEmpDocPath(employeeFolderPath+File.separator+originalFilename);
            employeeDocUpload.setEmpDocType(employeeDocType);
            employeeDocUpload.setEmpDocFileType(file.getContentType());
            employeeDocUpload.setEmpDocFileSize(file.getSize());
            employeeDocUpload.setDocOriginalName(file.getOriginalFilename());
            empDocUploadRepository.save(employeeDocUpload);
        }
        return  true;
    }
    @Override
    public Boolean saveEmployeeDecuments(MultipartFile[] empAllDocuments,Integer employeeId) throws IOException {

        Employee employee=employeeRepository.findByActiveAndEmployeeId(true,employeeId);
        String employeeFullName=employee.getEmpFirstName()+employee.getEmpLastName();
        String employeeFolderPath = UPLOAD_DIR + File.separator + employeeId.toString()+employeeFullName;
        File employeeFolder = new File(employeeFolderPath);

        if (!employeeFolder.exists()) {
            employeeFolder.mkdirs();
        }

        for (int i = 0; i < empAllDocuments.length; i++) {
            MultipartFile file = empAllDocuments[i];


            if (file != null && !file.isEmpty()) {
                String originalFilename = file.getOriginalFilename();
                Path destination = Paths.get(employeeFolderPath + File.separator + originalFilename);

                try {
                    Files.copy(file.getInputStream(), destination, StandardCopyOption.REPLACE_EXISTING);
                    System.out.println("File uploaded: " + destination);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return true;
    }



}