package com.emp.management.emp_management.Controller;

import com.emp.management.emp_management.DTO.Request.SkillRequest;

import com.emp.management.emp_management.DTO.Request.SkillUpdateRequest;
import com.emp.management.emp_management.DTO.Response.EmployeeSkillDTO;
import com.emp.management.emp_management.DTO.Response.SkillResponse;
import com.emp.management.emp_management.DTO.Response.SkillUpdateResponse;
import com.emp.management.emp_management.Service.EmployeeSkillSetService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/v1/employee/skillSets")

public class EmployeeSkillSetController {
    @Autowired
    private EmployeeSkillSetService employeeSkillSetService;

    @PostMapping("/save")

    public SkillResponse saveSkillsForEmployee(@Valid @RequestBody SkillRequest request){


        log.info("SkillController------SaveSkillData--{}",request);
        return employeeSkillSetService.saveSkills(request);
    }

    @GetMapping("/get/{empId}")
    public List<EmployeeSkillDTO> getEmpSkillsById(@PathVariable Integer empId){
        log.info("UserController-----getUserById----{}",empId);
        return this.employeeSkillSetService.getSkillsByEmpId(empId);
    }

    @PutMapping("/edit/{empId}")
    public SkillUpdateResponse editSkillSets(@PathVariable Integer empId , @RequestBody SkillUpdateRequest request){

        log.info("EmployeeSkillSetController------------UpdateSkillsForEmployee",empId,request);
        return this.employeeSkillSetService.editEmployeeSkills(empId,request);
    }


}
