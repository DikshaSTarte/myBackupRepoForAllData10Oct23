package com.emp.management.emp_management.Service;

import com.emp.management.emp_management.DTO.Request.EducationRequest;
import com.emp.management.emp_management.DTO.Request.SchoolRequest;
import com.emp.management.emp_management.DTO.Response.*;
import org.springframework.http.ResponseEntity;
import java.util.List;

public interface EducationDetailsService {
    CollegeResponse saveEmployeeCollegeDetails(EducationRequest request);
    List<EducationDetailDTO> getEducationInfoByEmpId(Integer empId);
    UpgradedEducationDTO updateEducationDetails(EducationRequest request, Integer empId);
    ResponseEntity<String> deleteEducationDetailsById(Integer empEduDetailsId);
}
