package com.emp.management.emp_management.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name= "basic_details")
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeBasicDetails extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "basic_details_id")
    private Integer empBasicDetailsId;

    @OneToOne
    @JoinColumn(name = "employee_id")
    private Employee employee;

    @Column(name = "emp_gender")
    private String empGender;

    @Column(name = "emp_doj")
    private LocalDate empDoj;

    @ManyToOne
    @JoinColumn(name = "employee_status_id")
    private EmpStatus empStatus;


    @Column(name = "emp_nationality")
    private String empNationality;

    @Column(name = "emp_dob")
    private LocalDate empDob;

    @ManyToOne
    @JoinColumn(name = "emp_marital_status_id")
    private EmpMaritalStatus empMaritalStatus;

    @ManyToOne
    @JoinColumn(name = "emp_blood_group_id")
    private EmpBloodGroup empBloodGroup;

//    @OneToOne(mappedBy = "employeeBasicDetails", cascade = CascadeType.ALL)
//    private EmployeeDocUpload employeeDocUpload;

    @Column(name = "emp_anniversary_date")
    private LocalDate empDoa;

    @Column(name = "emp_Former_name")
    private String empFormerName;

    @Column(name = "emp_passport_number")
    private String empPassportNumber;

    @Column(name = "emp_pan_number")
    private String empPanNumber;

    @Column(name = "emp_uan_number")
    private String empUanNumber;

    @Column(name = "emp_licence_number")
    private String empDrLicenceNumber;

    @Column(name = "emp_current_working_location")
    private String empCurrentWorkingLocation;


    // Other attributes
}

