package com.emp.management.emp_management.DTO.Response;


import com.emp.management.emp_management.model.EmpDesignation;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeResponse {

    private Integer employeeId ;
    private String empFirstName ;
    private String empLastName ;
    private String empMiddleName;
    private EmpDesignation empDesignation;
    private String empPhoneNumber;
    private String empOrganizationalMail;

}
