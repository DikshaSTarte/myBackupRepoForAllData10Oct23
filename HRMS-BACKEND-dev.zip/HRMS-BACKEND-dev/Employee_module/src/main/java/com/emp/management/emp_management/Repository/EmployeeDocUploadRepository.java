package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.Employee;
import com.emp.management.emp_management.model.EmployeeDocType;
import com.emp.management.emp_management.model.EmployeeDocUpload;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmployeeDocUploadRepository extends JpaRepository<EmployeeDocUpload,Integer> {



    List<EmployeeDocUpload>  findByActiveAndEmployee_EmployeeIdAndEmpDocType_EmpDocTypeId(boolean b, Integer employeeId, Integer documentId);
   EmployeeDocUpload findOneByActiveAndEmployee_EmployeeIdAndEmpDocType_EmpDocTypeId(boolean b, Integer employeeId, Integer documentId);


    boolean findByActiveAndEmpDocTypeAndEmployee(boolean b, EmployeeDocType employeeDocType, Employee employee);
    boolean existsByActiveAndEmpDocTypeAndEmployee(boolean active, EmployeeDocType empDocType, Employee employee);

    List<EmployeeDocUpload> findByActiveAndEmployee_EmployeeId(boolean b, Integer employeeId);
}
