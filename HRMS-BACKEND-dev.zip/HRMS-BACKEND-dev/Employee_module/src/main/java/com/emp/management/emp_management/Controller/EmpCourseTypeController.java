package com.emp.management.emp_management.Controller;

import com.emp.management.emp_management.DTO.Response.BloodGroupResponse;
import com.emp.management.emp_management.DTO.Response.SpecializationResponse;
import com.emp.management.emp_management.Service.BloodGroupService;
import com.emp.management.emp_management.Service.CourseTypeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/v1/employee/specialization")
public class EmpCourseTypeController {
    @Autowired
    private CourseTypeService service;
    @GetMapping("/list")
    public List<SpecializationResponse> getListOfCourseSpecialization() {
        log.info("CourseTypeController----------getCourseTypes------------{}");
        return this.service.getSpecializationList();
    }
}
