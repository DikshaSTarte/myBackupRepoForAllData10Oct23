package com.emp.management.emp_management.ServiceImpl;

import com.emp.management.emp_management.DTO.Request.EmployeePreCompanyRequest;
import com.emp.management.emp_management.DTO.Response.EmployeeHistoryResponse;
import com.emp.management.emp_management.DTO.Response.EmployeePreCompanyResponse;
import com.emp.management.emp_management.Repository.EmployeeHistoryRepository;
import com.emp.management.emp_management.Repository.EmployeePreCompanyRepository;
import com.emp.management.emp_management.Service.EmployeePreCompanyService;
import com.emp.management.emp_management.model.EmployeePreCompany;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeePreCompanyServiceImpl implements EmployeePreCompanyService {

    @Autowired
    private EmployeePreCompanyRepository employeePreCompanyRepository;
    @Autowired
    private EmployeeHistoryRepository employeeHistoryRepository;
    @Override
    public EmployeePreCompanyResponse saveEmployeePreCompany(EmployeePreCompanyRequest employeePreCompanyRequest) {
        EmployeePreCompany employeePreCompany=new EmployeePreCompany();
        employeePreCompany.setEmpHistory(employeeHistoryRepository.findByActiveAndEmpHistoryId(true,employeePreCompanyRequest.getEmpHistoryId()));
        employeePreCompany.setEmpPreCompanyDuration(employeePreCompanyRequest.getEmpPreCompanyDuration());
        employeePreCompany.setEmpPreCompanyName(employeePreCompanyRequest.getEmpPreCompanyName());
        employeePreCompany.setEmpLeavingReason(employeePreCompanyRequest.getEmpLeavingReason());

        employeePreCompany.setEmpPastDesignation(employeePreCompanyRequest.getEmpPastDesignation());
        employeePreCompany.setEmpPastSalaryDrawn(employeePreCompanyRequest.getEmpPastSalaryDrawn());
        employeePreCompany.setEmpPastKeyResponsibilities(employeePreCompanyRequest.getEmpPastKeyResponsibilities());
        EmployeePreCompany saveEmployeePreCompany=this.employeePreCompanyRepository.save(employeePreCompany);
        EmployeePreCompanyResponse employeePreCompanyResponse=employeePreCompanyEntityToEmployeePreCompanyResponse(saveEmployeePreCompany);
        return employeePreCompanyResponse;
    }

    EmployeePreCompanyResponse employeePreCompanyEntityToEmployeePreCompanyResponse(EmployeePreCompany employeePreCompany) {
        EmployeePreCompanyResponse employeePreCompanyResponse=new EmployeePreCompanyResponse();
        employeePreCompanyResponse.setEmpPreCompanyId(employeePreCompany.getEmpPreCompanyId());
        employeePreCompanyResponse.setEmpPreCompanyDuration(employeePreCompany.getEmpPreCompanyDuration());
        employeePreCompanyResponse.setEmpPreCompanyName(employeePreCompany.getEmpPreCompanyName());

        employeePreCompanyResponse.setEmpLeavingReason(employeePreCompany.getEmpLeavingReason());
        employeePreCompanyResponse.setEmpPastKeyResponsibilities(employeePreCompany.getEmpPastKeyResponsibilities());
        employeePreCompanyResponse.setEmpPastDesignation(employeePreCompany.getEmpPastDesignation());
        employeePreCompanyResponse.setEmpPastSalaryDrawn(employeePreCompany.getEmpPastSalaryDrawn());
        employeePreCompanyResponse.setEmpHistory(new EmployeeHistoryResponse(employeePreCompany.getEmpHistory().getEmpHistoryId(),employeePreCompany.getEmpHistory().getEmployee().getEmployeeId(),employeePreCompany.getEmpHistory().getEmpExperience()));

        return employeePreCompanyResponse;
    }

    @Override
    public List<EmployeePreCompanyResponse> listEmployeePreCompany() {
        List<EmployeePreCompany> employeePreCompanys=employeePreCompanyRepository.findByActiveOrderByCreatedOnAsc(true);
        List<EmployeePreCompanyResponse> employeePreCompanyResponseList = new ArrayList<>();
        for (EmployeePreCompany employeePreCompany : employeePreCompanys) {
            employeePreCompanyResponseList.add(employeePreCompanyEntityToEmployeePreCompanyResponse(employeePreCompany));
        }
        return employeePreCompanyResponseList;

    }

    @Override
    public String deleteEmpPreCompanyById(Integer empPreCompanyId) {

        Optional<EmployeePreCompany> employeePreCompany = employeePreCompanyRepository.findById(empPreCompanyId);
        employeePreCompany.get().setActive(false);
        employeePreCompanyRepository.save(employeePreCompany.get());

        return "EmployeePreCompany Successfully Deleted";
    }
    @Override
    public EmployeePreCompanyResponse updateEmployeePreCompanyById(Integer empPreCompanyId, EmployeePreCompanyRequest employeePreCompanyRequest){
        EmployeePreCompany employeePreCompany=employeePreCompanyRepository.findByActiveAndEmpPreCompanyId(true,empPreCompanyId);
        employeePreCompany.setEmpHistory(employeeHistoryRepository.findByActiveAndEmpHistoryId(true,employeePreCompanyRequest.getEmpHistoryId()));
        employeePreCompany.setEmpPreCompanyDuration(employeePreCompanyRequest.getEmpPreCompanyDuration());
        employeePreCompany.setEmpPreCompanyName(employeePreCompanyRequest.getEmpPreCompanyName());
        employeePreCompany.setEmpLeavingReason(employeePreCompanyRequest.getEmpLeavingReason());

        employeePreCompany.setEmpPastDesignation(employeePreCompanyRequest.getEmpPastDesignation());
        employeePreCompany.setEmpPastSalaryDrawn(employeePreCompanyRequest.getEmpPastSalaryDrawn());
        employeePreCompany.setEmpPastKeyResponsibilities(employeePreCompanyRequest.getEmpPastKeyResponsibilities());
        EmployeePreCompany update=this.employeePreCompanyRepository.save(employeePreCompany);
        EmployeePreCompanyResponse employeePreCompanyResponse=employeePreCompanyEntityToEmployeePreCompanyResponse(update);
        return employeePreCompanyResponse;

    }
}

