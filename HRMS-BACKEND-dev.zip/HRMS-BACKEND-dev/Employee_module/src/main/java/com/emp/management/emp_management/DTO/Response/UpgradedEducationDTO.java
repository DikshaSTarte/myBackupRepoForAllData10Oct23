package com.emp.management.emp_management.DTO.Response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UpgradedEducationDTO {
    private Integer educationDetailsId;
    private String updatedDistrict;
    private String updatedInstituteName;
    private String updatedUniversityName;
    private float updatedMarks;
    private MediumResponse updatedMedium;
    private EduTypeResponse updatedEducationType;
    private LearningTypeResponse updatedCourseType;
    private SpecializationResponse updatedSpecialization;
    private CourseResponse updatedCourseResponse;
}
