package com.emp.management.emp_management.Service;

import com.emp.management.emp_management.DTO.Response.EduTypeResponse;
import com.emp.management.emp_management.DTO.Response.EnumResponse;

import java.util.List;

public interface EmpEducationTypeService {

    List<EduTypeResponse> getEducationTypeList();
}
