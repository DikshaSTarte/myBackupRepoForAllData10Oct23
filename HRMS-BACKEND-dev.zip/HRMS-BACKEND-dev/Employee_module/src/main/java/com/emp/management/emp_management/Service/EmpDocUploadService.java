package com.emp.management.emp_management.Service;

import com.emp.management.emp_management.DTO.Request.DocumentRequest;
import com.emp.management.emp_management.DTO.Request.EmpDocsUploadRequest;

import com.emp.management.emp_management.DTO.Response.ApiResponse;
import com.emp.management.emp_management.DTO.Response.EmpDoctypeResponse;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface EmpDocUploadService {

    Boolean saveEmployeeDecuments(MultipartFile[] empAllDocuments,Integer employeeId) throws IOException;
    Boolean saveEmployeeDecuments2(List<DocumentRequest> documentRequestList, Integer employeeId) throws IOException;


//    ApiResponse saveEmployeeDecuments3(MultipartFile file, Integer employeeId, Integer documentId,boolean update)throws IOException;
    ApiResponse saveEmployeeDocuments3(MultipartFile file, Integer employeeId, Integer documentId, boolean update) throws IOException;
    List<EmpDoctypeResponse> getListDocumetsUploaded(Integer employeeId);

    ApiResponse deleteFileById(Integer employeeId, Integer docTypeId);

}
