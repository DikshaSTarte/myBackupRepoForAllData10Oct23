package com.emp.management.emp_management.DTO.Response;

import com.emp.management.emp_management.model.EmployeeHistory;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeePreCompanyResponse {


    private Integer empPreCompanyId;
    private EmployeeHistoryResponse empHistory;
    private String empPreCompanyName;
    private float empPreCompanyDuration;
    private String empPastDesignation;
    private String empPastKeyResponsibilities;
    private float empPastSalaryDrawn;
    private String empLeavingReason;


}
