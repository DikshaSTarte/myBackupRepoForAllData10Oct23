package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.Courses;
import com.emp.management.emp_management.model.Employee;
import com.emp.management.emp_management.model.EmployeeEducationDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmpEducationDetailsRepository extends JpaRepository<EmployeeEducationDetails,Integer> {
    EmployeeEducationDetails findByEmpInstituteName(String empInstituteName);

    EmployeeEducationDetails findByEmployee_employeeIdAndEmpInstituteName(Integer empId, String empInstituteName);

    EmployeeEducationDetails findByActiveAndEmployee_employeeIdAndEmployeeEducationType_empEducationTypeId(boolean b, Integer empId, Integer educationTypeId);

    Integer findByEmployeeEducationType_empEducationTypeId(Integer empEducationTypeId);

    EmployeeEducationDetails findByActiveAndSpecializations_courses_courseId(boolean b, Courses courses);
    EmployeeEducationDetails findByActiveAndEmpEducationDetailsId(boolean b, Integer empEduDetailsId);

    EmployeeEducationDetails findByMedium_mediumId(Integer mediumId);


    EmployeeEducationDetails findByActiveAndEmployee_employeeIdAndMedium_mediumIdAndEmployeeEducationType_empEducationTypeId(boolean b, Integer empId, Integer mediumId, int i);

//    EmployeeEducationDetails findByActiveAndEmployee_employeeIdAndEducationType_EmpEducationTypeId(boolean b, Employee empId, Integer educationTypeId);

//    EmployeeEducationDetails findByActiveAndEmployee_employeeIdAndEmployeeEducationType_EmpEducationTypeId(boolean b, Employee empId, Integer educationTypeId);
}
