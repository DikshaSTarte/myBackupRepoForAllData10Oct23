package com.emp.management.emp_management.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "employee_doc_upload")
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeDocUpload extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "emp_doc_id")
    private Integer empDocId;

    @ManyToOne
    @JoinColumn(name = "employee_id")
    private Employee employee;

    @ManyToOne
    @JoinColumn(name = "emp_doc_type_id")
    private EmployeeDocType empDocType;

    @Column(name = "emp_doc_path")
    private String empDocPath;

    @Column(name = "emp_doc_file_size")
    private long empDocFileSize;

    @Column(name = "emp_doc_file_type")
    private String empDocFileType;

    @Column(name = "doc_OriginalName")
    private String docOriginalName;

    // Other attributes

}

