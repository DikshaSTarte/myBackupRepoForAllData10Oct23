package com.emp.management.emp_management.DTO.Request;

import com.emp.management.emp_management.model.EmployeeHistory;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Positive;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeePreCompanyRequest {

    private Integer empHistoryId;

    @NotBlank(message = "empPreCompanyName cannot be blank")
    private String empPreCompanyName;

    @Positive(message = "empPreCompanyDuration must be a positive value")
    private float empPreCompanyDuration;

    @NotBlank(message = "empPastDesignation cannot be blank")
    private String empPastDesignation;

    @NotBlank(message = "empPastKeyResponsibilities cannot be blank")
    private String empPastKeyResponsibilities;

    @Positive(message = "empPastSalaryDrawn must be a positive value")
    private float empPastSalaryDrawn;

    @NotBlank(message = "empLeavingReason cannot be blank")
    private String empLeavingReason;
}
