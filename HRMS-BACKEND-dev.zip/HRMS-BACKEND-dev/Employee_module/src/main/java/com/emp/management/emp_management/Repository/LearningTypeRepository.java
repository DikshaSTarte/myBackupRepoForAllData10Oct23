package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.LearningTypes;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LearningTypeRepository extends JpaRepository<LearningTypes,Integer> {
}
