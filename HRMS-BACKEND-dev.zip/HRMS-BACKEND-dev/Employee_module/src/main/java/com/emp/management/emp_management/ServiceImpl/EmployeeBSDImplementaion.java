package com.emp.management.emp_management.ServiceImpl;

import com.emp.management.emp_management.DTO.Request.EmpAddressRequest;
import com.emp.management.emp_management.DTO.Request.EmployeeSaveRequest;
import com.emp.management.emp_management.DTO.Response.*;
import com.emp.management.emp_management.Repository.*;
import com.emp.management.emp_management.Service.EmployeeBasicDetailsService;
import com.emp.management.emp_management.model.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class EmployeeBSDImplementaion implements EmployeeBasicDetailsService {

    @Autowired
    private EmpBloodGroupRepository empBloodGroupRepository;

    @Autowired
    private EmpMarritalStatusRepository empMarritalStatusRepository;

    @Autowired
    private EmpAddressTypeRepository empAddressTypeRepository;

    @Autowired
    private EmpStatusRepository empStatusRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private ContactDetailsRepository contactDetailsRepository;

    @Autowired
    private  EmployeeBasicDetailsRepository employeeBasicDetailsRepository;

    @Autowired
    private EmployeeAddressRepository employeeAddressRepository;
    @Autowired
    private EmpDepartmentRepository empDepartmentRepository;

    @Autowired
    private EmpDesignationRepository empDesignationRepository;

    @Autowired
    private EmployeeHistoryRepository employeeHistoryRepository;




    @Override
   public EmployeeBasicDetailsResponse updateEmployeeBasicDetails(Integer employeeId,EmployeeSaveRequest employeeSaveRequest){
        Employee employee=employeeRepository.findByActiveAndEmployeeId(true,employeeId);
        employee.setEmpFirstName(employeeSaveRequest.getEmpFirstName());
        employee.setEmpMiddleName(employeeSaveRequest.getEmpMiddleName());
        employee.setEmpLastName(employeeSaveRequest.getEmpLastName());
        EmpDesignation empDesignation=empDesignationRepository.findByActiveAndEmpDesignationId(true,employeeSaveRequest.getEmpDesignationId());
        EmpDepartment empDepartment=empDesignation.getEmpDepartment();
        //employee.setEmpDep(empDepartment);
        employee.setEmpDesignation(empDesignation);
        Employee save = employeeRepository.save(employee);

        System.out.println("**************************Employee updated successfully*****************************");

        ContactDetails contactDetails=contactDetailsRepository.findByActiveAndEmployee_EmployeeId(true,employeeId);
        contactDetails.setPhoneNumber(employeeSaveRequest.getEmpPhoneNumber());
        contactDetails.setPersonalEmail(employeeSaveRequest.getEmpEmailAddress());
        contactDetails.setEmployee(employee);
        contactDetails.setTelephoneNumber(employeeSaveRequest.getEmpTelephoneNumber());
        contactDetails.setOrganizationalEmail(employeeSaveRequest.getEmpOrganizationalMail());
        contactDetailsRepository.save(contactDetails);

        System.out.println("**************************Employee CONTACT updated successfully*****************************");


        EmployeeHistory employeeHistory=employeeHistoryRepository.findByActiveAndEmployee_EmployeeId(true,employeeId);
        employeeHistory.setEmployee(employee);
        employeeHistory.setEmpExperience(employeeSaveRequest.getEmpTotalExperience());
        employeeHistoryRepository.save(employeeHistory);

        System.out.println("**************************Employee HISTORY updated successfully*****************************");


        EmployeeBasicDetails employeeBasicDetails=employeeBasicDetailsRepository.findByActiveAndEmployee_EmployeeId(true,employeeId);
        employeeBasicDetails.setEmployee(employee);
        employeeBasicDetails.setEmpDob(employeeSaveRequest.getEmpDob());
        employeeBasicDetails.setEmpDoj(employeeSaveRequest.getEmpDoj());
        employeeBasicDetails.setEmpDoa(employeeSaveRequest.getEmpDoa());
        employeeBasicDetails.setEmpNationality(employeeSaveRequest.getEmpNationality());
        employeeBasicDetails.setEmpGender(employeeSaveRequest.getEmpGender());
        EmpBloodGroup empBloodGroup=empBloodGroupRepository.findByActiveAndEmpBloodGroupId(true,employeeSaveRequest.getEmpBloodGroupId());
        employeeBasicDetails.setEmpBloodGroup(empBloodGroup);
        EmpMaritalStatus empMaritalStatus=empMarritalStatusRepository.findByActiveAndEmpMaritalStatusId(true,employeeSaveRequest.getEmpMarritalStatusId());
        employeeBasicDetails.setEmpMaritalStatus(empMaritalStatus);

        for(EmpAddressRequest empAddressRequest:employeeSaveRequest.getEmpAddressRequestList())
        {
            EmployeeAddress employeeAddress=employeeAddressRepository.findByActiveAndEmployee_EmployeeIdAndEmpAddType_EmpAddTypeId(true,employeeId,empAddressRequest.getEmpAddressTypeId());
            employeeAddress.setAddPincode(empAddressRequest.getEmpAddPincode());
            employeeAddress.setAddLandmark(empAddressRequest.getEmpAddLandMark());
            employeeAddress.setEmployee(employee);
            EmpAddressType empAddressType=empAddressTypeRepository.findByActiveAndEmpAddTypeId(true,empAddressRequest.getEmpAddressTypeId());
            employeeAddress.setEmpAddType(empAddressType);
            employeeAddress.setDetailAddress(empAddressRequest.getEmpDetailedAddress());
            employeeAddressRepository.save(employeeAddress);
        }
        System.out.println("**************************Employee ADDRESS updated successfully*****************************");


        EmpStatus empStatus=empStatusRepository.findByActiveAndEmployeeStatusId(true,employeeSaveRequest.getEmpStatus());
        employeeBasicDetails.setEmpStatus(empStatus);

        EmployeeBasicDetailsResponse employeeBasicDetailsResponse2=new EmployeeBasicDetailsResponse();
        employeeBasicDetailsResponse2.setEmployee(save);
        employeeBasicDetailsResponse2.setEmployeeHistoryId(employeeHistory.getEmpHistoryId());
        employeeBasicDetails.setEmpPanNumber(employeeSaveRequest.getEmpPanNumber());
        employeeBasicDetails.setEmpDrLicenceNumber(employeeSaveRequest.getEmpDrLicenceNumber());
        employeeBasicDetails.setEmpUanNumber(employeeSaveRequest.getEmpUanNumber());
        employeeBasicDetails.setEmpPassportNumber(employeeSaveRequest.getEmpPassportNumber());
        employeeBasicDetails.setEmpFormerName(employeeSaveRequest.getEmpFormerName());
        employeeBasicDetails.setEmpCurrentWorkingLocation(employeeSaveRequest.getEmpCurrentWorkingLocation());
        employeeBasicDetailsRepository.save(employeeBasicDetails);

        System.out.println("**************************Employee BASIC DETAILS updated successfully*****************************");
        return employeeBasicDetailsResponse2;

    }
  @Override
 public EmployeeBasicDetailsResponse saveEmployeeBasicDetails(EmployeeSaveRequest employeeSaveRequest)
  {
      Employee employee=new Employee();
      employee.setEmpFirstName(employeeSaveRequest.getEmpFirstName());
      employee.setEmpMiddleName(employeeSaveRequest.getEmpMiddleName());
      employee.setEmpLastName(employeeSaveRequest.getEmpLastName());

      EmpDesignation empDesignation=empDesignationRepository.findByActiveAndEmpDesignationId(true,employeeSaveRequest.getEmpDesignationId());
      EmpDepartment empDepartment=empDesignation.getEmpDepartment();
      //employee.setEmpDep(empDepartment);
      employee.setEmpDesignation(empDesignation);
      employeeRepository.save(employee);
      ContactDetails contactDetails=new ContactDetails();
      contactDetails.setPhoneNumber(employeeSaveRequest.getEmpPhoneNumber());
      contactDetails.setPersonalEmail(employeeSaveRequest.getEmpEmailAddress());
      contactDetails.setEmployee(employee);
      contactDetails.setTelephoneNumber(employeeSaveRequest.getEmpTelephoneNumber());
      contactDetails.setOrganizationalEmail(employeeSaveRequest.getEmpOrganizationalMail());
      contactDetailsRepository.save(contactDetails);
      EmployeeHistory employeeHistory=new EmployeeHistory();
      employeeHistory.setEmployee(employee);
      employeeHistory.setEmpExperience(employeeSaveRequest.getEmpTotalExperience());
      employeeHistoryRepository.save(employeeHistory);
//      employee.setContactDetails(contactDetails);
      EmployeeBasicDetails employeeBasicDetails=new EmployeeBasicDetails();
      employeeBasicDetails.setEmployee(employee);
      employeeBasicDetails.setEmpDob(employeeSaveRequest.getEmpDob());
      employeeBasicDetails.setEmpDoj(employeeSaveRequest.getEmpDoj());
      employeeBasicDetails.setEmpDoa(employeeSaveRequest.getEmpDoa());
      employeeBasicDetails.setEmpNationality(employeeSaveRequest.getEmpNationality());
      employeeBasicDetails.setEmpGender(employeeSaveRequest.getEmpGender());
      EmpBloodGroup empBloodGroup=empBloodGroupRepository.findByActiveAndEmpBloodGroupId(true,employeeSaveRequest.getEmpBloodGroupId());
      employeeBasicDetails.setEmpBloodGroup(empBloodGroup);
      EmpMaritalStatus empMaritalStatus=empMarritalStatusRepository.findByActiveAndEmpMaritalStatusId(true,employeeSaveRequest.getEmpMarritalStatusId());
      employeeBasicDetails.setEmpMaritalStatus(empMaritalStatus);
      for(EmpAddressRequest empAddressRequest:employeeSaveRequest.getEmpAddressRequestList())
      {
          EmployeeAddress employeeAddress=new EmployeeAddress();
          employeeAddress.setAddPincode(empAddressRequest.getEmpAddPincode());
          employeeAddress.setAddLandmark(empAddressRequest.getEmpAddLandMark());
          employeeAddress.setEmployee(employee);
          EmpAddressType empAddressType=empAddressTypeRepository.findByActiveAndEmpAddTypeId(true,empAddressRequest.getEmpAddressTypeId());
          employeeAddress.setEmpAddType(empAddressType);
          employeeAddress.setDetailAddress(empAddressRequest.getEmpDetailedAddress());
          employeeAddressRepository.save(employeeAddress);
      }
      employeeBasicDetails.setEmpPanNumber(employeeSaveRequest.getEmpPanNumber());
      employeeBasicDetails.setEmpDrLicenceNumber(employeeSaveRequest.getEmpDrLicenceNumber());
      employeeBasicDetails.setEmpUanNumber(employeeSaveRequest.getEmpUanNumber());
      employeeBasicDetails.setEmpPassportNumber(employeeSaveRequest.getEmpPassportNumber());
      employeeBasicDetails.setEmpFormerName(employeeSaveRequest.getEmpFormerName());
      employeeBasicDetails.setEmpCurrentWorkingLocation(employeeSaveRequest.getEmpCurrentWorkingLocation());
//      EmployeeAddress employeeAddress=new EmployeeAddress();
//      employeeAddress.setAddPincode(employeeSaveRequest.getEmpAddPincode());
//      employeeAddress.setAddLandmark(employeeSaveRequest.getEmpAddLandMark());
//      employeeAddress.setEmployee(employee);
//      EmpAddressType empAddressType=empAddressTypeRepository.findByActiveAndEmpAddTypeId(true,employeeSaveRequest.getEmpAddressTypeId());
//      employeeAddress.setEmpAddType(empAddressType);
//      employeeAddress.setDetailAddress(employeeSaveRequest.getEmpDetailedAddress());
//      employeeAddressRepository.save(employeeAddress);
      EmpStatus empStatus=empStatusRepository.findByActiveAndEmployeeStatusId(true,employeeSaveRequest.getEmpMarritalStatusId());
      employeeBasicDetails.setEmpStatus(empStatus);
      EmployeeBasicDetailsResponse employeeBasicDetailsResponse=new EmployeeBasicDetailsResponse();
      employeeBasicDetailsResponse.setEmployee(employee);
      employeeBasicDetailsResponse.setEmployeeHistoryId(employeeHistory.getEmpHistoryId());
      employeeBasicDetailsRepository.save(employeeBasicDetails);
      return employeeBasicDetailsResponse;
  }

    @Override
    public List<EmployeeBasicDetailDtoResponse> getEmployeeBasicDetailByEmpId(Integer employeeId) {
List<EmployeeBasicDetailDtoResponse> employeeBasicDetailDtoResponseList=new ArrayList<>();
        Employee employee= employeeRepository.findByActiveAndEmployeeId(true,employeeId);
List<EmployeeBasicDetails> employeeBasicDetailList=employeeBasicDetailsRepository.findAllByActiveAndEmployee_EmployeeId(true,employee.getEmployeeId());
        for(EmployeeBasicDetails employeeBasicDetails:employeeBasicDetailList) {
            EmployeeBasicDetailDtoResponse employeeBasicDetailDtoResponse=new EmployeeBasicDetailDtoResponse();
            employeeBasicDetailDtoResponse.setEmpBasicDetailsId(employeeBasicDetails.getEmpBasicDetailsId());
            employeeBasicDetailDtoResponse.setEmpGender(employeeBasicDetails.getEmpGender());
            employeeBasicDetailDtoResponse.setEmpDoj(employeeBasicDetails.getEmpDoj());
            employeeBasicDetailDtoResponse.setEmpDoa(employeeBasicDetails.getEmpDoa());
            employeeBasicDetailDtoResponse.setEmpNationality(employeeBasicDetails.getEmpNationality());
            employeeBasicDetailDtoResponse.setEmpDob(employeeBasicDetails.getEmpDob());
          EmployeeHistory employeeHistory=employeeHistoryRepository.findByActiveAndEmployee_EmployeeId(true,employeeId);
          float totalExperience= employeeHistory.getEmpExperience();
          employeeBasicDetailDtoResponse.setEmpHistoryExperience(totalExperience);
            employeeBasicDetailDtoResponse.setEmpFormerName(employeeBasicDetails.getEmpFormerName());
            employeeBasicDetailDtoResponse.setEmpPanNumber(employeeBasicDetails.getEmpPanNumber());
            employeeBasicDetailDtoResponse.setEmpPassportNumber(employeeBasicDetails.getEmpPassportNumber());
            employeeBasicDetailDtoResponse.setEmpUanNumber(employeeBasicDetails.getEmpUanNumber());
            employeeBasicDetailDtoResponse.setEmpCurrentWorkingLocation(employeeBasicDetails.getEmpCurrentWorkingLocation());
            employeeBasicDetailDtoResponse.setEmpDrLicenceNumber(employeeBasicDetails.getEmpDrLicenceNumber());


            employeeBasicDetailDtoResponse.setEmployee(new EmpResponse(employeeBasicDetails.getEmployee().getEmployeeId(),employeeBasicDetails.getEmployee().getEmpFirstName(),employeeBasicDetails.getEmployee().getEmpMiddleName(),employeeBasicDetails.getEmployee().getEmpLastName()));
            employeeBasicDetailDtoResponse.setEmpStatus(new EmpStatusResponse(employeeBasicDetails.getEmpStatus().getEmployeeStatusId(),employeeBasicDetails.getEmpStatus().getEmpStatusName()));
            employeeBasicDetailDtoResponse.setEmpBloodGroup(new BloodGroupResponse(employeeBasicDetails.getEmpBloodGroup().getEmpBloodGroupId(),employeeBasicDetails.getEmpBloodGroup().getEmpBloodGroupName()));
            employeeBasicDetailDtoResponse.setEmpMaritalStatus(new EmpMaritalStatusResponse(employeeBasicDetails.getEmpMaritalStatus().getEmpMaritalStatusId(),employeeBasicDetails.getEmpMaritalStatus().getEmpMaritalStatusName()));
           DesignationResponse response = new DesignationResponse();
           response.setEmpDesignationId(employeeBasicDetails.getEmployee().getEmpDesignation().getEmpDesignationId());
           response.setEmpDesignationName(employeeBasicDetails.getEmployee().getEmpDesignation().getEmpDesignationName());
            DepartmentResponse response1 = new DepartmentResponse();
            response1.setEmpDepartmentId(employeeBasicDetails.getEmployee().getEmpDesignation().getEmpDepartment().getEmpDepartmentId());
            response1.setEmpDepartmentName(employeeBasicDetails.getEmployee().getEmpDesignation().getEmpDepartment().getEmpDepartmentName());
           response.setEmpDepartment(response1);
            employeeBasicDetailDtoResponse.setDesignation(response);
//           employeeBasicDetailDtoResponse.setDepartment(new DepartmentResponse(employeeBasicDetails.getEmployee().getEmpDesignation().getEmpDepartment().getEmpDepartmentId(),
//                   employeeBasicDetails.getEmployee().getEmpDesignation().getEmpDepartment().getEmpDepartmentName()));

            List<EmployeeAddress> address= employeeAddressRepository.findByActiveAndEmployee_EmployeeId(true,employee.getEmployeeId());

            List<EmployeeAddressDTO> employeeAddressDTOS=new ArrayList<>();
            for (EmployeeAddress employeeAddress:address){
            EmployeeAddressDTO employeeAddressDTO=new EmployeeAddressDTO();
            employeeAddressDTO.setEmpAddId(employeeAddress.getEmpAddId());
            employeeAddressDTO.setEmpAddressType(new EmpAddressTypeResponse(employeeAddress.getEmpAddType().getEmpAddTypeId(),employeeAddress.getEmpAddType().getEmpAddTypeName()));
            employeeAddressDTO.setDetailAddress(employeeAddress.getDetailAddress());
            employeeAddressDTO.setAddLandmark(employeeAddress.getAddLandmark());
            employeeAddressDTO.setAddPincode(employeeAddress.getAddPincode());
            employeeAddressDTOS.add(employeeAddressDTO);
            }
            employeeBasicDetailDtoResponse.setEmployeeAddressDTO(employeeAddressDTOS);




           ContactDetailsResponse response3 = new ContactDetailsResponse();
            response3.setContactId(employeeBasicDetails.getEmployee().getContactDetails().getContactId());
            response3.setPersonalEmail(employeeBasicDetails.getEmployee().getContactDetails().getPersonalEmail());
              response3.setOrganizationalEmail(employeeBasicDetails.getEmployee().getContactDetails().getOrganizationalEmail());
              response3.setPhoneNumber(employeeBasicDetails.getEmployee().getContactDetails().getPhoneNumber());
            employeeBasicDetailDtoResponse.setContactDetails(response3);

            employeeBasicDetailDtoResponseList.add(employeeBasicDetailDtoResponse);
        }
        return employeeBasicDetailDtoResponseList;
    }

}
