package com.emp.management.emp_management.ServiceImpl;

import com.emp.management.emp_management.DTO.Response.EnumResponse;
import com.emp.management.emp_management.Service.LearningTypeService;

import com.emp.management.emp_management.model.Enum.CourseTypes;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class LearningTypeServiceImpl implements LearningTypeService {
    @Override
    public List<EnumResponse> getLearningTypeList() {
            List<EnumResponse> responseList = new ArrayList<>();
            for (CourseTypes learningTypes : CourseTypes.values()) {
                EnumResponse response = new EnumResponse(
                        learningTypes.name(),
                        learningTypes.ordinal(),
                        learningTypes.getDescription()
                );
                responseList.add(response);
            }
            return responseList;
    }

}
