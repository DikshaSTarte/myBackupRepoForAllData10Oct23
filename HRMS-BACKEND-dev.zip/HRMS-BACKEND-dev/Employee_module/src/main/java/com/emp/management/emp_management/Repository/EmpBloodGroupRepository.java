package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.EmpBloodGroup;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmpBloodGroupRepository extends JpaRepository<EmpBloodGroup, Integer> {
    EmpBloodGroup findByActiveAndEmpBloodGroupId(boolean active, Integer empBloodGroupId);

    List<EmpBloodGroup> findByActive(boolean b);
}
