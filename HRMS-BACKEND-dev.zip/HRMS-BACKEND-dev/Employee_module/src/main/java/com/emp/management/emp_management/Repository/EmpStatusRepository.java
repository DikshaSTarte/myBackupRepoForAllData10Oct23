package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.EmpStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmpStatusRepository extends JpaRepository< EmpStatus,Integer> {
    EmpStatus findByActiveAndEmployeeStatusId(boolean b, Integer empMarritalStatusId);
}
