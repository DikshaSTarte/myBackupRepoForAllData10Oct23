package com.emp.management.emp_management.model.Enum;

public enum GenderEnum {
    MALE,
    FEMALE,
    TRANSGENDER

}
