package com.emp.management.emp_management.Controller;

import com.emp.management.emp_management.DTO.Response.BloodGroupResponse;
import com.emp.management.emp_management.DTO.Response.CourseResponse;
import com.emp.management.emp_management.Service.CourseService;
import com.emp.management.emp_management.Service.CourseTypeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/v1/employee/courses")
public class EmpCourseController {
    @Autowired
    private CourseService service ;
    @GetMapping("/list")
    public List<CourseResponse> getListOfCourseTypes() {
        log.info("CourseTypeController----------getCourseTypes------------{}");
        return this.service.getCourseList();
    }
    @GetMapping("/get/{educationTypeId}")
    public List<CourseResponse> getListOfCourseByEducationType(@PathVariable Integer educationTypeId) {
        log.info("CourseTypeController----------getCourseTypes------------{}");
        return this.service.getCourseListByEducationType(educationTypeId);
    }
}
