package com.emp.management.emp_management.ServiceImpl;

import com.emp.management.emp_management.DTO.Response.OccupationResponse;
import com.emp.management.emp_management.Repository.OccupationRepository;
import com.emp.management.emp_management.Service.OccupationService;
import com.emp.management.emp_management.mapper.ListingMapper;
import com.emp.management.emp_management.model.Occupation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OccupationServiceImpl implements OccupationService {
    @Autowired
    private OccupationRepository occupationRepository;
    @Autowired
    private ListingMapper listingMapper;
    @Override
    public List<OccupationResponse> listOccupation() {
        List<Occupation> occupation=occupationRepository.findByActive(true);
        return listingMapper.occupationListMapper(occupation);

    }
}