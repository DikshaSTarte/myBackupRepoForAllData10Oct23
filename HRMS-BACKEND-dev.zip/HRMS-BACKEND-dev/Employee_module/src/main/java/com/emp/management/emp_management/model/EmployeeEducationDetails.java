package com.emp.management.emp_management.model;

import com.emp.management.emp_management.model.Enum.CourseTypes;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "Employee_Education_Details")
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeEducationDetails extends BaseEntity{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "employee_education_details_id")
    private Integer empEducationDetailsId;

    @ManyToOne
    @JoinColumn(name = "employee_id")
    private Employee employee;

    @Column(name = "employee_institute_name")
    private String empInstituteName;

    @Column(name = "employee_university_name",columnDefinition = "NA")
    private String empUniversityName;

    @Column(name = "employee_year_of_passing")
    private String empYearOfPassing;

    @Column(name = "employee_percentage")
    private float empPercentage;

    @Column(name = "emp_district")
    private String district;

    @ManyToOne
    @JoinColumn(name = "employee_medium")
    private EducationMedium medium;

    @ManyToOne
    @JoinColumn(name = "emp_specialization",columnDefinition = "NA")
    private Specializations specializations;

    @ManyToOne
    @JoinColumn(name = "edu_learning_type")
    private LearningTypes type;

    @ManyToOne
    @JoinColumn(name = "education_type_id")
    private EmployeeEducationType employeeEducationType;

    @ManyToOne
    @JoinColumn(name = "grading_system")
    private GradingSystem gradingSystem;

}
