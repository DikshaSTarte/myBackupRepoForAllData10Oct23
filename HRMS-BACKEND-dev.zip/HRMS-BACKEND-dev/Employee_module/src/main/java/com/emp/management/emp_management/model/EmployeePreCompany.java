package com.emp.management.emp_management.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "employee_pre_company")
@AllArgsConstructor
@NoArgsConstructor
public class EmployeePreCompany extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "emp_pre_company_id")
    private Integer empPreCompanyId;

    @ManyToOne
    @JoinColumn(name = "emp_history_id")
    private EmployeeHistory empHistory;

    @Column(name = "emp_pre_company_name")
    private String empPreCompanyName;

    @Column(name = "emp_pre_company_duration")
    private float empPreCompanyDuration;

    @Column(name = "emp_past_designation")
    private String empPastDesignation;

    @Column(name = "emp_past_key_responsibilities")
    private String empPastKeyResponsibilities;//tinytext

    @Column(name = "emp_past_salary_drawn")
    private float empPastSalaryDrawn;

    @Column(name = "emp_leaving_reason")
    private String empLeavingReason;
}
