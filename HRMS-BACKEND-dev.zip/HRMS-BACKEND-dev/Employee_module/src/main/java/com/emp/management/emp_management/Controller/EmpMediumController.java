package com.emp.management.emp_management.Controller;

import com.emp.management.emp_management.DTO.Response.MediumResponse;
import com.emp.management.emp_management.Service.MediumService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/v1/employee/medium")
public class EmpMediumController {
    @Autowired
    private MediumService service ;
    @GetMapping("/list")
    public List<MediumResponse> getListOfBloodGroups() {
        log.info("MediumController----------getAllMedia------------{}");
        return this.service.getMediumList();
    }
}
