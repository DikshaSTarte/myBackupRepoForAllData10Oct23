package com.emp.management.emp_management.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "emp_department")
@AllArgsConstructor
@NoArgsConstructor
public class EmpDepartment extends BaseEntity{

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "department_id")
    private Integer empDepartmentId;

    @Column(name = "emp_dept_name")
    private String empDepartmentName;


//    @OneToMany(mappedBy = "empDepartment", cascade = CascadeType.ALL)
//    @JsonIgnoreProperties("empDepartment")
//   private List<EmpDesignation> empDesignationList;



}
