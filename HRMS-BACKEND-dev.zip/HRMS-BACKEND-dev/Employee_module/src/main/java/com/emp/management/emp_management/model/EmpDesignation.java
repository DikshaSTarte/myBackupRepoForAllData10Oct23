package com.emp.management.emp_management.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "emp_designation")
@AllArgsConstructor
@NoArgsConstructor
public class EmpDesignation extends BaseEntity{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "emp_designation_id")
    private Integer empDesignationId;

    @Column(name = "emp_designation_name")
    private String empDesignationName;

    @ManyToOne
    @JoinColumn(name = "emp_department")
    private EmpDepartment empDepartment;

}
