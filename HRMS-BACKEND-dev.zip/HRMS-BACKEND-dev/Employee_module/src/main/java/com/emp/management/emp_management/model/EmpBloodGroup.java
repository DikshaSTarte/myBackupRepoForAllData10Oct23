package com.emp.management.emp_management.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "emp_blood_group")
@AllArgsConstructor
@NoArgsConstructor
public class EmpBloodGroup extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "emp_blood_group_id")
    private Integer empBloodGroupId;

    @Column(name = "emp_blood_group_name")
    private String empBloodGroupName;

}

