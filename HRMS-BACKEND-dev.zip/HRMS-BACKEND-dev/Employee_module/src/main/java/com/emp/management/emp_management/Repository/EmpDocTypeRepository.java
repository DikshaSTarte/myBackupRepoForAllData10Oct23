package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.EmployeeDocType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmpDocTypeRepository extends JpaRepository<EmployeeDocType,Integer> {
}
