package com.emp.management.emp_management.Service;

import com.emp.management.emp_management.DTO.Request.EmployeeSaveRequest;
import com.emp.management.emp_management.DTO.Response.EmployeeBasicDetailDtoResponse;
import com.emp.management.emp_management.DTO.Response.EmployeeBasicDetailsResponse;
import com.emp.management.emp_management.DTO.Response.EmployeeFamilyBgResponse;

import java.util.List;

public interface EmployeeBasicDetailsService {

    EmployeeBasicDetailsResponse saveEmployeeBasicDetails(EmployeeSaveRequest employeeSaveRequest);



    EmployeeBasicDetailsResponse updateEmployeeBasicDetails(Integer employeeId,EmployeeSaveRequest employeeSaveRequest);


    List<EmployeeBasicDetailDtoResponse> getEmployeeBasicDetailByEmpId(Integer employeeId);

}
