package com.emp.management.emp_management.DTO.Response;


import com.emp.management.emp_management.model.Employee;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EmployeeBasicDetailsResponse {
   private Employee employee;
   private Integer EmployeeHistoryId;
//   private EmployeeResponse employeeResponse;
}
