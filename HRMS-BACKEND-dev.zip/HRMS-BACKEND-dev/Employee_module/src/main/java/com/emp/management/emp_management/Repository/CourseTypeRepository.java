//package com.emp.management.emp_management.Repository;
//
//import com.emp.management.emp_management.model.Specializations;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import java.util.List;
//
//public interface CourseTypeRepository extends JpaRepository<Specializations,Integer> {
//    List<Specializations> findByActive(boolean b);
//}
