package com.emp.management.emp_management.Controller;

import com.emp.management.emp_management.DTO.Request.EmployeePreCompanyRequest;
import com.emp.management.emp_management.DTO.Response.EmployeePreCompanyResponse;
import com.emp.management.emp_management.Service.EmployeePreCompanyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

    @Slf4j
    @RestController
    @RequestMapping("api/v1/employee/preCompany")
    public class EmployeePreCompanyController {

        @Autowired
        private EmployeePreCompanyService employeePreCompanyService;

        @PostMapping("/save")
        public EmployeePreCompanyResponse saveEmpPreCompanyData(@Valid @RequestBody EmployeePreCompanyRequest employeePreCompanyRequest){
            log.info("EmployeePreCompanyController----------saveEmpPreCompanyData------------{}",employeePreCompanyRequest);
            return employeePreCompanyService.saveEmployeePreCompany(employeePreCompanyRequest);
        }

        @GetMapping("/list")
        public List<EmployeePreCompanyResponse> getListEmployeePreCompany() {
            log.info("EmployeePreCompanyController----------getListEmployeePreCompany------------{}");
            return this.employeePreCompanyService.listEmployeePreCompany();
        }

        @DeleteMapping("/delete/{empPreCompanyId}")
        public ResponseEntity<String> deleteEmployeePreCompanyById(@PathVariable Integer empPreCompanyId) {
            employeePreCompanyService.deleteEmpPreCompanyById(empPreCompanyId);
            log.info("EmployeePreCompanyController----------deleteEmployeePreCompanyById------{}");
            return ResponseEntity.noContent().build();
            // return ResponseEntity.ok().body(result);
        }


        @PutMapping("/update/{empPreCompanyId}")
        public ResponseEntity<EmployeePreCompanyResponse> updateEmployeePreCompanyData(@Valid @PathVariable Integer empPreCompanyId, @RequestBody EmployeePreCompanyRequest employeePreCompanyRequest) {

            EmployeePreCompanyResponse employeePreCompanyResponse=employeePreCompanyService.updateEmployeePreCompanyById(empPreCompanyId,employeePreCompanyRequest);

            if (employeePreCompanyResponse != null) {
                log.info("EmployeePreCompanyController-----updateEmployeePreCompanyData--------{}",empPreCompanyId,employeePreCompanyRequest);
                return ResponseEntity.ok(employeePreCompanyResponse);
            } else {
                log.info("EmployeePreCompanyController-----------updateEmployeePreCompanyData---------{}",empPreCompanyId,employeePreCompanyRequest);
                return ResponseEntity.notFound().build();
            }
        }

    }

