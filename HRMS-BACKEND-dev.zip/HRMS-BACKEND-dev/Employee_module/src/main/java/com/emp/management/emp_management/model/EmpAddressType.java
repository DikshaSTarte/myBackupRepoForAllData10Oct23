package com.emp.management.emp_management.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "emp_address_type")
@AllArgsConstructor
@NoArgsConstructor
public class EmpAddressType extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "emp_add_type_id")
    private Integer empAddTypeId;

    @Column(name = "emp_add_type_name")
    private String empAddTypeName;

    // Other attributes

    @OneToMany(mappedBy = "empAddType")
    private List<EmployeeAddress> employeeAddressList;

    // Other relationships

}

