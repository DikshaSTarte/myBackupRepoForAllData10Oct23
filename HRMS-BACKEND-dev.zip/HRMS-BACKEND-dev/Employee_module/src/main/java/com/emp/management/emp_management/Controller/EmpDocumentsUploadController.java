package com.emp.management.emp_management.Controller;

import com.emp.management.emp_management.DTO.Request.DocumentRequest;
import com.emp.management.emp_management.DTO.Response.ApiResponse;
import com.emp.management.emp_management.DTO.Response.EmpDoctypeResponse;
import com.emp.management.emp_management.Service.EmpDocUploadService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/v1/employee/docUpload")
public class EmpDocumentsUploadController {

    @Autowired
    EmpDocUploadService empDocUploadService;

    @GetMapping("/list/{employeeId}")
    public List<EmpDoctypeResponse> getAllDocumentsTypes(@PathVariable Integer employeeId) {
        log.info("EmployeeController----------getEmployeess------------{}");
        return this.empDocUploadService.getListDocumetsUploaded(employeeId);
    }

    @DeleteMapping("/delete/{empId}/{docTypeId}")
    public ResponseEntity<ApiResponse> deleteDocumentByEmpId(@PathVariable Integer empId,@PathVariable Integer docTypeId) {
        System.out.println("*********************************************************************************************************");
        ApiResponse apiResponse= empDocUploadService.deleteFileById(empId,docTypeId);
        log.info("File deleting api Invoked----------------------------------------------------------{}",empId);
        if(apiResponse.getSuccess()){
            return new ResponseEntity<ApiResponse>(apiResponse, HttpStatus.OK);
//            return ResponseEntity.ok().body("file Deleted Successfully");
        }
        else
            return new ResponseEntity<ApiResponse>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
//            return ResponseEntity.ok().body("Error while Deleteing file :File Does not exist");
    }

    @PostMapping("/upload-files")
    public ResponseEntity<String> SaveEmployeeDocuments(@RequestParam("empAllDocuments") MultipartFile[] empAllDocuments,
                                                        Integer employeeId)throws IOException {


        log.info("employeeController----------UploadEmployeeDocs----------{}");
        Boolean check= empDocUploadService.saveEmployeeDecuments(empAllDocuments,employeeId);

        if(check)
            return ResponseEntity.ok("All Documents Uploaded SuccessFully");
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error While Uploading Files");

    }

    @PostMapping("/upload-files2")
    public ResponseEntity<String> uploadDocuments(@RequestParam("documentRequests") List<DocumentRequest> documentRequestList,Integer employeeId) throws IOException {

//        MultipartFile[] empAllDocuments = {
//
//        };
        log.info("employeeController----------UploadEmployeeDocs----------{}");
        Boolean check= empDocUploadService.saveEmployeeDecuments2(documentRequestList,employeeId);
        if(check)
            return ResponseEntity.ok("All Documents Uploaded SuccessFully");
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error While Uploading Files");

    }


//    @PostMapping("/upload-files3")
//    public ResponseEntity<ApiResponse> uploadDocuments3(@RequestParam("file") MultipartFile file, Integer employeeId, Integer documentId,boolean update) throws IOException {
//
//        log.info("employeeController----------UploadEmployeeDocs----------{}");
//        ApiResponse apiResponse = empDocUploadService.saveEmployeeDocuments3(file, employeeId, documentId,update);
//        if (apiResponse.getSuccess())
//        {
////            ResponseEntity.ok("All Documents Uploaded SuccessFully");
//            return new ResponseEntity<ApiResponse>(apiResponse, HttpStatus.OK);
//        }
////        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error While Uploading Files");
//        return new ResponseEntity<ApiResponse>(apiResponse, HttpStatus.OK);
//
//    }

    @PostMapping("/upload-files3")
    public ResponseEntity<ApiResponse> uploadDocuments3(
            @RequestParam(value = "file", required = false) MultipartFile file,
            Integer employeeId,
            Integer documentId,
            boolean update
    ) throws IOException {
        log.info("employeeController----------UploadEmployeeDocs----------{}");

        if (file!=null && file.getSize() > 90 * 1024 * 1024 ) {
            ApiResponse errorResponse = new ApiResponse("File size exceeds the maximum limit (100MB)", false);
            return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
        }
        ApiResponse apiResponse = empDocUploadService.saveEmployeeDocuments3(file, employeeId, documentId, update);

        HttpStatus httpStatus = apiResponse.getSuccess() ? HttpStatus.OK : HttpStatus.BAD_REQUEST;

        return new ResponseEntity<>(apiResponse, httpStatus);
    }
}