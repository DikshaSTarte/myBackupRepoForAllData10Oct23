package com.emp.management.emp_management.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.tomcat.jni.Address;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "employee")
@AllArgsConstructor
@NoArgsConstructor
public class Employee extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "employee_id")
    private Integer employeeId;

    @Column(name = "emp_first_name")
    private String empFirstName;

    @Column(name = "emp_Middle_name")
    private String empMiddleName;

    @Column(name = "emp_last_name")
    private String empLastName;

    @ManyToOne
    @JoinColumn(name = "emp_designation_id")
    private EmpDesignation empDesignation;


    @OneToOne(mappedBy = "employee", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("employee")
    private EmployeeBasicDetails basicDetails;

    @OneToOne(mappedBy = "employee", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnoreProperties("employee") // Ignore the circular reference here
    private ContactDetails contactDetails;

    @OneToMany(mappedBy = "employee", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("employee")
    private List<EmployeeAddress> addresses;

}
