package com.emp.management.emp_management.Repository;

import com.emp.management.emp_management.model.EmployeePreCompany;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmployeePreCompanyRepository extends JpaRepository<EmployeePreCompany,Integer> {
    List<EmployeePreCompany> findByActiveOrderByCreatedOnAsc(boolean b);

    EmployeePreCompany findByActiveAndEmpPreCompanyId(boolean b, Integer empPreCompanyId);
}
