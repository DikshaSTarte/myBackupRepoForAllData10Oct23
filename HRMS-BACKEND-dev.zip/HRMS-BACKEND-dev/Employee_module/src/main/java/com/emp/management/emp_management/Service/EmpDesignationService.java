package com.emp.management.emp_management.Service;

import com.emp.management.emp_management.DTO.Response.DesignationResponse;

import java.util.List;

public interface EmpDesignationService {

    List<DesignationResponse> getDesignationsListByDeptId(Integer departmentId);
}
