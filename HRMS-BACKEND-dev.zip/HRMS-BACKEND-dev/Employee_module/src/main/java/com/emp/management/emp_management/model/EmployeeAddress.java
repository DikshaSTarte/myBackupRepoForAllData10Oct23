package com.emp.management.emp_management.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "employee_address")
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeAddress extends BaseEntity{

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "emp_add_id")
    private Integer empAddId;

    @ManyToOne
    @JoinColumn(name = "employee_id")
    private Employee employee;

//    @Column(name = "emp_add_street")
//    private Integer addStreet;
//
//    @Column(name = "emp_add_city")
//    private Integer addCity;

    @Column(name = "emp_add_pincode")
    private Integer addPincode;


    @Column(name = "emp_detail_address")
    private String detailAddress;

    @Column(name = "emp_add_landmark")
    private String addLandmark;

    @ManyToOne
    @JoinColumn(name = "emp_add_type_id")
    private EmpAddressType empAddType;

    // Other attributes

}
