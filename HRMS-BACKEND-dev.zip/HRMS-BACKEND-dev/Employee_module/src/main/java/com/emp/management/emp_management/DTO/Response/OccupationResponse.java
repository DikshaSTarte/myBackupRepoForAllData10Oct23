package com.emp.management.emp_management.DTO.Response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OccupationResponse {

    private Integer occupationId;
    private String occupationName;
}
