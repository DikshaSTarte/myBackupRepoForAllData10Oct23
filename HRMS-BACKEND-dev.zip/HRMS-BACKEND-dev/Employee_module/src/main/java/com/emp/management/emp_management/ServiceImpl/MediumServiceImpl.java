package com.emp.management.emp_management.ServiceImpl;

import com.emp.management.emp_management.DTO.Response.MediumResponse;
import com.emp.management.emp_management.Repository.MediumRepository;
import com.emp.management.emp_management.Service.MediumService;
import com.emp.management.emp_management.mapper.ListingMapper;
import com.emp.management.emp_management.model.EducationMedium;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class MediumServiceImpl implements MediumService {
    @Autowired
    private MediumRepository mediumRepository;
    @Autowired
    private ListingMapper listingMapper;

    @Override
    public List<MediumResponse> getMediumList() {
        List<EducationMedium> educationMediumList = mediumRepository.findByActive(true);
        return listingMapper.mediumListMapper(educationMediumList);
    }
}
