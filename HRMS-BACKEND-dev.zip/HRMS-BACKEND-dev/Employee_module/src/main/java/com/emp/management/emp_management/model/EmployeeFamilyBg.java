package com.emp.management.emp_management.model;

import com.emp.management.emp_management.DTO.Response.EduTypeResponse;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "employee_family_bg")
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeFamilyBg extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "emp_family_bg_id")
    private Integer empFamilyBgId;

    @ManyToOne
    @JoinColumn(name = "employee_id")
    private Employee employee;

    @Column(name = "emp_family_member_first_name")
    private String empFamilyMemberFirstName;

    @Column(name = "emp_family_member_last_name")
    private String empFamilyMemberLastName;

    @Column(name = "emp_fm_relation")
    private String empFmRelation;

    @Column(name = "emp_fm_contact")
    private String empFmContact;

    @Column(name = "emp_fm_dob")
    private Date empFmDob;

    @ManyToOne
    @JoinColumn(name = "occupation_id")
    private Occupation occupation;

    @ManyToOne
    @JoinColumn(name = "emp_education_type_id")
    private EmployeeEducationType eduType;
}
