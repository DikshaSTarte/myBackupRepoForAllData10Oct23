//package com.emp.management.emp_management.model.Enum;
//
//public enum EmployeeEducationType {
//    SSC("Secondary School Certificate"),
//    HSC("Higher Secondary Certificate"),
//    UG("Undergraduate"),
//    PG("Postgraduate"),
//    DIPLOMA("Diploma"),
//    PHD("Doctor of Philosophy");
//
//    private final String description;
//
//    EmployeeEducationType(String description) {
//        this.description = description;
//    }
//
//    public String getDescription() {
//        return description;
//    }
//}
