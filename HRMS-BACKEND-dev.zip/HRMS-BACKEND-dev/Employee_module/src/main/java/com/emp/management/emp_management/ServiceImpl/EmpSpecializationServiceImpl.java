package com.emp.management.emp_management.ServiceImpl;

import com.emp.management.emp_management.DTO.Response.SpecializationResponse;
import com.emp.management.emp_management.Repository.SpecializationsRepository;
import com.emp.management.emp_management.Service.CourseTypeService;
import com.emp.management.emp_management.mapper.ListingMapper;
import com.emp.management.emp_management.model.Specializations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class EmpSpecializationServiceImpl implements CourseTypeService {
    @Autowired
    private ListingMapper listingMapper;
    @Autowired
    private SpecializationsRepository specializationsRepository ;
    @Override
    public List<SpecializationResponse> getSpecializationList() {

            List<Specializations> specializations = specializationsRepository.findByActive(true);
            return listingMapper.courseTypeListMapper(specializations);
    }

}

