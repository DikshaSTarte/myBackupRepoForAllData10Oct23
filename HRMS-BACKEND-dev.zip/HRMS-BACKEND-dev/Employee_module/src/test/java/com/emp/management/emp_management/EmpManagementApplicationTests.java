package com.emp.management.emp_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
